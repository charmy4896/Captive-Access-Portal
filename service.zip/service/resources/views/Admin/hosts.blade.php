@extends('index.Admin.index')




@section('content')


    <script src="{{ asset('DataTable/jquery.js') }}"></script>
    <script src="{{ asset('DataTable/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('DataTable/bootstrap.min.css') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.css') }}"></script>


    <div class="col-md-10 col-md-offset-1">

        {{--flashing message--}}
        @include('flash-message')

        {{ Session::forget('success') }}

        {{ Session::forget('error') }}


        @if($SecurityInfo != null and  $group_dn != null)


        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h1 class="panel-title"><h2>Host Names</h2></h1>
                    </div>
                    <div class="col col-xs-6 text-right" style="padding-top: 15px">

                        <button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal"> Add New Host </button>

                        {{--<button type="button" class="btn btn-sm btn-primary btn-create">Add New Group</button>--}}
                    </div>
                </div>
            </div>

            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog modal-lg" style="padding-top: 50px;
">
                    <div class="modal-content">
                        <div class="modal-header" style="padding: 2px 16px; background-color: #428bca; color: white">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×</button>
                            <h1 class="modal-title" id="myModalLabel">
                                New Host  </h1>
                        </div>
                        <div class="modal-body">

                            <form name="newgroup" class="form-horizontal" method="post" action="{{ route('addHost') }}">
                                {{ csrf_field() }}
                                <input type="hidden" name="action" value="groupadd" />
                                <input type="hidden" name="groupdn" value="{{ $group_dn }}"/>
                                <div class="form-group">
                                    <label for="name" class="col-sm-4 control-label">Name of Host</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                            <input type="text" name="name" id="name" class="form-control" placeholder="Host Name" required/>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="owner" class="col-sm-4 control-label">Owner</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                            <input type="text" name="owner" id="owner" class="form-control" placeholder="Owner" onfocus="getUsers()" required/>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Create</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel-body">

                <table id="mytable" class="table table-striped" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Name</th>
                    </tr>
                    </thead>
                    <tbody>

                    @foreach($SecurityInfo as $key => $SecurityGroup)
                    <tr>
                            <td><a href="{{ route('getHostInfoView',$SecurityGroup['dn']) }}">{{ $SecurityGroup['name'] }}</a></td>
                    </tr>

                    @endforeach


                    </tbody>
                </table>
            </div>
        </div>
    </div>


    @endif


    <link href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" rel="Stylesheet"></link>

    <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script>


    <style>

        /*#myModal2 .modal-content*/
        /*{*/
        /*height:400px;*/
        /*overflow:auto;*/
        /*}*/


        .panel-table .panel-footer .pagination{
            margin:0;
        }

        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 0px;
        }

        .ui-autocomplete {
            z-index:2147483647;
        }

    </style>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
            // $('#mytable1').DataTable();


        } );

        function getUsers() {

            jQuery.ajax({

                type :'POST',

                url: '{{ route('getUsers') }}',

                data: {_token: '{{csrf_token()}}'},

                success:function(data){

                    displayUsers(JSON.parse(data));

                },
                error:function (){}
            });
        }

        function displayUsers(data){

            $( function() {

                $( "#owner" ).autocomplete({
                    source: data ,
                });


            } );


        }
    </script>
@endsection