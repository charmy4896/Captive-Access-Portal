@extends('index.Admin.index')


@section('content')


    <script src="{{ asset('DataTable/jquery.js') }}"></script>
    <script src="{{ asset('DataTable/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('DataTable/bootstrap.min.css') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.css') }}"></script>


    @include('flash-message')


    {{ Session::forget('success') }}

    {{ Session::forget('error') }}


    @if($users != null and $count != null)

    <div class="alert alert-success">{{ $count }}
        @if( $count == 1)

            {{ getHeading('entryfound') }}

            @else

            {{ getHeading('entriesfound') }}

            @endif

    </div>

    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h3 class="panel-title">All Users</h3>
                    </div>
                    <div class="col col-xs-6 text-right">
                        <button type="button" class="btn btn-sm btn-primary btn-create" data-toggle="modal" data-target="#myModal">Create New</button>
                    </div>
                </div>
            </div>
            <div class="panel-body">

                <br>

                <table id="mytable" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th><em class="fa fa-cog"></em></th>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Mail</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>

                    @foreach($users as $key => $user)
                    <tr>

                        <td align="center" width="110px">
                            <a href="{{ route('editUserProfile',$user->getCommonName()) }}" class="btn btn-default"><i class="fa fa-edit"></i></a>
                            <a class="btn btn-danger" onclick=" return confirm('Are You Sure Want To Delete')" href="{{ route('deleteUser', $user->getCommonName()) }}" ><i class="fa fa-trash"></i></a>

                            {{--<a class="btn btn-danger" onclick="confirm('Are You Sure Want To Delete')"  ><i class="fa fa-trash"></i></a>--}}




                        </td>

                            <td><a href="{{ route('showUserProfile',$user->getCommonName()) }}">{{ $user->getCommonName() }}</a></td>
                            <td>{{ $user->getFirstName() }}</td>
                            <td>{{ $user->getEmail() }}</td>
                            <td>
                                {{ $user->getActive() }}
                            </td>
                    </tr>

                    @endforeach




                    </tbody>
                </table>
            </div>
        </div>
    </div>


        {{--Create User Modal--}}


    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" style="padding-top: 50px;
">
            <div class="modal-content">
                <div class="modal-header" style="padding: 2px 16px; background-color: #428bca; color: white">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        ×</button>
                    <h1 class="modal-title" id="myModalLabel">
                      Create  New User  </h1>
                </div>
                <div class="modal-body">

                    <form name="newgroup" class="form-horizontal" method="post" action="{{ route('createUser') }}">
                        {{ csrf_field() }}


                        <div class="form-group">
                            <label for="initials" class="col-sm-4 control-label">Initials<b style = 'font-size:150%;color:red'> *</b></label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    <select class="form-control" id="initials" name="initials" value="">
                                        <option value="Mr.">Mr.</option>
                                        <option value="Ms.">Ms.</option>
                                        <option value="Mrs.">Mrs.</option>
                                        <option value="Prof.">Prof.</option>
                                        <option value="Dr.">Dr.</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="login" class="col-sm-4 control-label">Username<b style = 'font-size:150%;color:red'> *</b></label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    <input type="text" name="login" id="login" value="" class="form-control " placeholder="Username" onblur="checkAvailability()"/>
                                </div>
                            </div>
                            <span id="user-availability-status" style="color: red"></span>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-sm-4 control-label">Password<b style = 'font-size:150%;color:red'> *</b></label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required/>
                                </div>

                                @if($errors->has('password'))
                                    <span class="help-block">

                                    <strong><p style="color: red">Password must contains least one Uppercase , one Lowercase and  one number</p></strong>
                                    </span>

                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="confirmpassword" class="col-sm-4 control-label">Confirm Password<b style = 'font-size:150%;color:red'> *</b></label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="password" name="confirmpassword" id="confirmpassword" class="form-control" placeholder="Confirm Password" onblur="check()" required/>
                                </div>
                                {{--@if($errors->has('confirmpassword'))--}}
                                    {{--<span class="help-block">--}}

                                        {{--<strong><p style="color: red"> Confirm Password is incorrect </p></strong>--}}

                                    {{--</span>--}}

                                {{--@endif--}}

                            </div>

                            <span id="message"></span>
                        </div>

                        <script>

                            var check = function() {

                                if (document.getElementById('password').value == document.getElementById('confirmpassword').value) {
                                    document.getElementById('message').style.color = 'green';
                                    document.getElementById('message').innerHTML = '&nbsp &nbsp &nbsp &nbsp matching';
                                } else {
                                    document.getElementById('message').style.color = 'red';
                                    document.getElementById('message').innerHTML = '&nbsp &nbsp &nbsp &nbsp not matching';
                                }
                            };
                        </script>

                        <div class="form-group">
                            <label for="firstname" class="col-sm-4 control-label">First name<b style = 'font-size:150%;color:red'> *</b></label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="text" name="firstname" id="firstname" value=""class="form-control" placeholder="First name" required/>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <label for="lastname" class="col-sm-4 control-label">Last name<b style = 'font-size:150%;color:red'> *</b></label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="text" name="lastname" id="lastname" value=""class="form-control" placeholder="Last name" required/>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-sm-4 control-label">Work E-Mail<b style = 'font-size:150%;color:red'> *</b></label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="text" name="email" id="email" value=""class="form-control" placeholder="Work E-Mail" required/>
                                </div>
                            </div>
                        </div>




                        <button type="submit" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Create</button>

                    </form>
                </div>
            </div>
        </div>
    </div>

    @endif


    <style>
        .panel-table .panel-body{
            padding:0;
        }

        .panel-table .panel-body .table-bordered{
            border-style: none;
            margin:0;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type {
            text-align:center;
            width: 100px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:last-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:last-of-type {
            border-right: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:first-of-type {
            border-left: 0px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr:first-of-type > td{
            border-bottom: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr:first-of-type > th{
            border-top: 0px;
        }

        .panel-table .panel-footer .pagination{
            margin:0;
        }


        /*
        used to vertically center elements, may need modification if you're not using default sizes.
        */
        .panel-table .panel-footer .col{
            line-height: 34px;
            height: 34px;
        }

        .panel-table .panel-heading .col h3{
            line-height: 30px;
            height: 30px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr > td{
            line-height: 30px;
        }

        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info {
            padding-left: 10px;
        }



    </style>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable({
                // "scrollY": "450px",
                "scrollCollapse": true,
                "pagingType": "full_numbers"
            });

        } );



        function checkAvailability() {


            jQuery.ajax({

                type :'POST',

                url: '{{ route('checkusername') }}',

                data: {_token: '{{csrf_token()}}',username :$("#login").val()},

                success:function(data){

                    if(data == 'true'){
                        $("#user-availability-status").html('&nbsp &nbsp username already exists');
                    }else{
                        $("#user-availability-status").html('  ');

                    }

                },
                error:function (){}
            });

        }


    </script>
@endsection