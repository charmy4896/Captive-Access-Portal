@extends('index.Admin.index')


@section('content')


    <script src="{{ asset('DataTable/jquery.js') }}"></script>
    <script src="{{ asset('DataTable/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('DataTable/bootstrap.min.css') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.css') }}"></script>


    @include('flash-message')


    {{ Session::forget('success') }}

    {{ Session::forget('error') }}




    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h3 class="panel-title">Users to be disable in Current Month</h3>
                    </div>

                </div>
            </div>
            <div class="panel-body">

                <table id="mytable1" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>

                        <th>Username</th>
                        <th>Date</th>
                        <th>Status</th>

                    </tr>
                    </thead>
                    <tbody>

                    @if($currentMonthUsers != null)

                        @foreach($currentMonthUsers as $user)
                            <tr>

                                <td><a href="{{ route('showUserProfile',  $user['username']) }}">{{$user['username'] }}</a></td>

                                <td>{{ $user['date'] }}</td>

                                @if($user['status'] == 'true' or $user['status'] == '1')

                                    <td> Disabled</td>


                                @else

                                    <td>Enabled</td>

                                @endif



                            </tr>

                        @endforeach

                    @endif



                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h3 class="panel-title">Users disabled in Previous Month</h3>
                    </div>
                </div>
            </div>
            <div class="panel-body">

                <table id="mytable" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>

                        <th>Username</th>
                        <th>Date</th>
                        <th>Status</th>

                    </tr>
                    </thead>
                    <tbody>

                    @if($prevMonthUsers != null)

                    @foreach($prevMonthUsers as $user)
                        <tr>

                            <td><a href="{{ route('showUserProfile',  $user['username']) }}">{{$user['username'] }}</a></td>

                            <td>{{ $user['date'] }}</td>



                            <td>Disabled</td>

                        </tr>

                    @endforeach

                        @endif



                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <style>
        .panel-table .panel-body{
            padding:0;
        }

        .panel-table .panel-body .table-bordered{
            border-style: none;
            margin:0;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type {
            text-align:center;
            width: 100px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:last-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:last-of-type {
            border-right: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:first-of-type {
            border-left: 0px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr:first-of-type > td{
            border-bottom: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr:first-of-type > th{
            border-top: 0px;
        }

        .panel-table .panel-footer .pagination{
            margin:0;
        }


        /*
        used to vertically center elements, may need modification if you're not using default sizes.
        */
        .panel-table .panel-footer .col{
            line-height: 34px;
            height: 34px;
        }

        .panel-table .panel-heading .col h3{
            line-height: 30px;
            height: 30px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr > td{
            line-height: 30px;
        }
        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 10px;
        }


    </style>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();

            $('#mytable1').DataTable();

        } );

    </script>



@endsection