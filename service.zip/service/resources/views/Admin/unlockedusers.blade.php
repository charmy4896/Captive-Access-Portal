@extends('index.Admin.index')


@section('content')

    <script src="{{ asset('DataTable/jquery.js') }}"></script>
    <script src="{{ asset('DataTable/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('DataTable/bootstrap.min.css') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.css') }}"></script>


    @include('flash-message')


    {{ Session::forget('success') }}

    {{ Session::forget('error') }}


    @if($no_of_unlocked_users != null and $users != null)

    <div class="alert alert-success">{{ $no_of_unlocked_users }}
        @if( $no_of_unlocked_users == 1)

            {{ getHeading('entryfound') }}

        @else

            {{ getHeading('entriesfound') }}

        @endif

    </div>

    {{--<div class="alert alert-warning"><i class="fa fa-fw fa-exclamation-triangle"></i>{{ $count }}</div>--}}


    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h3 class="panel-title">All Unlocked Users</h3>
                    </div>
                    {{--<div class="col col-xs-6 text-right">--}}
                        {{--<button type="button" class="btn btn-sm btn-primary btn-create">Create New</button>--}}
                    {{--</div>--}}
                </div>
            </div>
            <div class="panel-body">


                <table id="mytable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th><em class="fa fa-cog"></em></th>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Mail</th>
                    </tr>
                    </thead>
                    <tbody>
                    <br>
                    <tr>
                        @foreach($users as $key => $user)

                            <td align="center" width="110px">
                                <a href="{{ route('editUserProfile',$user->getCommonName()) }}" class="btn btn-default"><i class="fa fa-edit"></i></a>
                                <a class="btn btn-danger" onclick=" return confirm('Are You Sure Want To Delete')" href="{{ route('deleteUser', $user->getCommonName()) }}" ><i class="fa fa-trash"></i></a>

                            </td>

                            <td><a href="{{ route('showUserProfile',$user->getCommonName()) }}">{{ $user->getCommonName() }}</a></td>
                            <td>{{ $user->getFirstName() }}</td>
                            <td>{{ $user->getEmail() }}</td>
                    </tr>

                    @endforeach


                    </tbody>
                </table>
            </div>
        </div>
    </div>


    @endif

    <style>
        .panel-table .panel-body{
            padding:0;
        }

        .panel-table .panel-body .table-bordered{
            border-style: none;
            margin:0;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type {
            text-align:center;
            width: 100px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:last-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:last-of-type {
            border-right: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:first-of-type {
            border-left: 0px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr:first-of-type > td{
            border-bottom: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr:first-of-type > th{
            border-top: 0px;
        }

        .panel-table .panel-footer .pagination{
            margin:0;
        }


        /*
        used to vertically center elements, may need modification if you're not using default sizes.
        */
        .panel-table .panel-footer .col{
            line-height: 34px;
            height: 34px;
        }

        .panel-table .panel-heading .col h3{
            line-height: 30px;
            height: 30px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr > td{
            line-height: 30px;
        }
        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 10px;
        }


    </style>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
        } );
    </script>

@endsection