@extends('index.Admin.index')




@section('content')


    <script src="{{ asset('DataTable/jquery.js') }}"></script>
    <script src="{{ asset('DataTable/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('DataTable/bootstrap.min.css') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.css') }}"></script>


    <div class="col-md-10 col-md-offset-1">

        {{--flashing message--}}
        @include('flash-message')

        {{ Session::forget('success') }}

        {{ Session::forget('error') }}


        @if($securityInfo != null and $parent_dn != null and $group_dn != null and $users != null)

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h1 class="panel-title"><h2>{{ $securityInfo['name'] }}</h2></h1>
                        <button type="submit" name="submit" class="btn btn-primary col-sm-3" data-toggle="modal" data-target="#renamemodal">
                            <em class="glyphicon glyphicon-edit"></em> Rename</button>
                    </div>
                    <div class="col col-xs-6 text-right" style="padding-top: 15px">



                        <button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal"> Add New Host </button>

                    </div>
                </div>
            </div>

            {{--Add  new Group--}}

            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog modal-lg" style="padding-top: 50px;
">
                    <div class="modal-content">
                        <div class="modal-header" style="padding: 2px 16px; background-color: #428bca; color: white">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×</button>
                            <h1 class="modal-title" id="myModalLabel">
                                New Group  </h1>
                        </div>
                        <div class="modal-body">

                            <form name="newgroup" class="form-horizontal" method="post" action="{{ route('addHost') }}">
                                {{ csrf_field() }}
                                <input type="hidden" name="action" value="groupadd" />
                                <input type="hidden" name="groupdn" value="{{ $group_dn }}"/>
                                <div class="form-group">
                                    <label for="name" class="col-sm-4 control-label">Name of Host</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                            <input type="text" name="name" id="name" class="form-control" placeholder="Group Name" required/>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="owner" class="col-sm-4 control-label">Owner</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                            <input type="text" name="owner" id="owner" class="form-control" placeholder="Owner" onfocus="getUsers()" required/>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Create</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            {{--Rename Host Name Modal--}}

            <div class="modal fade" id="renamemodal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog modal-lg" style="padding-top: 50px;
">
                    <div class="modal-content">
                        <div class="modal-header" style="padding: 2px 16px; background-color: #428bca; color: white">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×</button>
                            <h1 class="modal-title" id="myModalLabel">
                                New Host  </h1>
                        </div>
                        <div class="modal-body">

                            <form name="newgroup" class="form-horizontal" method="post" action="{{ route('renameHostName') }}">
                                {{ csrf_field() }}
                                <input type="hidden" name="action" value="groupadd" />
                                <input type="hidden" name="groupdn" value="{{ $group_dn }}"/>
                                <input type="hidden" name="parentdn" value="{{ $parent_dn }}"/>

                                <div class="form-group">
                                    <label for="groupname" class="col-sm-4 control-label">New Host Name</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                            <input type="text" name="groupname" id="groupname" class="form-control" placeholder=" New Group Name" required/>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Rename</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <div class="panel-body">

                <table id="mytable" class="table table-striped" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Owner</th>
                    </tr>
                    </thead>
                    <tbody>

                    {{ Session::put('parent_dn',$group_dn) }}

                    @if(array_key_exists('suborg',$securityInfo))

                        @foreach($securityInfo['suborg'] as $key => $security)

                            <tr>
                                <td><a href="{{ route('getHostInfoView',$security['dn']) }}">{{ $security['name'] }}</a></td>
                                <td>{{ $security['owner']  }}</td>
                            </tr>

                        @endforeach

                    @endif

                    </tbody>
                </table>
            </div>
        </div>
    </div>



    {{--ADD MEMBER --}}

    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6 ">
                        <h1 class="panel-title"><h2>Members</h2></h1>
                    </div>
                    <div class="col col-xs-6 text-right" style="padding-top: 15px">

                        <button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target="#addmembermodal"> Add New Member </button>

                        {{--<button type="button" class="btn btn-sm btn-primary btn-create">Add New Group</button>--}}
                    </div>
                </div>
            </div>




            <div class="modal fade" id="addmembermodal"  role="dialog">
                <div class="modal-dialog"  >
                    <div class="modal-content">
                        <div class="modal-header" style="background-color: #428bca; color: white" >
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×</button>
                            <h1 class="modal-title" id="myModalLabel">
                                New Member  </h1>
                        </div>

                        <div class="modal-body">

                            {{--<form name="newgroup" class="form-horizontal" method="post" action="{{ route('addMember') }}">--}}

                                {{--{{ csrf_field() }}--}}
                                {{--<input type="hidden" name="action" value="groupadd" />--}}
                                {{--<input type="hidden" name="groupdn" value="{{ $group_dn }}"/>--}}

                            {{ Session::put('groupdn',$group_dn) }}

                                {{--All users --}}
                                <div class="col-md-10 col-md-offset-1">

                                    <div class="panel panel-default panel-table">
                                        <div class="panel-body">
                                            <table id="mytable2" class="table table-striped " cellspacing="0" width="100%">
                                                <thead>
                                                <tr>
                                                    <th>UID</th>
                                                    <th><em class="fa fa-cog"></em></th>
                                                </tr>
                                                </thead>
                                                <tbody>

                                                @foreach($users as $key => $user)
                                                    <tr>

                                                        <td>{{ $user->getCommonName() }} </td>

                                                        <td>

                                                            <!-- <input type="hidden" name="commanName" value="{{ $user->getCommonName() }}"/> -->

                                                            <a href="{{ route('addMember',$user->getCommonName()) }}">
                                                                <button type="submit" name="submit" class="btn btn-primary"> Add To Group</button></a>

                                                        </td>

                                                    </tr>
                                                @endforeach

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Create</button>
                            {{--</form>--}}

                        </div>
                    </div>
                </div>
            </div>

            {{----}}
            {{--Display Member of Group--}}

            <div class="panel-body">

                <table id="mytable1" class="table table-striped" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>UID</th>
                        <th></th>

                    </tr>
                    </thead>
                    <tbody>
                    @if(array_key_exists('member',$securityInfo))

                        @foreach($securityInfo['member'] as $key => $member)
                            <tr>


                                <td><a href="{{ route('showUserProfile',$member) }}">{{ $member }}</a></td>
                                <td>

                                    <form name="newgroup" class="form-horizontal" method="post" action="{{ route('removeMember',$member) }}">

                                        {{ csrf_field() }}
                                        <input type="hidden" name="groupdn" value="{{ $group_dn }}"/>

                                        <button type="submit" name="submit" class="btn btn-primary">Remove</button>


                                    </form>

                                </td>

                            </tr>
                        @endforeach
                    @endif

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @endif




    <link href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" rel="Stylesheet"></link>

    <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script>


    <style>

        /*#myModal2 .modal-content*/
        /*{*/
        /*height:400px;*/
        /*overflow:auto;*/
        /*}*/


        .panel-table .panel-footer .pagination{
            margin:0;
        }

        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 0px;
        }

        .ui-autocomplete {
            z-index:2147483647;
        }


    </style>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
            $('#mytable1').DataTable();
            $('#mytable2').DataTable({
                "scrollY": "450px",
                "scrollCollapse": true,
                "pagingType": "full_numbers"
            } );


        } );

        function getUsers() {

            jQuery.ajax({

                type :'POST',

                url: '{{ route('getUsers') }}',

                data: {_token: '{{csrf_token()}}'},

                success:function(data){

                    displayUsers(JSON.parse(data));

                },
                error:function (){}
            });
        }

        function displayUsers(data){

            $( function() {

                $( "#owner" ).autocomplete({
                    source: data ,
                });


            } );


        }
    </script>
@endsection