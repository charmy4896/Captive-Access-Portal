

@extends('index.Admin.index')


        @section('content')

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
        google.load("visualization", "1", { packages: ["orgchart"] });
        google.setOnLoadCallback(drawChart);
        function drawChart() {
            $.ajax({
                type: "POST",
                url: '{{ route('getOrganizationInformation') }}',
                data: {_token: '{{csrf_token()}}'},
                datatype: 'json',

                success: function (data1) {


                    // // console.log(jQuery.parseJSON(data1));



                    var r =  JSON.parse(data1);

                    var parent = r[0];

                    var child = r[1];

                    var ParentCount = Object.keys(parent).length;

                    var ChildCount = Object.keys(child).length;

                    var employeeId , parentName,childName;

                    var Parentdata = new google.visualization.DataTable();
                    Parentdata.addColumn('string', 'Entity');
                    Parentdata.addColumn('string', 'ParentEntity');
                    Parentdata.addColumn('string', 'ToolTip');

                    var Childdata = new google.visualization.DataTable();
                    Childdata.addColumn('string', 'Entity');
                    Childdata.addColumn('string', 'ParentEntity');
                    Childdata.addColumn('string', 'ToolTip');

                    for (var i = 0; i < ParentCount; i++) {

                          employeeId = i.toString();
                         parentName = parent[i]['parentId'];
                          childName = parent[i]['memberId'];

                        Parentdata.addRows([[{ v: employeeId,
                            f: childName }, parentName, '']]);
                    }
                    console.log(parent);

                    for ( i = 0; i < ChildCount; i++) {

                         employeeId = i.toString();
                         parentName = child[i]['parentId'];
                         childName = child[i]['memberId'];

                        Childdata.addRows([[{ v: employeeId,
                            f: childName }, parentName, '']]);
                    }

                    console.log(child);
                    var chart1 = new google.visualization.OrgChart($("#ParentChart")[0]);
                    chart1.draw(Parentdata, { allowHtml: true });

                    var chart2 = new google.visualization.OrgChart($("#ChildChart")[0]);
                    chart2.draw(Childdata, { allowHtml: true });
                },
                failure: function (r) {
                    alert(r.d);
                },
                error: function (r) {
                    alert(r.d);
                }
            });
        }

        </script>


<div id="ParentChart">
</div>


    <div id="ChildChart">
    </div>


@endsection

