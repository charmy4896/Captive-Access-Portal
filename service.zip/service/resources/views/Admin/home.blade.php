 @extends('index.Admin.index')


@section('content')


    @include('flash-message')

    {{ Session::forget('success') }}

    {{ Session::forget('error') }}


    @if($info != null and $username != null)

    <div class="col-lg-4">
        <div class="panel panel-info">
            <div class="panel-heading">
                <div class="row"><div class="col-xs-6">
                        <i class="fa fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-6 text-right">
                        <p class="announcement-heading">{{ $info['totalusers'] }}</p>
                        <p class="announcement-text">Total Users</p>
                    </div>
                </div>
            </div>
                </div>
        </div>

    <div class="col-lg-4">
        <div class="panel panel-success">
            <div class="panel-heading">
                <div class="row"><div class="col-xs-6">
                        <i class="fa fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-6 text-right">
                        <p class="announcement-heading">{{ $info['unlockedusers'] }}</p>
                        <p class="announcement-text">Total Unlocked Users</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="panel panel-danger">
            <div class="panel-heading">
                <div class="row"><div class="col-xs-6">
                        <i class="fa fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-6 text-right">
                        <p class="announcement-heading">{{ $info['lockedusers'] }}</p>
                        <p class="announcement-text">Total Locked Users</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endif




    <img src="{{ asset('/images/DAE.gif') }}" alt="Not Available" class="center-block" width ="200px" height = "200px">



@endsection