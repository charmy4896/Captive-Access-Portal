@extends('layouts.main')

@section('content')


    @include('flash-message')

    {{ Session::forget('success') }}

    {{ Session::forget('error') }}


    {{--<div class="result alert alert-success">--}}
        {{--<p><i class="fa fa-check-square" aria-hidden="true"></i></p>--}}
    {{--</div>--}}

    <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Enter your Username</p></div>


    <div class="alert alert-info">
        <form action="{{ route('SentResetPasswordLink') }}" method="post" class="form-horizontal">

            {{csrf_field()}}

            <div class="form-group">
                <label for="username" class="col-sm-4 control-label">Username</label>
                <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" name="username" id="username" value="" class="form-control" placeholder="Username" />
                    </div>
                </div>
            </div>


            <div class="form-group">

                <label for="captcha" class="col-sm-4 control-label">Captcha</label>

                <div class="col-sm-4">

                    <div class="col-sm-6">

                        <div class="form-group refereshrecapcha">

                            {!! captcha_img('flat') !!}

                        </div>

                    </div>

                    <div class="col-sm-6">

                        <button type="button" class="btn btn-success" onclick="Captcha_refresh()" ><i class="fa fa-refresh" style="font-size:12px"></i></button>

                    </div>

                    <br>

                    <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha Here"  required />


                </div>

            </div>


            <div class="form-group">
                <div class="col-sm-offset-4 col-sm-1">
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-check-square"></i> Change Password </button>
                </div>
                <div>


        </form>
        <form action="{{ route('home.index') }}" method="GET" class="form-horizontal">
            {{  csrf_field() }}
            <div class="form-group">
                <div class="col-sm-offset-1 col-sm-3">
                    <button type="submit" class="btn btn-success">
                        <input type="hidden" name="cancel" value="cancel">
                        <i class="fa fa-check-square"></i> Cancel            </button>
                </div>
            </div>
        </form>
    </div>




    <script type="text/javascript">

        function Captcha_refresh() {

            $.ajax({

                url: '{{ route('refreshCaptcha') }}',

                type: 'get',

                dataType: 'html',

                success: function(json) {

                    $('.refereshrecapcha').html(json);

                },

            });

        }


    </script>


@endsection