<!doctype html>
<html lang="en">
<head>


</head>
<body>
<h1>Computer Division</h1>
{{--<h1> Click Here for Approval : {{ route('divHeadApprovalView',[  $userId  , $divHeadId]) }}</h1>--}}
<h2><br>
    Following User have requested  for {{ $remarks }} : <br>
    {{ $userId }} <br>
 </h2>
</body>
</html>