



@extends( Session::has('admin_username') ? 'index.Admin.index'  : 'layouts.display_main')



@section('content')

    <script src="{{ asset('DataTable/jquery.js') }}"></script>
    <script src="{{ asset('DataTable/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('DataTable/bootstrap.min.css') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.css') }}"></script>

    @include('flash-message')


    {{ Session::forget('success') }}

    {{ Session::forget('error') }}

        <div class="result alert alert-success">
            <p>
                <b>
                    USER DIVSION HEAD APPROVAL
                </b>
            </p>
        </div>

    <div class="col-md-12">

        <div class="panel panel-default panel-table">

            <div class="panel-body">

                <table id="mytable" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th scope="col">User Id</th>
                        <th scope="col">Payroll</th>
                        <th scope="col">Head Id</th>
                        <th scope="col">Div Status</th>
                        <th>Request Date</th>
                        <th>Division Approval</th>
                        <th>Remarks</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>

                    @if($divHeadInfo != null)
                        @foreach( $divHeadInfo as $info)

                            <tr>

                                <td>{{ $info->user_id }}</td>
                                <td>{{ $info->payroll_no }}</td>
                                <td>{{ $info->div_head_id }}</td>
                                <td>{{$info->div_head_status  }}</td>
                                <td>
                                    {{ $info->request_date}}
                                </td>
                                <td>
                                    @if($info->div_approval_date != null)
                                        {{ $info->div_approval_date}}
                                    @endif
                                </td>
                                <td>

                                    @if($info->div_head_status != 'Approved')


                                        <input type="text" name="remarks{{ $info->user_id }}" id="remarks{{ $info->user_id }}"  value="" class="form-control " placeholder="Remarks"/>

                                        @else

                                        <input id="remarks.{{ $info->user_id }}" type="text" name="remarks"  value="{{ $info->remarks }}"  required disabled="" >

                                        @endif




                                </td>
                                <td>

                                    @if($info->div_approval_date == null)

                                        <button  id="approve" name="submit" class="btn btn-primary" onclick="approve( '{{ $info->user_id }}' , '#remarks{{ $info->user_id  }}');" >Yes</button>

                                        <button  id="disapprove" name="submit" class="btn btn-danger" onclick="disapprove('{{ $info->user_id }}')">No</button>


                                    @else

                                        {{ $info->div_head_status }}


                                    @endif

                                </td>



                            </tr>

                        @endforeach

                    @endif


                    </tbody>
                </table>
            </div>
        </div>
    </div>





{{--<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">--}}
{{--<script src="https://code.jquery.com/jquery-1.12.4.js"></script>--}}
{{--<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>--}}

<script type="text/javascript">

    function approve( user_id , remarks) {

    jQuery.ajax({

            type :'POST',

            url: '{{ route('divHeadApproval') }}',

            data : {_token: '{{csrf_token()}}', user_id: user_id , remarks : $(remarks).val() },

            success:  function (data) {

                console.log(data);

                if(data == 'true'){
                    alert('User request Approved');

                    window.location.reload();

                }else{
                    alert('Error While Approving');
                    window.location.reload();
                }

            }


        });
    }
    
    function disapprove(user_id) {


        jQuery.ajax({

            type :'POST',

            url: '{{ route('divHeadDisApproval') }}',

            data : {_token: '{{csrf_token()}}', user_id: user_id },

            success:  function (data) {

                console.log(data);

                if(data == 'true'){
                    alert('User request DisApproved');
                    window.location.reload();

                }else{
                    alert('Error While DisApproving');
                    window.location.reload();

                }

            }


        });
    }


</script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
        } );

    </script>

        @endsection

{{--</body>--}}
{{--</html>--}}