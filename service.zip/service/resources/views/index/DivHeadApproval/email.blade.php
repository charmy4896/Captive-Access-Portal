<!doctype html>
<html lang="en">
<head>


</head>
<body>

{{--<h1> Click Here for Approval : {{ route('divHeadApprovalView',[  $userId  , $divHeadId]) }}</h1>--}}
<h4>Division Head ID : {{ $divHeadId }}</h4>
<h3>Following Student have applied Internet Access :</h3>
<h1>{{ $userId }}</h1>
<h3>Check your Account for above Student Approval</h3>


Click Here :

</body>
</html>