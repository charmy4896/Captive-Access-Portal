

@extends( Session::has('admin_username') ? 'index.Admin.index'  : 'layouts.display_main')



@section('content')


    <script src="{{ asset('DataTable/jquery.js') }}"></script>
    <script src="{{ asset('DataTable/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.js') }}"></script>
    <script src="{{ asset('DataTable/bootstrap.min.css') }}"></script>
    <script src="{{ asset('DataTable/dataTables.bootstrap.min.css') }}"></script>


    @include('flash-message')


    {{ Session::forget('success') }}

    {{ Session::forget('error') }}

    {{--<link rel="stylesheet" href="{{ asset('css/libs.css') }}">--}}
    {{--<link rel="stylesheet" href="{{ asset('css/app.css') }}">--}}

    <div class="result alert alert-success">
        <p>
            <b>
                USER CC HEAD APPROVAL
            </b>
        </p>
    </div>


    <div class="col-md-12">

        <div class="panel panel-default panel-table">

            <div class="panel-body">

                <table id="mytable" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th scope="col">User Id</th>
                        <th scope="col">Payroll</th>
                        <th scope="col">Head Id</th>
                        <th scope="col">Head Status</th>
                        <th>Request Date</th>
                        <th>Division Approval</th>
                        <th>Head Remarks</th>
                        <th>CC Head Approval Date</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>

                    @if($pendingRequest != null)

                        @foreach( $pendingRequest as $info)
                            <tr>


                                <td >{{ $info->user_id }}</td>
                                <td >{{ $info->payroll_no }}</td>
                                <td >{{ $info->div_head_id }}</td>
                                <td >{{$info->div_head_status  }}</td>

                                <td>
                                    {{ $info->request_date}}
                                </td>

                                <td>
                                    @if($info->div_approval_date != null)
                                        {{ $info->div_approval_date}}
                                    @endif

                                </td>
                                <td>
                                    @if( $info->remarks  != null)

                                        {{ $info->remarks }}

                                        @endif


                                </td>
                                <td>
                                    @if($info->cc_head_approval_date != null)

                                        {{$info->cc_head_approval_date   }}

                                    @endif

                                </td>
                                <td>


                                    <button  id="approve" name="submit" class="btn btn-primary" onclick="approve( '{{ $info->user_id }}' );" >Yes</button>

                                    <button  id="disapprove" name="submit" class="btn btn-danger" onclick="disapprove('{{ $info->user_id }}')">No</button>


                                </td>

                            </tr>

                        @endforeach

                    @endif


                    @if($otherRequest != null)

                        @foreach( $otherRequest as $info)

                            <tr>

                                <td >{{ $info->user_id }}</td>

                                <td >{{ $info->payroll_no }}</td>

                                <td >{{ $info->div_head_id }}</td>

                                <td >{{$info->div_head_status  }}</td>

                                <td>
                                    {{ $info->request_date}}
                                </td>
                                <td>
                                    @if($info->div_approval_date != null)
                                        {{ $info->div_approval_date}}
                                    @endif

                                </td>

                                <td>
                                    @if( $info->remarks  != null)

                                        {{ $info->remarks }}

                                    @endif


                                </td>


                                <td>
                                    @if($info->cc_head_approval_date != null)

                                        {{$info->cc_head_approval_date   }}

                                    @endif
                                </td>
                                <td>

                                    {{ $info->cc_head_approval_status }}



                                </td>

                            </tr>

                        @endforeach

                    @endif


                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <script type="text/javascript">



        function approve( user_id) {



            jQuery.ajax({

                type :'POST',

                url: '{{ route('CCHeadApproval') }}',

                data : {_token: '{{csrf_token()}}', user_id: user_id },

                success:  function (data) {

                    console.log(data);

                    if(data == 'true'){
                        alert('User request Approved');

                        window.location.reload();

                    }else{
                        alert('Error While Approving');
                        window.location.reload();
                    }

                }


            });
        }

        function disapprove(user_id) {


            jQuery.ajax({

                type :'POST',

                url: '{{ route('CCHeadDisApproval') }}',

                data : {_token: '{{csrf_token()}}', user_id: user_id },

                success:  function (data) {

                    console.log(data);

                    if(data == 'true'){
                        alert('User request DisApproved');
                        window.location.reload();

                    }else{
                        alert('Error While DisApproving');
                        window.location.reload();

                    }

                }


            });
        }



    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
        } );

    </script>

    <style>
        .panel-table .panel-body{
            padding:0;
        }

        .panel-table .panel-body .table-bordered{
            border-style: none;
            margin:0;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type {
            text-align:center;
            width: 100px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:last-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:last-of-type {
            border-right: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:first-of-type {
            border-left: 0px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr:first-of-type > td{
            border-bottom: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr:first-of-type > th{
            border-top: 0px;
        }

        .panel-table .panel-footer .pagination{
            margin:0;
        }


        /*
        used to vertically center elements, may need modification if you're not using default sizes.
        */
        .panel-table .panel-footer .col{
            line-height: 34px;
            height: 34px;
        }

        .panel-table .panel-heading .col h3{
            line-height: 30px;
            height: 30px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr > td{
            line-height: 30px;
        }
        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 10px;
        }


    </style>

@endsection

{{--</body>--}}
{{--</html>--}}