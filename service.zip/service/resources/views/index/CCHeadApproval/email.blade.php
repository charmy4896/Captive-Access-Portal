<!doctype html>
<html lang="en">
<head>


</head>
<body>
<h1>CC HEAD</h1>
{{--<h1> Click Here for Approval : {{ route('divHeadApprovalView',[  $userId  , $divHeadId]) }}</h1>--}}
<h2>Division Head ID : {{ $divHeadId }}<br>
Following Student have applied  for {{ $remarks }}: <br>
{{ $userId }} <br>
Check your Account for above Student Approval </h2>
</body>
</html>