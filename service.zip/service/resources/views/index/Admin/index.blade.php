<!doctype html>
<html lang="en">
<head>

    <link href="{{asset('css/app.css')}}" rel="stylesheet">

    {{--<link href="{{asset('css/libs.css')}}" rel="stylesheet">--}}

    {{--<link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">--}}


    <script rel="stylesheet" src="{{ asset('js/jquery.js') }}" ></script>

    <script rel="stylesheet" src="{{ asset('js/bootstrap.js') }}"></script>

    <script rel="stylesheet" src="{{ asset('js/jquery-ui.js') }}"></script>

    <link rel="stylesheet" href="{{ asset('css/jquery-ui.css') }}">

    {{--<link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">--}}


    <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">



    <style type="text/css">
        html,body {
            background: url({{ URL::asset('images/unsplash-clouds.jpeg')}}) no-repeat center fixed;
            background-size: cover;

            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            /*background-image: url('images/background.jpg');*/
            background-repeat: no-repeat;
            background-attachment: fixed;
        //background-size: 100%;
            opacity: 0.9;
            filter:alpha(opacity=90);

        }
    </style>

</head>
<body id="background">

<div class="container" id="container">

    <div class="panel panel-success">
        <div class="panel-body">
            <div class="navbar-wrapper">

                <div class="navbar navbar-default navbar-static-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-form navbar-left">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="{{ route('Admin.index') }}"><i class="fa fa-home"></i>Home</a>
                        </div>

                        <div class="navbar-form navbar-right ">
                            <ul class="nav navbar-nav">
                                <li class="navbar">
                                    <a href="{{ route('logviewer') }}"><i class="fa fa-fw fa-th"></i>Log Viewer</a>
                                </li>
                                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-fw fa-th"></i> {{ getHeading('users') }}<b class="caret"></b></a>



                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="{{ route('getAllUsers') }}">{{ getHeading('all') }}</a>
                                        </li>
                                        <li>
                                            <a href="{{ route('getLockedUsers') }}">{{ getHeading('locked') }}</a>
                                        </li>
                                        <li>
                                            <a href="{{ route('getUnLockedUsers') }}">{{ getHeading('unlocked') }}</a>
                                        </li>
                                        <li>
                                            <a href="{{ route('getGuests') }}">{{ getHeading('guest') }}</a>
                                        </li>
                                        <li>
                                            <a href="{{ route('admin_password_change_view') }}">{{ getHeading('changepassword') }}</a>
                                        </li>
                                    </ul>

                                </li>
                                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-fw fa-th"></i> {{ getHeading('groups') }}<b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="{{ route('OrgGroupsView') }}">{{ getHeading('orggroups') }}</a>
                                        </li>
                                        <li>
                                            <a href="{{ route('SecurityGroupNames') }}">{{ getHeading('hbac') }}</a>
                                        </li>
                                    </ul>
                                </li>

                                {{--@if(Session::get('ismember') == 'true')--}}

                                    {{--<li class="navbar">--}}
                                        {{--<a href="{{ route('divHeadApprovalView') }}"><i class="fa fa-fw fa-th"></i>User Request Approval</a>--}}
                                    {{--</li>--}}

                                {{--@endif--}}

                                {{--@if(Session::get('cc_head') == 'true')--}}

                                    {{--<li class="navbar">--}}
                                        {{--<a href="{{ route('CCHeadApprovalView') }}"><i class="fa fa-fw fa-th"></i> CC Head Approval</a>--}}
                                    {{--</li>--}}

                                {{--@endif--}}


                                @if(Session::get('ismember') == 'true' or Session::get('cc_head') == 'true'  )


                                        <ul class="nav navbar-nav">

                                            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                                    <i class="fa fa-fw fa-th"></i> Manage Users Request <b class="caret"></b></a>

                                                <ul class="dropdown-menu">

                                                    @if(Session::get('ismember') == 'true')

                                                        <li class="navbar">
                                                            <a href="{{ route('divHeadApprovalView') }}"><i class="fa fa-fw fa-th"></i>User Request Approval</a>
                                                        </li>

                                                    @endif

                                                    @if(Session::get('cc_head') == 'true')

                                                        <li class="navbar">
                                                            <a href="{{ route('CCHeadApprovalView') }}"><i class="fa fa-fw fa-th"></i> CC Head Approval</a>
                                                        </li>
                                                    @endif
                                                </ul>
                                            </li>

                                        </ul>


                                @endif

                                {{--<li class="navbar">--}}
                                    {{--<a href="{{ route('showOrganizationalChart') }}"><i class="fa fa-fw fa-th"></i>Organization Information</a>--}}
                                {{--</li>--}}

                                <li class="navbar">
                                    <a href="{{ route('deadline') }}"><i class="fa fa-fw fa-th"></i>Deadline</a>
                                </li>


                                <li class="navbar-right">
                                    <a href="{{ route('logout') }}"><i class="fa fa-fw fa-th"></i>Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            @yield('content')
        </div>
    </div>


</div>


</body>
</html>