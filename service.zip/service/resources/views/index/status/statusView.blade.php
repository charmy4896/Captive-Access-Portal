@extends('layouts.main')




@section('labels')

    <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Enter Your Username to Check Current Status</p></div>


    @include('flash-message')

    {{ Session::forget('success') }}

    {{ Session::forget('error') }}
@endsection


@section('content')

    <div class="alert alert-info" style="width: 80%; margin:0 auto;">

        <form action="{{ route('getStatus')}}" method="POST" class="form-horizontal">

            {{csrf_field()}}



            <div class="form-group">
                <label for="username" class="col-sm-4 control-label">Username</label>
                <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" name="username" id="username" value="" class="form-control" placeholder="Username"  required/>
                    </div>
                </div>
            </div>


            <div class="form-group">

                <label for="captcha" class="col-sm-4 control-label">Captcha</label>

                <div class="col-sm-4">

                    <div class="col-sm-8">

                        <div class="form-group refereshrecapcha">

                            {!! captcha_img('flat') !!}

                        </div>

                    </div>

                    <div class="col-sm-4">

                        <button type="button" class="btn btn-success" onclick="Captcha_refresh()" ><i class="fa fa-refresh" style="font-size:12px"></i></button>

                    </div>

                    <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha Here"   />


                </div>

            </div>



            <div class="form-group">
                    <div class="col-sm-offset-4 col-sm-8">
                        <button type="submit"  class="btn btn-success">
                            <i class="fa fa-check-square-o"></i> Get Status           </button>
                    </div>
                </div>
        </form>


    </div>

    <script>


        function Captcha_refresh() {

            $.ajax({

                url: '{{ route('refreshCaptcha') }}',

                type: 'get',

                dataType: 'html',

                success: function(json) {

                    $('.refereshrecapcha').html(json);

                },

            });

        }






    </script>


@endsection