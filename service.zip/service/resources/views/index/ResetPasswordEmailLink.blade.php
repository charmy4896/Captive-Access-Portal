<!doctype html>
<html lang="en">
<head>

</head>
<body>
<h3>Click Here to Reset your password :


    {{ route('PasswordResetEmail',$username) }}


</h3>




</body>
</html>