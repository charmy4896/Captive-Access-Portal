
<!DOCTYPE html>
<html lang="en" >

<head>
    <meta charset="UTF-8">
    <title>IPR</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">


    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- Bootstrap Core CSS -->
    <link href="{{asset('css/app.css')}}" rel="stylesheet">

    <link href="{{asset('css/libs.css')}}" rel="stylesheet">


</head>

<body>

<!-- multistep form -->
<form id="msform" action="{{ route('employee.store') }}" method="POST">

{{csrf_field()}}

<!-- progressbar -->
    <ul id="progressbar">
        <li class="active">Account Setup</li>
        <li>Additional Details</li>
        <li>Employee Details</li>
    </ul>
    <!-- fieldsets -->
    <fieldset>
        <h2 class="fs-title">Create your account</h2>
        {{--<h3 class="fs-subtitle">This is step 1</h3>--}}
        <input type="text" name="login" id="login" value="" class="form-control" placeholder="Username" onblur="myFunction()"/>
        <input type="text" name="mail" id="mail" value=""class="form-control" placeholder="Work E-Mail" required/>
        <input type="text" name="mobile" id="mobile" maxlength="10" value="" class="form-control" placeholder="Mobile No."  required/>
        <input type="button" name="next" class="next action-button" value="Next" />
    </fieldset>




    <fieldset>
        <h2 class="fs-title">Additional Details</h2>
        {{--<h3 class="fs-subtitle">Personal Details</h3>--}}

        <input type="text" name="firstname" id="firstname" value=""class="form-control" placeholder="First name" required/>
        <input type="text" name="lastname" id="lastname" value=""class="form-control" placeholder="Last name" required/>
        <select class="form-control" id="initials" name="initials" value="">
            <option value="Mr.">Mr.</option>
            <option value="Ms.">Ms.</option>
            <option value="Mrs.">Mrs.</option>
            <option value="Prof.">Prof.</option>
            <option value="Dr.">Dr.</option>
        </select>
        <br>
        <input type="text" name="emailaddress" id="emailaddress" value="" class="form-control" placeholder="Alternate Email" required/>
        <input type="text" class="form-control" id="dateofbirth" value="" name="dateofbirth" placeholder="Date Of Birth" data-provide="datepicker" data-date-language="en" data-date-format="dd-mm-yy">
        <input type="text" name="homephone" id="homephone" maxlength="10" value=""class="form-control" placeholder="Home-Phone No." />

        <input type="button" name="previous" class="previous action-button" value="Previous" />
        <input type="button" name="next" class="next action-button" value="Next" />
    </fieldset>



    <fieldset>
        <h2 class="fs-title">Employee Details</h2>
        {{--<h3 class="fs-subtitle">We will never sell it</h3>--}}
        <input type="text" name="employeenumber" id="employeenumber" value="" class="form-control" placeholder="Payroll No." />
        <select class="form-control" id="employeetype" name="employeetype" value="Enter Employee Type">
            <option value="0">Select Employee Type</option>
            <option value="Permanent">Permanent</option>
            <option value="Temporary">Temporary</option>
            <option value="Contractual">Contractual-Through Agency</option>
        </select>
        <br>

        <select class="form-control" id="businesscategory" name="businesscategory" value="">
            <option value="Select a Value">Select employee Category</option>
            <option value="Technical">Scientific/Technical Officers</option>
<!--             <option value="Scientific">Scientific- For Scientists</option> -->
            <option value="Administration">Administration</option>
            <option value="Student">Student/Interns/Trainee</option>
            <option value="Scholar">Scholar/PDF</option>
            <option value="Trainee">Project-Staff</option>
	    <option value="Trainee">Contractual-Through Agency?</option>
        </select>
        <br>

        <input type="text" name="manager" id="manager" value=""class="form-control" placeholder="Division/Section/Project Leader" />
        <select class="form-control" id="organization" name="organization" value="">
            <option value="Select a Value">Select Organization</option>
            <option value="IPR">IPR</option>
            <option value="CPP">CPP</option>
            <option value="FCIPT">FCIPT</option>
            <option value="ITER-India">ITER-India</option>
        </select>
        <input type="text" name="organizationalunit" id="organizationalunit" value=""class="form-control" placeholder="Department" />
        <input type="text" class="form-control" value="" id="dateofjoining" name="dateofjoining" placeholder="Date Of Joining" data-provide="datepicker" data-date-language="en" data-date-format="dd-mm-yy" >
        <input type="text" class="form-control" value="" id="dateofcompletion" name="dateofcompletion"  placeholder="Date Of Completion" data-provide="datepicker" data-date-language="en"data-date-format="dd-mm-yy">
        <input type="text" name="officeroomnumber" id="officeroomnumber" value=""class="form-control" placeholder="Room Number" />
        <input type="text" name="extensionnumber" id="extensionnumber" value=""class="form-control" placeholder="Extention Number" />
        <input type="button" name="previous" class="previous action-button" value="Previous" />
        <input type="submit" name="submit" class="submit action-button" value="Submit" />
    </fieldset>

</form>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>



<script  src="{{ asset('js/index.js') }}"></script>




</body>

</html>
