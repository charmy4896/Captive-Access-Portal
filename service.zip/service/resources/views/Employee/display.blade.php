@extends('layouts.display_main')



@section('content')

   

    <div class="row">

        <div class="col-md-2 hidden-xs"></div>


        <div class="display col-md-8 col-xs-12">

            @include('flash-message')


            {{ Session::forget('success') }}

            {{ Session::forget('error') }}

            @if(Session::has('profile_upload'))

                <p class="bg-success"> {{ session('profile_upload') }}</p>

                {{ Session::forget('profile_upload') }}



            @endif




                <img src="{{ asset('/images/DAE.gif') }}" alt="Not Available" class="center-block" width ="200px" height = "200px">



        </div>
    </div>


    @endsection