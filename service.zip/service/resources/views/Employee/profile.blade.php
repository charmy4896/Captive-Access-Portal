@extends('layouts.display_main')


@section('content')

    <div class="row">
        <div class="col-md-2 hidden-xs"></div>
        <div class="display col-md-8 col-xs-12">


            <div class="panel panel-info">
                <div class="panel-heading text-center">
                    <p class="panel-title">
                        <i class="fa fa-fw fa-user"></i>

                        {{ $user_attributes['username']}}
                    </p>
                </div>

                <div class="panel-body">

                    <img src="{{ route('jpegphoto',$user_attributes['username']) }}" alt="" class="center-block" width ="300px" height = "300px">

                    <div class="table-responsive">
                        <table class="table table-striped table-hover">

                            @foreach($user_attributes['info'] as $key => $value)
                        <tr>
                            <th>
                                <em class="fa fa-{{ $value['faclass'] }}"></em>
                            </th>
                            <th class="hidden-xs">
                                {{ $key }}
                            </th>
                            <td>
                                {{ $value['value'] }}
                            </td>

                        </tr>

                                @endforeach

                        </table>
                    </div>


                    </div>

            </div>
        </div>
    </div>

    @endsection