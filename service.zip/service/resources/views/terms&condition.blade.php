<strong>Preamble</strong><br>

<br><p>The Institute for Plasma Research (IPR) is a premier national level research institute. The IPR community consists of about 1000 staff memberswith students and contract /project staff. Members of this community have access to desktop /laptop systems that are connected to the campus network. The campus network is connected to the Internet via leased circuits from several ISP (Internet Service Providers). In this way Internet access, email and other Internet services are made available across the campus to all the users.</p>

<p>Internet access is an essential resource for an academic campus. Academic users expect a certain level of performance and availability. On the other hand, Internet access is a limited and expensive resource, and can easily be congested by uncontrolled and arbitrary usage. In addition, there are certain legal issues that arise when connecting the private network of a national level research institute to the public Internet. It is because of such reasons that it has been felt necessary to develop an Internet Usage Policy.</p>

<br><br><strong>General Guidelines</strong>

<br><br><p>The IPR community should be aware that several Internet usage issues are covered by the Indian IT Act 2000-2008 (Amendment), violation of which is an offense under national law</p>

<p>1.    The IPR campus network and Internet access resources are meant for official use arising from the academic / technical activities and administrative responsibilities of the faculty, staff and students of the Institute. Use of network resources for personal purposes is discouraged.</p>

<p>2.    The IPR community should view the network resources with a sense of ownership and participation, and should actively help to prevent and to interdict any misuse. Procedures laid down, from time to time, regarding the management of network resources, must be understood and followed meticulously by the user community.</p>

<p>3.    The IPR network management reserves the right to scan all information carried by the network for the purpose of detecting and identifying inappropriate use. However, such scanning will be done only on approval by a competent authority. This is in concordance with the Indian IT Act 2000.</p>

<p>4.    The IPR community is expected to be aware of the contents of this policy document, and agrees to abide by its provisions.</p>

<p>5.    IPR has an IT Security committee that looks into all violations of this policy, and can recommendappropriate action(s) to the authorities. This committee is also the cyber crisis management committee.</p>

<p>6.    Use of IPR IT resources and services for any unlawful activity is strictly prohibited.</p>

<p>7.    Users should make their password strong for accessing IT services. Password must contain at least one special character and one number character. Password length must not be less than 8 character. User must change their password at least every 6 months.</p>



<br><br><strong>Scope</strong>

<br><br><p>This policy applies to the use of information, electronic and computing devices, and network

    resources interact with internal networks and business systems, whether owned or leased by  IPR , the employee, or a third party employees, contract, consultants, temporary, and other workers at IPR and its subsidiaries are responsible for exercising good judgment regarding appropriate use of information, electronic devices, and network resources in accordance with IPR policies and standards, and local laws and regulation</p>

<br><br><strong>Policy</strong>

<br><br><strong>1.  Appropriate Use:</strong>

<br><br><p>a.  The IPR campus network and Internet access will not be used for commercial activity, personal advertisement, solicitations, or promotions, such as hosting of commercial websites, or email broadcasts of commercial promotions to the IPR community.</p>

<p>b.    As such, non IPR organizations (such as commercial outlets operating on the IPR campus) will not be connected to the IPR network, and cannot be a part of the IPR domain space (ipr.res.in).</p>

<p>c.     Ethical usage of internet bandwidth needs to be followed. Downloading of audio and video files, peer to peer file sharing is to be done strictly for official purposes.</p>

<p>d.    Access to sites that are banned under law or that are offensive or obscene is prohibited. This is also an offense under the Indian IT Act 2000.</p>

<p>e.    Use of the network to tamper with information on other computers, to deliberately spread harmful programs, to hack into and compromise other systems, or to cause damage of any kind using the internet, is prohibited, and is an offense under the Indian IT Act 2000. The user is liable for any civil losses caused, in addition to criminal prosecution under the Indian IT Act 2000. </p>

<br><br><strong>2.   Email Usage:</strong>

<br><br><p>a.  IPR official email service should be used for all official communications. It should not be used to subscribe to any social networking / e-commerce / irrelevant newsletters or other web sites which are not relevant to office work.</p>

<p>b.    Since email accumulates over time, and storage space is limited, the storage in email servers can overflow. Users must, therefore, regularly download their mails to their local machine and clean out their mail-boxes, failing which, the system managers may delete excess emails. </p>

<p>c.     Use of the email service to send fraudulent, threatening, anonymous or harassing emails is prohibited.</p>

<p>d.    Users must refrain from opening emails from unknown sources, especially attachments and should inform to Computer Center if they receive malicious emails.  </p>

<p>e.    Sharing of an email accounts as well as passwords is prohibited.</p>

<p>f.     All emails/messages/data (including attachment) sent through the IPR IT/email services are the sole responsibility of the account holder.</p>

<br><strong>3.   Use of only Licensed Software:</strong>

<br><br><p>a.  Software programs are covered by copyrights and a license is required for their use. Users must ensure that they have either a commercial or public license (as in the case of ‘free’ software) for any software they install on the systems that they are responsible for.</p>

<p>b.    Use and exchange of pirated software over the network and internet is strictly prohibited.</p>

<p>c.     The downloading and use of software that is not characterized as public domain or ‘free’ is prohibited. </p>

<br><strong>4.    System Protection:</strong>

<br><br><p>a.  Users access the network via desktop/laptop machines on the campus network. Users are responsible and accountable for the usage of the systems allocated to them.</p>

<p>b.    Since most system in IPR are not system administered, the user must take adequate and regular measures to prevent network misuse from computer systems that they are responsible for.</p>

<p>c.     Reasonable care should be taken to minimize the vulnerability of systems attached to the campus network. In particular, users must apply appropriate service packs and antivirus and client security solutions in their MS Windows machines, and necessary upgrades and OS patches for other systems, including mobile devices.Anti-virus updates will be provided by the CC.</p>

<br><strong>5.    Hosting Information on the IPR Network:</strong>

<br><br><p>a.  The hosting of web sites on systems attached to the campus network requires prior permission from the competent authority in the group / division / section where the site is hosted. </p>

<p>b.    A website hosted on the campus network will be linked to the IPR website only on approval by the competent authority.</p>

<p>c.     The hosting of websites that carry offensive or obscene material is prohibited. </p>

<p>d.    Individual webpage(s) of the faculty /Scientists / Research Scholars etc. need to be located within their group website. </p>



<br><strong>6. Appropriate Use of Electronic Information Resources:</strong>

<br><br><p>The Institute has acquired several commercial information resources (e.g., citation databases, electronic journals, and journal archives) that are connected to the campus network. Further, the Institute subscribes to several such resources available over the Internet. These resources are extremely valuable to the academic community, but their use is bound by certain contractual obligations. Users are responsible for having read and understood these contractual terms while accessing these resources over the network. Users can refer to the library web-site for related policies and instructions.  </p>



<br><strong>7. Enforcement:</strong>

<br><br><p>The violation of the above policy either intentionally or accidentally by any user will result in locking the account and the issue would be bought to the management notice for appropriate disciplinary action.</p>

<br>
