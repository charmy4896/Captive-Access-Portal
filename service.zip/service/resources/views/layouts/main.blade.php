<!DOCTYPE html>
<html lang="en">

<head>


    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">



    <link href="{{asset('css/app.css')}}" rel="stylesheet">

    {{--<link href="{{asset('css/libs.css')}}" rel="stylesheet">--}}

    <script rel="stylesheet" src="{{ asset('js/jquery.js') }}" ></script>

    <script rel="stylesheet" src="{{ asset('js/bootstrap.js') }}"></script>

    <script rel="stylesheet" src="{{ asset('js/jquery-ui.js') }}"></script>

    <link rel="stylesheet" href="{{ asset('css/jquery-ui.css') }}">

    <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">
    {{--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">--}}



    <style type="text/css">
        html, body {
            background: url({{ URL::asset('images/unsplash-clouds.jpeg')}}) no-repeat center fixed;
            {{--background: url({{ URL('/image/unsplash-clouds.jpeg')}}) no-repeat center fixed;--}}
            background-size: cover;

            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            /*background-image: url('images/background.jpg');*/
            background-repeat: no-repeat;
            background-attachment: fixed;
        //background-size: 100%;
            opacity: 0.9;
            filter:alpha(opacity=90);
        }
    </style>


    <script>
        $(document).ready(function() {
            $("#dateofbirth").datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                dateFormat: 'dd/mm/yy'
            });
        });
        $(document).ready(function() {
            $("#dateofjoining").datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                dateFormat: 'dd/mm/yy'
            });
        });
        $(document).ready(function() {
            $("#dateofcompletion").datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                dateFormat: 'dd/mm/yy'
            });
        });

    </script>

</head>

<body>
<div class="container">
    <div class="panel panel-success">
        <div class="panel-body" style="background-color: lightgray">
            <div class="navbar-wrapper">
                <div class="navbar navbar-default navbar-static-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header" >
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="{{ route('login') }}"><i class="fa fa-home"></i> Home</a>
                        </div>

                        <div class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-fw fa-th"></i> Request new Account <b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href= {{ route('employee.create') }}> Employee</a>
                                        </li>

                                        <li>
                                            <a href="{{ route('guest.create') }}">Guest</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="">
                                    <a href="{{ route('passwordResetEmail') }}"><i class="fa fa-envelope"></i> Reset Password using email</a>
                                </li>
                                <li class="">
                                    <a href="{{ route('getPasswordChangeView') }}"><i class="fa fa-lock"></i> Change Password</a>
                                </li>

                                <li class="">
                                    <a href="{{ route('getStatusView') }}"><i class="fa fa-mobile"></i>&nbsp Status</a>
                                </li>


                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <a href="#" alt="Home">
                <img src="{{ asset('/images/ipr-logo.png') }}" alt="Logo" class="logo img-responsive center-block" />
            </a>

            @yield('labels')

            @yield('content')

        </div>
    </div>
</div>





</body>

</html>

