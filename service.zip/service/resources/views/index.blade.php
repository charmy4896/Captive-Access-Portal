@extends('layouts.display_main')


@section('content')

    @include('flash-message')

    {{ Session::forget('error') }}

    @if($count != null)
    <div class="alert alert-success">{{ $count }} entries found</div>
    @endif

    <div class="row">
        @if($users != null)

            @foreach($users as $user)
                <div class="search-result col-sm-4 hvr-grow "  style="width:25%;height:40%">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <h3 class="panel-title text-center"><i class="fa fa-fw fa-user "></i>{{ $user->getCommonName() }}</h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-4">
                                    <img src="{{ route('jpegphoto',$user->getCommonName()) }}" alt="" class="img-responsive img-thumbnail center-block" width="100%" height="100%"/>
                                </div>
                                <div class="col-sm-8">
                                    <p class="emailtext">
                                        <i class="fa fa-fw fa-envelope"></i>
                                    <br>
                                        <a  href="#">{{ $user->getEmail() }}</a>
                                        <br>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer text-center">
                            <a href="{{ route('profile',$user->getCommonName()) }}" class="btn btn-info" role="button"><i class="fa fa-fw fa-id-card"></i> Display entry</a>
                        </div>
                    </div>
                </div>
            @endforeach


        @endif
    </div>


    @endsection