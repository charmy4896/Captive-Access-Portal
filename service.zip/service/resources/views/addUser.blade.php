<!DOCTYPE html>
<head>

    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

	<link href="{{ asset('css/libs.css') }}" rel="stylesheet">


<body>

<div class="container">

	<div class="panel panel-success">
		<div class="panel-body">

			<div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Fill up necessary details to Request a New account</p></div>

			<div class="alert alert-info">
				<form action="/user" method="post" class="form-horizontal">
					<div class="form-group">
						<label for="login" class="col-sm-4 control-label">Username<b style = 'font-size:150%;color:red'> *</b></label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user"></i></span>
								<input type="text" name="login" id="login" value="" class="form-control" placeholder="Username" onblur="myFunction()"/>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-4 control-label">Password<b style = 'font-size:150%;color:red'> *</b></label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" name="password" id="password" class="form-control" placeholder="Password" required/>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="confirmpassword" class="col-sm-4 control-label">Confirm Password<b style = 'font-size:150%;color:red'> *</b></label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" name="confirmpassword" id="confirmpassword" class="form-control" placeholder="Confirm Password" required/>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="firstname" class="col-sm-4 control-label">First name<b style = 'font-size:150%;color:red'> *</b></label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="firstname" id="firstname" value=""class="form-control" placeholder="First name" required/>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="lastname" class="col-sm-4 control-label">Last name<b style = 'font-size:150%;color:red'> *</b></label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="lastname" id="lastname" value=""class="form-control" placeholder="Last name" required/>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="mail" class="col-sm-4 control-label">Work E-Mail<b style = 'font-size:150%;color:red'> *</b></label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="mail" id="mail" value=""class="form-control" placeholder="Work E-Mail" required/>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="initials" class="col-sm-4 control-label">Initials<b style = 'font-size:150%;color:red'> *</b></label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<select class="form-control" id="initials" name="initials" value="">
									<option value="Mr.">Mr.</option>
									<option value="Ms.">Ms.</option>
									<option value="Mrs.">Mrs.</option>
									<option value="Prof.">Prof.</option>
									<option value="Dr.">Dr.</option>
								</select>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="emailaddress" class="col-sm-4 control-label">Alternate Email<b style = 'font-size:150%;color:red'> *</b></label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="emailaddress" id="emailaddress" value="" class="form-control" placeholder="Alternate Email" required/>
							</div>
						</div>
					</div>

					<!--<div class="form-group">
                        <label for="bankaccountnumber" class="col-sm-4 control-label">Bank Account Number</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="bankaccountnumber" id="bankaccountnumber" value=""class="form-control" placeholder="Bank Account Number" />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="aadharnumber" class="col-sm-4 control-label">Aadhar Card Number</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="aadharnumber" id="aadharnumber" value=""class="form-control" placeholder="Aadhar Card Number" />
                            </div>
                        </div>
                    </div>
                -->
					<div class="form-group">
						<label for="dateofbirth" class="col-sm-4 control-label">Date Of Birth</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" class="form-control" id="dateofbirth" value="" name="dateofbirth" data-provide="datepicker" data-date-language="en" data-date-format="dd-mm-yy">
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="mobile" class="col-sm-4 control-label">Mobile No.</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="mobile" id="mobile" maxlength="10" value="" class="form-control" placeholder="Mobile No."  required/>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="homephone" class="col-sm-4 control-label">Home-Phone No.</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="homephone" id="homephone" maxlength="10" value=""class="form-control" placeholder="Home-Phone No." />
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="employeenumber" class="col-sm-4 control-label">Payroll No.</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="employeenumber" id="employeenumber" value="" class="form-control" placeholder="Payroll No." />
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="employeetype" class="col-sm-4 control-label">Employee Type</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<select class="form-control" id="employeetype" name="employeetype" value="">
									<option value="0">Select a Value</option>
									<option value="Permanent">Permanent</option>
									<option value="Temporary">Temporary</option>
									<option value="Contractual">Contractual-Through Agency</option>
								</select>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="businesscategory" class="col-sm-4 control-label">Employee Category</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<select class="form-control" id="businesscategory" name="businesscategory" value="">
									<option value="Select a Value">Select a Value</option>
									<option value="Technical">Technical-For Engineers</option>
									<option value="Scientific">Scientific- For Scientists</option>
									<option value="Administration">Administration</option>
									<option value="Student">Student/Interns/Trainee</option>
									<option value="Scholar">Scholar/PDF</option>
									<option value="Trainee">Project-Staff</option>

								</select>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="manager" class="col-sm-4 control-label">Division/Section/Project Leader</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="manager" id="manager" value=""class="form-control" placeholder="Division/Section/Project Leader" />
							</div>
						</div>
					</div>



					<div class="form-group">
						<label for="organization" class="col-sm-4 control-label">Organization</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<select class="form-control" id="organization" name="organization" value="">
									<option value="Select a Value">Select a Value</option>
									<option value="IPR">IPR</option>
									<option value="CPP">CPP</option>
									<option value="FCIPT">FCIPT</option>
									<option value="ITER-India">ITER-India</option>
								</select>
							</div>
						</div>
					</div>



					<div class="form-group">
						<label for="organizationalunit" class="col-sm-4 control-label">Department</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="organizationalunit" id="organizationalunit" value=""class="form-control" placeholder="Department" />
							</div>
						</div>
					</div>

					<!-- <div class="form-group">
                         <label for="departmentnumber" class="col-sm-4 control-label">Department Number</label>
                         <div class="col-sm-8">
                             <div class="input-group">
                                 <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                 <input type="text" name="departmentnumber" id="departmentnumber" value="" class="form-control" placeholder="Department Number" />
                             </div>
                         </div>
                     </div>
                 -->
					<div class="form-group">
						<label for="dateofjoining" class="col-sm-4 control-label">Joining Date</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" class="form-control" value="" id="dateofjoining" name="dateofjoining" data-provide="datepicker" data-date-language="en" data-date-format="dd-mm-yy">
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="dateofcompletion" class="col-sm-4 control-label">Completion Date</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" class="form-control" value=""id="dateofcompletion" name="dateofcompletion" data-provide="datepicker" data-date-language="en"data-date-format="dd-mm-yy">
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="officeroomnumber" class="col-sm-4 control-label">Room Number</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="officeroomnumber" id="officeroomnumber" value=""class="form-control" placeholder="Room Number" />
							</div>
						</div>
					</div>

					<div class="form-group">
						<label for="extensionnumber" class="col-sm-4 control-label">Extention Number</label>
						<div class="col-sm-8">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="text" name="extensionnumber" id="extensionnumber" value=""class="form-control" placeholder="Extention Number" />
							</div>
						</div>
					</div>


					<div class="form-group">
						<div class="col-sm-offset-4 col-sm-8">
							<div class="g-recaptcha" data-sitekey="6LfL8RIUAAAAAPSe0pTdmngrPeekYUGQmO29HFhq" data-theme="light" data-type="image" data-size="normal"></div>
							<script type="auth/text/javascript" src="https://www.google.com/recaptcha/api.js?hl=en"></script>
						</div>
					</div>

					<div class="form-group">
						<div class="col-sm-offset-4 col-sm-8">
							<button type="submit" class="btn btn-success">
								<i class="fa fa-check-square-o"></i> Request new Account            </button>
						</div>
					</div>
				</form>
			</div>



			<script>
                function myFunction() {
                    var x = document.getElementById("login");
                    var y = document.getElementById("mail");
                    y.value = x.value.concat("@ipr.res.in");

                }
			</script>
			<script src="auth/jquery/jquery-ui.js"></script>
			<script type="text/javascript">

                $(function() {
                    $('#manager').keyup(function(){
                        var data=$('#manager').val();
                        $.ajax({
                            type:'POST',
                            url:'auth/pages/owners.php',
                            data:"data="+data,
                            dataType: "json",
                            success: function(msg){
                                var availableTags = msg;
                                $("#manager").autocomplete({
                                    source: availableTags
                                });
                            }
                        });

                    });
                });


			</script>

			<script type="text/javascript">

                $(function() {
                    $('#organizationalunit').keyup(function(){
                        var data=$('#organizationalunit').val();
                        $.ajax({
                            type:'POST',
                            url:'auth/pages/orggroups.php',
                            data:"data="+data,
                            dataType: "json",
                            success: function(msg){
                                var availableTags = msg;
                                $("#organizationalunit").autocomplete({
                                    source: availableTags
                                });
                            }
                        });

                    });
                });

			</script>
        </div>

		</div>
	</div>

</div>
</body>
</html>