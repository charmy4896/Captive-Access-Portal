<!doctype html>
<html lang="en">
<head>

</head>
<body>

<h2>{{ $txt }}</h2>

</body>
</html>