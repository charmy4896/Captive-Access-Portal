<!doctype html>
<html lang="en">
<head>

</head>
<body>

Welcome India!!!

{{ $name }}
</body>
</html>