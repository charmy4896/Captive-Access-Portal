@extends('layouts.main')



@section('labels')

    @include('flash-message')

    {{--{{ session::flush() }}--}}

    <div class="result alert alert-success">

    @if(Session::has('loginMsg'))

            <p><i class="fa fa-check-square" aria-hidden="true"></i>&nbsp{{ Session::get('loginMsg') }}</p>

        {{ session::forget('loginMsg') }}

        @else

            <p><i class="fa fa-check-square" aria-hidden="true"></i> Log In</p>


    @endif


    </div>

    <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Enter Your Username and Password to Log in.</p></div>

    @endsection

@section('content')
    <div class="alert alert-info" style="width: 40%; margin:0 auto;">

        <form action="{{ route('login') }}" method="POST" class="form-horizontal">
            {{csrf_field()}}
            <div class="form-group">
                <label for="login" class="col-sm-4 control-label">Username</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" name="login" id="login" value="" class="form-control" placeholder="Username" />
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="password" class="col-sm-4 control-label">Password</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Password" />
                    </div>
                </div>
            </div>



            <div class="form-group">

                <label for="captcha" class="col-sm-4 control-label">Captcha</label>

                <div class="col-sm-8">

                    <div class="col-sm-8">

                        <div class="form-group refereshrecapcha">

                            {!! captcha_img('flat') !!}

                        </div>

                    </div>

                    <div class="col-sm-4">

                        <button type="button" class="btn btn-success" onclick="Captcha_refresh()" ><i class="fa fa-refresh" style="font-size:12px"></i></button>

                    </div>

                    <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha Here"  required />


                </div>

            </div>


            {{ session::forget('success') }}

            {{ session::forget('error') }}


            {{--{{ Session::forget('captchaError') }}--}}




            <div class="form-group">
                <div class="col-sm-offset-4 col-sm-8">
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-check-square-o"></i> Login            </button>
                </div>
            </div>


        </form>
    </div>

    <script type="text/javascript">

        function Captcha_refresh() {

            $.ajax({

                url: '{{ route('refreshCaptcha') }}',

                type: 'get',

                dataType: 'html',

                success: function(json) {

                    $('.refereshrecapcha').html(json);

                },

            });

        }


    </script>

@endsection
