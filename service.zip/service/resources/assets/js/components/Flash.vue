<template>

    <div class="alert alert-success" role="alert" v-show="show">
        {{ body}}
    </div>
</template>

<script>
    export default {

        props: ['message'],

        data()  {
            return {
                body: '',
                show: false,
            }
        },

        created() {
            if (this.message) {
                this.flash(this.message);
            }
        },

        methods: {
            flash(message) {
                this.body = message;
                this.show = true;

                this.hide();
            },

            hide() {
                setTimeout(() => {
                    this.show = false;
                }, 3000);
            }
        }
    }
</script>


<style>

    .alert-style {
        position: fixed;
        right: 25px;
        bottom: 25px;
    }

    .slide-fade-enter-active {
        transition: all .3s ease;
    }
    .slide-fade-leave-active {
        transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
    }
    .slide-fade-enter, .slide-fade-leave-to
        /* .slide-fade-leave-active below version 2.1.8 */ {
        transform: translateX(10px);
        opacity: 0;
    }



</style>

