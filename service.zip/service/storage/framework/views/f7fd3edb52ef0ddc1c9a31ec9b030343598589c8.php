        

        <?php $__env->startSection('labels'); ?>



            <div class="result alert alert-success">
                <p><i class="fa fa-check-square" aria-hidden="true"></i> Register a new account</p>
            </div>


            <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Fill up necessary details to Request a New account</p>
            </div>


            <?php $__env->stopSection(); ?>

        <?php $__env->startSection('content'); ?>
            <div class="alert alert-info">

                <form action="<?php echo e(route('employee.store')); ?>" method="post" class="form-horizontal">

                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="login" class="col-sm-4 control-label">Username<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" name="login" id="login" value="" class="form-control " placeholder="Username" onblur="checkAvailability()"/>

                            </div>
                        </div>
                        <span id="user-availability-status" style="color: red"></span>
                    </div>

                    
                        
                        
                            
                                
                                
                            

                            
                                

                                    
                                    

                            
                        
                    

                    
                        
                        
                            
                                
                                
                            
                            
                                

                                    
                                    

                                

                        
                    

                    <div class="form-group">
                        <label for="firstname" class="col-sm-4 control-label">First name<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="firstname" id="firstname" value=""class="form-control" placeholder="First name" required/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="lastname" class="col-sm-4 control-label">Last name<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="lastname" id="lastname" value=""class="form-control" placeholder="Last name" required/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="mail" class="col-sm-4 control-label">Work E-Mail<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="mail" id="mail" value=""class="form-control" placeholder="Work E-Mail" required/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="initials" class="col-sm-4 control-label">Initials<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <select class="form-control" id="initials" name="initials" value="">
                                    <option value="Mr.">Mr.</option>
                                    <option value="Ms.">Ms.</option>
                                    <option value="Mrs.">Mrs.</option>
                                    <option value="Prof.">Prof.</option>
                                    <option value="Dr.">Dr.</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="emailaddress" class="col-sm-4 control-label">Alternate Email<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="emailaddress" id="emailaddress" value="" class="form-control" placeholder="Alternate Email" required/>
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="dateofbirth" class="col-sm-4 control-label">Date Of Birth</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" class="form-control" id="dateofbirth" value="" name="dateofbirth"  data-date-format="dd-mm-yy">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="mobile" class="col-sm-4 control-label">Mobile No.</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="mobile" id="mobile" maxlength="10" value="" class="form-control" placeholder="Mobile No."  required/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="homephone" class="col-sm-4 control-label">Home-Phone No.</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="homephone" id="homephone" maxlength="10" value=""class="form-control" placeholder="Home-Phone No." />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="employeenumber" class="col-sm-4 control-label">Payroll No.</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="employeenumber" id="employeenumber" value="" class="form-control" placeholder="Payroll No." />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="employeetype" class="col-sm-4 control-label">Employee Type</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <select class="form-control" id="employeetype" name="employeetype" value="">
                                    <option value="0">Select a Value</option>
                                    <option value="Permanent">Permanent</option>
                                    <option value="Temporary">Temporary</option>
                                    <option value="Contractual">Contractual-Through Agency</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="businesscategory" class="col-sm-4 control-label">Employee Category</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <select class="form-control" id="businesscategory" name="businesscategory" value="">
                                    <option value="Select a Value">Select a Value</option>
                                    <option value="Technical">Technical-For Engineers</option>
                                    <option value="Scientific">Scientific- For Scientists</option>
                                    <option value="Administration">Administration</option>
                                    <option value="Student">Student/Interns/Trainee</option>
                                    <option value="Scholar">Scholar/PDF</option>
                                    <option value="Trainee">Project-Staff</option>

                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="manager" class="col-sm-4 control-label">Division/Section/Project Leader</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="manager" id="manager" value=""class="form-control" placeholder="Division/Section/Project Leader" />
                            </div>
                        </div>
                    </div>



                    <div class="form-group">
                        <label for="organization" class="col-sm-4 control-label">Organization</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <select class="form-control" id="organization" name="organization" value="">
                                    <option value="Select a Value">Select a Value</option>
                                    <option value="IPR">IPR</option>
                                    <option value="CPP">CPP</option>
                                    <option value="FCIPT">FCIPT</option>
                                    <option value="ITER-India">ITER-India</option>
                                </select>
                            </div>
                        </div>
                    </div>



                    <div class="form-group">
                        <label for="organizationalunit" class="col-sm-4 control-label">Department</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="organizationalunit" id="organizationalunit" value=""class="form-control" placeholder="Department" />
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="dateofjoining" class="col-sm-4 control-label">Joining Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" class="form-control" value="" id="dateofjoining" name="dateofjoining" data-provide="datepicker" data-date-language="en" data-date-format="dd-mm-yy">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="dateofcompletion" class="col-sm-4 control-label">Completion Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" class="form-control" value=""id="dateofcompletion" name="dateofcompletion" data-provide="datepicker" data-date-language="en"data-date-format="dd-mm-yy">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="officeroomnumber" class="col-sm-4 control-label">Room Number</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="officeroomnumber" id="officeroomnumber" value=""class="form-control" placeholder="Room Number" />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="extensionnumber" class="col-sm-4 control-label">Extention Number</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="extensionnumber" id="extensionnumber" value=""class="form-control" placeholder="Extention Number" />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
                            <button type="submit" class="btn btn-success">
                                <i class="fa fa-check-square-o"></i> Request new Account</button>
                        </div>
                    </div>
                </form>
            </div>
        <?php $__env->stopSection(); ?>


        <script>
            function checkAvailability() {

                jQuery.ajax({
                    url: "http://localhost:8000/check_username_unique/".concat($("#login").val()),
                    // data:'username='+$("#login").val(),
                    type: "get",
                    success:function(data){

                        if(data == 'true'){
                            $("#user-availability-status").html('&nbsp &nbsp username already exists');
                        }else{
                            $("#user-availability-status").html('  ');

                        }

                    },
                    error:function (){}
                });

            }


        </script>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>