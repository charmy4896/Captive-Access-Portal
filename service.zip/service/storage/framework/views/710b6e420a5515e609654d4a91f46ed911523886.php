<?php $__env->startSection('content'); ?>


    <script src="<?php echo e(asset('DataTable/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/bootstrap.min.css')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.css')); ?>"></script>


    <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo e(Session::forget('success')); ?>


    <?php echo e(Session::forget('error')); ?>


    
    

    <div class="result alert alert-success">
        <p>
            <b>
                USER CC HEAD APPROVAL
            </b>
        </p>
    </div>


    <div class="col-md-12">

        <div class="panel panel-default panel-table">

            <div class="panel-body">

                <table id="mytable" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th scope="col">User Id</th>
                        <th scope="col">Payroll</th>
                        <th scope="col">Head Id</th>
                        <th scope="col">Head Status</th>
                        <th>Request Date</th>
                        <th>Division Approval</th>
                        <th>Head Remarks</th>
                        <th>CC Head Approval Date</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php if($pendingRequest != null): ?>

                        <?php $__currentLoopData = $pendingRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>


                                <td ><?php echo e($info->user_id); ?></td>
                                <td ><?php echo e($info->payroll_no); ?></td>
                                <td ><?php echo e($info->div_head_id); ?></td>
                                <td ><?php echo e($info->div_head_status); ?></td>

                                <td>
                                    <?php echo e($info->request_date); ?>

                                </td>

                                <td>
                                    <?php if($info->div_approval_date != null): ?>
                                        <?php echo e($info->div_approval_date); ?>

                                    <?php endif; ?>

                                </td>
                                <td>
                                    <?php if( $info->remarks  != null): ?>

                                        <?php echo e($info->remarks); ?>


                                        <?php endif; ?>


                                </td>
                                <td>
                                    <?php if($info->cc_head_approval_date != null): ?>

                                        <?php echo e($info->cc_head_approval_date); ?>


                                    <?php endif; ?>

                                </td>
                                <td>


                                    <button  id="approve" name="submit" class="btn btn-primary" onclick="approve( '<?php echo e($info->user_id); ?>' );" >Yes</button>

                                    <button  id="disapprove" name="submit" class="btn btn-danger" onclick="disapprove('<?php echo e($info->user_id); ?>')">No</button>


                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>


                    <?php if($otherRequest != null): ?>

                        <?php $__currentLoopData = $otherRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td ><?php echo e($info->user_id); ?></td>

                                <td ><?php echo e($info->payroll_no); ?></td>

                                <td ><?php echo e($info->div_head_id); ?></td>

                                <td ><?php echo e($info->div_head_status); ?></td>

                                <td>
                                    <?php echo e($info->request_date); ?>

                                </td>
                                <td>
                                    <?php if($info->div_approval_date != null): ?>
                                        <?php echo e($info->div_approval_date); ?>

                                    <?php endif; ?>

                                </td>

                                <td>
                                    <?php if( $info->remarks  != null): ?>

                                        <?php echo e($info->remarks); ?>


                                    <?php endif; ?>


                                </td>


                                <td>
                                    <?php if($info->cc_head_approval_date != null): ?>

                                        <?php echo e($info->cc_head_approval_date); ?>


                                    <?php endif; ?>
                                </td>
                                <td>

                                    <?php echo e($info->cc_head_approval_status); ?>




                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <script type="text/javascript">



        function approve( user_id) {



            jQuery.ajax({

                type :'POST',

                url: '<?php echo e(route('CCHeadApproval')); ?>',

                data : {_token: '<?php echo e(csrf_token()); ?>', user_id: user_id },

                success:  function (data) {

                    console.log(data);

                    if(data == 'true'){
                        alert('User request Approved');

                        window.location.reload();

                    }else{
                        alert('Error While Approving');
                        window.location.reload();
                    }

                }


            });
        }

        function disapprove(user_id) {


            jQuery.ajax({

                type :'POST',

                url: '<?php echo e(route('CCHeadDisApproval')); ?>',

                data : {_token: '<?php echo e(csrf_token()); ?>', user_id: user_id },

                success:  function (data) {

                    console.log(data);

                    if(data == 'true'){
                        alert('User request DisApproved');
                        window.location.reload();

                    }else{
                        alert('Error While DisApproving');
                        window.location.reload();

                    }

                }


            });
        }



    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
        } );

    </script>

    <style>
        .panel-table .panel-body{
            padding:0;
        }

        .panel-table .panel-body .table-bordered{
            border-style: none;
            margin:0;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type {
            text-align:center;
            width: 100px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:last-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:last-of-type {
            border-right: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:first-of-type {
            border-left: 0px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr:first-of-type > td{
            border-bottom: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr:first-of-type > th{
            border-top: 0px;
        }

        .panel-table .panel-footer .pagination{
            margin:0;
        }


        /*
        used to vertically center elements, may need modification if you're not using default sizes.
        */
        .panel-table .panel-footer .col{
            line-height: 34px;
            height: 34px;
        }

        .panel-table .panel-heading .col h3{
            line-height: 30px;
            height: 30px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr > td{
            line-height: 30px;
        }
        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 10px;
        }


    </style>

<?php $__env->stopSection(); ?>



<?php echo $__env->make( Session::has('admin_username') ? 'index.Admin.index'  : 'layouts.display_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>