<!doctype html>
<html lang="en">
<head>

</head>
<body>
<h3>Click Here to Reset your password :


    <?php echo e(route('PasswordResetEmail',$username)); ?>



</h3>




</body>
</html>