<!doctype html>
<html lang="en">
<head>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    

    


    <script rel="stylesheet" src="<?php echo e(asset('js/jquery.js')); ?>" ></script>

    <script rel="stylesheet" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>

    <script rel="stylesheet" src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>

    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">

    


    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">



    <style type="text/css">
        html,body {
            background: url(<?php echo e(URL::asset('images/unsplash-clouds.jpeg')); ?>) no-repeat center fixed;
            background-size: cover;

            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            /*background-image: url('images/background.jpg');*/
            background-repeat: no-repeat;
            background-attachment: fixed;
        //background-size: 100%;
            opacity: 0.9;
            filter:alpha(opacity=90);

        }
    </style>

</head>
<body id="background">

<div class="container" id="container">

    <div class="panel panel-success">
        <div class="panel-body">
            <div class="navbar-wrapper">

                <div class="navbar navbar-default navbar-static-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-form navbar-left">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="<?php echo e(route('Admin.index')); ?>"><i class="fa fa-home"></i>Home</a>
                        </div>

                        <div class="navbar-form navbar-right ">
                            <ul class="nav navbar-nav">
                                <li class="navbar">
                                    <a href="<?php echo e(route('logviewer')); ?>"><i class="fa fa-fw fa-th"></i>Log Viewer</a>
                                </li>
                                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-fw fa-th"></i> <?php echo e(getHeading('users')); ?><b class="caret"></b></a>



                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('getAllUsers')); ?>"><?php echo e(getHeading('all')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('getLockedUsers')); ?>"><?php echo e(getHeading('locked')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('getUnLockedUsers')); ?>"><?php echo e(getHeading('unlocked')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('getGuests')); ?>"><?php echo e(getHeading('guest')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin_password_change_view')); ?>"><?php echo e(getHeading('changepassword')); ?></a>
                                        </li>
                                    </ul>

                                </li>
                                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-fw fa-th"></i> <?php echo e(getHeading('groups')); ?><b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('OrgGroupsView')); ?>"><?php echo e(getHeading('orggroups')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('SecurityGroupNames')); ?>"><?php echo e(getHeading('hbac')); ?></a>
                                        </li>
                                    </ul>
                                </li>

                                

                                    
                                        
                                    

                                

                                

                                    
                                        
                                    

                                


                                <?php if(Session::get('ismember') == 'true' or Session::get('cc_head') == 'true'  ): ?>


                                        <ul class="nav navbar-nav">

                                            <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                                    <i class="fa fa-fw fa-th"></i> Manage Users Request <b class="caret"></b></a>

                                                <ul class="dropdown-menu">

                                                    <?php if(Session::get('ismember') == 'true'): ?>

                                                        <li class="navbar">
                                                            <a href="<?php echo e(route('divHeadApprovalView')); ?>"><i class="fa fa-fw fa-th"></i>User Request Approval</a>
                                                        </li>

                                                    <?php endif; ?>

                                                    <?php if(Session::get('cc_head') == 'true'): ?>

                                                        <li class="navbar">
                                                            <a href="<?php echo e(route('CCHeadApprovalView')); ?>"><i class="fa fa-fw fa-th"></i> CC Head Approval</a>
                                                        </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </li>

                                        </ul>


                                <?php endif; ?>

                                
                                    
                                

                                <li class="navbar">
                                    <a href="<?php echo e(route('deadline')); ?>"><i class="fa fa-fw fa-th"></i>Deadline</a>
                                </li>


                                <li class="navbar-right">
                                    <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-th"></i>Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>


</div>


</body>
</html>