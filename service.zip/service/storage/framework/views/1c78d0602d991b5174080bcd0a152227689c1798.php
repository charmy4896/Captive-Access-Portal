<?php $__env->startSection('content'); ?>


    Welcome to Admin Home


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>