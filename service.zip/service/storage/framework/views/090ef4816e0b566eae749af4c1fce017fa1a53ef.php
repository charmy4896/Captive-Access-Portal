<?php $__env->startSection('content'); ?>



    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <form class="form-horizontal" method="POST" action="<?php echo e(route('profileupdate')); ?>">

        <?php echo e(csrf_field()); ?>


        <div class="form-group">
            <label for="initials" class="col-sm-3 control-label">
                Initials <b style = 'font-size:150%;color:red'> *</b>

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-user"></i></span>

                    <select class="form-control" id="initials" name="initials" placeholder="Initials">
                        <option value="<?php echo e($user->getInitials()); ?>"> <?php echo e($user->getInitials()); ?></option>
                        <option value="Mr.">Mr.</option>
                        <option value="Mrs.">Mrs.</option>
                        <option value="Prof.">Prof.</option>
                        <option value="Dr.">Dr.</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="firstname" class="col-sm-3 control-label">
                First name <b style = 'font-size:150%;color:red'> *</b>

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-user"></i></span>

                    <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo e($user->getFirstName()); ?>" >

                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="lastname" class="col-sm-3 control-label">
                Last name <b style = 'font-size:150%;color:red'> *</b>

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-user"></i></span>

                    <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo e($user->getLastName()); ?>" >

                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="mail" class="col-sm-3 control-label">
                IPR E-Mail <b style = 'font-size:150%;color:red'> *</b>

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-envelope"></i></span>

                    <input type="text" class="form-control" id="mail" name="mail" value="<?php echo e($user->getEmail()); ?>" >

                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="emailaddress" class="col-sm-3 control-label">
                Alternate Email <b style = 'font-size:150%;color:red'> *</b>

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-envelope"></i></span>

                    <input type="text" class="form-control" id="emailaddress" name="emailaddress" value="<?php echo e($user->getEmailAddress()); ?>" >

                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="employeenumber" class="col-sm-3 control-label">
                Payroll number

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-hashtag"></i></span>

                    <input type="text" class="form-control" id="employeenumber"  name="employeenumber" value="<?php echo e($user->getEmployeeNumber()); ?>" >

                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="employeetype" class="col-sm-3 control-label">
                Employee type
            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-id-badge"></i></span>
                    <select class="form-control" id="employeetype" name="employeetype">
                        <option value="<?php echo e($user->getEmployeeType()[0]); ?>"><?php echo e($user->getEmployeeType()[0]); ?> </option>
                        <option value="Permanent" >Permanent</option>
                        <option value="Temporary" >Temporary</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="businesscategory" class="col-sm-3 control-label">
                Employee category

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-briefcase"></i></span>
                    <select class="form-control" id="businesscategory" name="businesscategory" >
                        <option value="<?php echo e($user->getBusinessCategory()); ?>"><?php echo e($user->getBusinessCategory()); ?></option>
                        <option value="Technical" >Technical</option>
                        <option value="Scientific" >Scientific</option>option>
                        <option value="Administration">Administration</option>
                        <option value="Consultant">Consultant</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="manager" class="col-sm-3 control-label">
                Division/Section/Project Leader

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-user-circle"></i></span>

                    <input type="text" class="form-control" id="manager" name="manager" value="" >


                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="organization" class="col-sm-3 control-label">
                Organization

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-building"></i></span>
                    <select class="form-control" id="organization" name="organization" placeholder="<?php echo e($user->getOrganizationName()); ?>" >
                        <option value="<?php echo e($user->getOrganizationName()); ?>"><?php echo e($user->getOrganizationName()); ?></option>
                        <option value="IPR" >IPR</option>
                        <option value="CPP" >CPP</option>
                    </select>

                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="organizationalunit" class="col-sm-3 control-label">
                Department

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-building"></i></span>

                    <input type="text" class="form-control" id="organizationalunit"  name="organizationalunit" value="<?php echo e($user->getOrganizationalUnit()); ?>" >

                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="dateofjoining" class="col-sm-3 control-label">
                Joining Date

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-calendar"></i></span>

                    <input type="text" class="form-control" id="dateofjoining" name="dateofjoining" value="<?php echo e($user->getJoiningDate()[0]); ?>">
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="dateofcompletion" class="col-sm-3 control-label">
                Completion Date

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-calendar"></i></span>

                    <input type="text" class="form-control" id="dateofcompletion" name="dateofcompletion" value="<?php echo e($user->getDateOfCompletion()); ?>">
                </div>
            </div>
        </div>


        <div class="form-group">
            <label for="dateofbirth" class="col-sm-3 control-label">
                Date Of Birth

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-calendar"></i></span>

                    <input type="text" class="form-control" id="dateofbirth" name="dateofbirth" value="<?php echo e($user->getBirthOfDate()); ?>" >
                </div>
            </div>
        </div>

        <script>

            $(document).ready(function() {
                $("#dateofbirth").datepicker();
            });
            $(document).ready(function() {
                $("#dateofjoining").datepicker();
            });
            $(document).ready(function() {
                $("#dateofcompletion").datepicker();
            });

        </script>


        <div class="form-group">
            <label for="mobile" class="col-sm-3 control-label">
                Mobile

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-mobile"></i></span>

                    <input type="text" class="form-control" id="mobile" maxlength="10" name="mobile" value="<?php echo e($user->getMobile()[0]); ?>">

                </div>
            </div>
        </div>


        <div class="form-group">
            <label for="homephone" class="col-sm-3 control-label">
                homephone

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-phone"></i></span>

                    <input type="text" class="form-control" id="homephone" maxlength="10" name="homephone" value="<?php echo e($user->getHomePhone()); ?>">

                </div>
            </div>
        </div>


        <div class="form-group">
            <label for="officeroomnumber" class="col-sm-3 control-label">
                Room Number

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-building"></i></span>

                    <input type="text" class="form-control" id="officeroomnumber"  name="officeroomnumber" value="<?php echo e($user->getRoomNumber()); ?>">

                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="extensionnumber" class="col-sm-3 control-label">
                Extention Number

            </label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-fw fa-phone"></i></span>

                    <input type="text" class="form-control" id="extensionnumber"  name="extensionnumber" value="<?php echo e($user->getTelephoneNumber()); ?>">

                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-1">
                <button type="submit" name="submit" class="btn btn-success"> Save Profile</button>
            </div>
        </div>
    </form>
    <form  class="form-horizontal" method="GET" action="<?php echo e(route('home.index')); ?>">
        <div class="form-group">
            <input type = "hidden" name= "cancel" value="cancel">
            <div class="col-sm-offset-3 col-sm-1">
                <button type="submit" name="submit" class="btn btn-success"> Cancel </button>
            </div>
        </div>
    </form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>