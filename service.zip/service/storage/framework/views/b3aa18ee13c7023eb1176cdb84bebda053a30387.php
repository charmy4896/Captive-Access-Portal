<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo e(Session::forget('error')); ?>


    <?php if($count != null): ?>
    <div class="alert alert-success"><?php echo e($count); ?> entries found</div>
    <?php endif; ?>

    <div class="row">
        <?php if($users != null): ?>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="search-result col-sm-4 hvr-grow "  style="width:25%;height:40%">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <h3 class="panel-title text-center"><i class="fa fa-fw fa-user "></i><?php echo e($user->getCommonName()); ?></h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-4">
                                    <img src="<?php echo e(route('jpegphoto',$user->getCommonName())); ?>" alt="" class="img-responsive img-thumbnail center-block" width="100%" height="100%"/>
                                </div>
                                <div class="col-sm-8">
                                    <p class="emailtext">
                                        <i class="fa fa-fw fa-envelope"></i>
                                    <br>
                                        <a  href="#"><?php echo e($user->getEmail()); ?></a>
                                        <br>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer text-center">
                            <a href="<?php echo e(route('profile',$user->getCommonName())); ?>" class="btn btn-info" role="button"><i class="fa fa-fw fa-id-card"></i> Display entry</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <?php endif; ?>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.display_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>