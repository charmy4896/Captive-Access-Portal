<!DOCTYPE html>
<html lang="en">

<head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <script href="bower_components/bootpag/lib/jquery.bootpag.min.js"></script>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/libs.css')); ?>" rel="stylesheet">


    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>

    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">

    <script>

        $(document).ready(function() {
            $("#dateofbirth").datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                dateFormat: 'dd/mm/yy'
            });
        });
        $(document).ready(function() {
            $("#dateofjoining").datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                dateFormat: 'dd/mm/yy'
            });
        });
        $(document).ready(function() {
            $("#dateofcompletion").datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                dateFormat: 'dd/mm/yy'
            });
        });


    </script>

</head>

<body>
<div class="container">
    <div class="panel panel-success">
        <div class="panel-body" style="background-color: lightgray">
            <div class="navbar-wrapper">
                <div class="navbar navbar-default navbar-static-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header" >
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="<?php echo e(route('login')); ?>"><i class="fa fa-home"></i> Home</a>
                        </div>

                        <div class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-fw fa-th"></i> Request new Account <b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href= <?php echo e(route('employee.create')); ?>> Employee</a>
                                        </li>

                                        <li>
                                            <a href="<?php echo e(route('guest.create')); ?>">Guest</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="">
                                    <a href="#"><i class="fa fa-envelope"></i> Reset Password using email</a>
                                </li>
                                <li class="">
                                    <a href="<?php echo e(route('getPasswordChangeView')); ?>"><i class="fa fa-mobile"></i> Change Password</a>
                                </li>

                                <li class="">
                                    <a href="<?php echo e(route('getStatusView')); ?>"><i class="fa fa-mobile"></i>&nbsp Status</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <a href="#" alt="Home">
                <img src="<?php echo e(asset('/images/ipr-logo.png')); ?>" alt="Logo" class="logo img-responsive center-block" />
            </a>

            <?php echo $__env->yieldContent('labels'); ?>

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
</div>





</body>

</html>

