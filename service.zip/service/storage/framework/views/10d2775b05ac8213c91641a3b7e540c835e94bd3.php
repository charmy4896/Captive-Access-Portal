<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>



    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>




    <script href="bower_components/bootpag/lib/jquery.bootpag.min.js"></script>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/libs.css')); ?>" rel="stylesheet">


    <script href="bower_components/datatables.net/js/dataTables.bootstrap.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>

    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">





</head>
<body >

<div class="container" id="container">


    <div class="panel panel-success">
        <div class="panel-body">
            <div class="navbar-wrapper">

                <div class="navbar navbar-default navbar-static-top" role="navigation">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="<?php echo e(route('Admin.index')); ?>"><i class="fa fa-home"></i>Home</a>
                        </div>

                        <div class="navbar-form navbar-right">
                            <ul class="nav navbar-nav">
                                <li class="navbar">
                                    <a href="<?php echo e(route('logviewer')); ?>"><i class="fa fa-fw fa-th"></i>Log Viewer</a>
                                </li>
                                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-fw fa-th"></i> <?php echo e(getHeading('users')); ?><b class="caret"></b></a>



                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('getAllUsers')); ?>"><?php echo e(getHeading('all')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('getLockedUsers')); ?>"><?php echo e(getHeading('locked')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('getUnLockedUsers')); ?>"><?php echo e(getHeading('unlocked')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('getGuests')); ?>"><?php echo e(getHeading('guest')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin_password_change_view')); ?>"><?php echo e(getHeading('changepassword')); ?></a>
                                        </li>
                                    </ul>

                                </li>
                                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-fw fa-th"></i> <?php echo e(getHeading('groups')); ?><b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('OrgGroupsView')); ?>"><?php echo e(getHeading('orggroups')); ?></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('SecurityGroupNames')); ?>"><?php echo e(getHeading('hbac')); ?></a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="navbar">
                                    <a href="<?php echo e(route('showOrganizationalChart')); ?>"><i class="fa fa-fw fa-th"></i>Organization Information</a>
                                </li>

                                <li class="navbar">
                                    <a href="<?php echo e(route('deadline')); ?>"><i class="fa fa-fw fa-th"></i>Deadline</a>
                                </li>


                                <li class="navbar-right">
                                    <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-th"></i>Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>


</div>




</body>
</html>