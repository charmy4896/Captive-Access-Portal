<!doctype html>
<html lang="en">
<head>


</head>
<body>
<h1>CC HEAD</h1>

<h2>Division Head ID : <?php echo e($divHeadId); ?><br>
Following Student have applied  for Internet Access : <br>
<?php echo e($userId); ?> <br>
Check your Account for above Student Approval </h2>
</body>
</html>