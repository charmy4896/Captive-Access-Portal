<?php $__env->startSection('content'); ?>

   

    <div class="row">

        <div class="col-md-2 hidden-xs"></div>


        <div class="display col-md-8 col-xs-12">

            <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            <?php echo e(Session::forget('success')); ?>


            <?php echo e(Session::forget('error')); ?>


            <?php if(Session::has('profile_upload')): ?>

                <p class="bg-success"> <?php echo e(session('profile_upload')); ?></p>

                <?php echo e(Session::forget('profile_upload')); ?>




            <?php endif; ?>




                <img src="<?php echo e(asset('/images/DAE.gif')); ?>" alt="Not Available" class="center-block" width ="200px" height = "200px">



        </div>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.display_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>