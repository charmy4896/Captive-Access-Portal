<?php $__env->startSection('content'); ?>



    <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo e(Session::forget('success')); ?>


    <?php echo e(Session::forget('error')); ?>


    <script href="bower_components/jquery/dist/jquery.js"></script>

    <div class="result alert alert-success">
        <p><i class="fa fa-check-square" aria-hidden="true"></i> Change your password</p>
    </div>

    <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Enter your Username and choose a new Password.
        &nbsp &nbsp  &nbsp &nbsp <br> Password Must contain number, uppercase letter, lowercase letter and special character, and have 8 or more characters</p></div>


    <div class="alert alert-info">
        <form action="<?php echo e(route('Admin_password_change')); ?>" method="post" class="form-horizontal">

    <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="username" class="col-sm-4 control-label">Username</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" name="username" id="username" class="form-control" placeholder="Username"  onblur="checkAvailability()"  required/>
                    </div>
                    <span id="user-availability-status" style="color: red"></span>


                </div>
            </div>

            <div class="form-group">
                <label for="newpassword" class="col-sm-4 control-label">New password</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="password" name="newpassword" id="newpassword" class="form-control" placeholder="New password"
                               pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20}" title="Must contain at least one number and one uppercase one lowercase letter and one special character, and at least 8 or more characters"
                               required/>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="confirmpassword" class="col-sm-4 control-label">Confirm Password</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="password" name="confirmpassword" id="confirmpassword" class="form-control" placeholder="Confirm Password" onkeyup="check()" required />
                    </div>
                    <span id="message"></span>
                    <script>

                        var check = function() {

                            if (document.getElementById('newpassword').value == document.getElementById('confirmpassword').value) {
                                document.getElementById('message').style.color = 'green';
                                document.getElementById('message').innerHTML = '&nbsp &nbsp &nbsp &nbsp matching';
                            } else {
                                document.getElementById('message').style.color = 'red';
                                document.getElementById('message').innerHTML = '&nbsp &nbsp &nbsp &nbsp not matching';
                            }
                        };


                       var checkAvailability = function () {

                            jQuery.ajax({
                                type :'POST',
                                url: '<?php echo e(route('checkusername')); ?>',
                                data: {_token: '<?php echo e(csrf_token()); ?>',username :$("#username").val()},

                                success:function(data){

                                    // console.log(data);

                                    if(data != 'true'){
                                        $("#user-availability-status").html('&nbsp &nbsp  invalid username  ');
                                    }else{
                                        $("#user-availability-status").html('');
                                    }

                                },
                                error:function (){}
                            });

                        };
                    </script>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-4 col-sm-1">
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-check-square"></i> Change Password            </button>
                </div>
            </div>
        </form>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>