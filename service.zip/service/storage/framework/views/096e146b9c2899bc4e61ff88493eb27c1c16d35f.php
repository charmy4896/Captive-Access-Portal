<?php $__env->startSection('content'); ?>

    <script src="<?php echo e(asset('DataTable/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/bootstrap.min.css')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.css')); ?>"></script>

    <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo e(Session::forget('success')); ?>


    <?php echo e(Session::forget('error')); ?>


        <div class="result alert alert-success">
            <p>
                <b>
                    USER DIVSION HEAD APPROVAL
                </b>
            </p>
        </div>

    <div class="col-md-12">

        <div class="panel panel-default panel-table">

            <div class="panel-body">

                <table id="mytable" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th scope="col">User Id</th>
                        <th scope="col">Payroll No</th>
                        <th scope="col">Group Head Id</th>
                        <th scope="col">Div Status</th>
                        <th>Request Date</th>
                        <th>Division Approval Date</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php if($divHeadInfo != null): ?>
                        <?php $__currentLoopData = $divHeadInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td ><?php echo e($info->user_id); ?></td>
                                <td ><?php echo e($info->payroll_no); ?></td>
                                <td ><?php echo e($info->div_head_id); ?></td>
                                <td ><?php echo e($info->div_head_status); ?></td>
                                <td>
                                    <?php echo e($info->request_date); ?>

                                </td>
                                <td>
                                    <?php if($info->div_approval_date != null): ?>
                                        <?php echo e($info->div_approval_date); ?>

                                    <?php endif; ?>

                                </td>
                                <td>

                                    <?php if($info->div_approval_date == null): ?>


                                        <button  id="approve" name="submit" class="btn btn-primary" onclick="approve( '<?php echo e($info->user_id); ?>' );" >Yes</button>

                                        <button  id="disapprove" name="submit" class="btn btn-danger" onclick="disapprove('<?php echo e($info->user_id); ?>')">No</button>


                                    <?php else: ?>

                                        <?php echo e($info->div_head_status); ?>



                                    <?php endif; ?>

                                </td>



                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>






<script type="text/javascript">

    function approve( user_id) {



        jQuery.ajax({

            type :'POST',

            url: '<?php echo e(route('divHeadApproval')); ?>',

            data : {_token: '<?php echo e(csrf_token()); ?>', user_id: user_id },

            success:  function (data) {

                console.log(data);

                if(data == 'true'){
                    alert('User request Approved');

                    window.location.reload();

                }else{
                    alert('Error While Approving');
                    window.location.reload();
                }

            }


        });
    }
    
    function disapprove(user_id) {


        jQuery.ajax({

            type :'POST',

            url: '<?php echo e(route('divHeadDisApproval')); ?>',

            data : {_token: '<?php echo e(csrf_token()); ?>', user_id: user_id },

            success:  function (data) {

                console.log(data);

                if(data == 'true'){
                    alert('User request DisApproved');
                    window.location.reload();

                }else{
                    alert('Error While DisApproving');
                    window.location.reload();

                }

            }


        });
    }


</script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
        } );

    </script>

        <?php $__env->stopSection(); ?>



<?php echo $__env->make( Session::has('admin_username') ? 'Index.Admin.index'  : 'layouts.display_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>