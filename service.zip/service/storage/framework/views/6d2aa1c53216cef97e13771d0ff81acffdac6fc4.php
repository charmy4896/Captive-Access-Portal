<?php $__env->startSection('labels'); ?>

    <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo e(session::forget('success')); ?>


    <?php echo e(session::forget('error')); ?>


    

    <div class="result alert alert-success">

    <?php if(Session::has('loginMsg')): ?>



            <p><i class="fa fa-check-square" aria-hidden="true"></i>&nbsp<?php echo e(Session::get('loginMsg')); ?></p>

        <?php echo e(session::flush()); ?>


        <?php else: ?>

            <p><i class="fa fa-check-square" aria-hidden="true"></i> Log In</p>


    <?php endif; ?>




    </div>

    <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Enter Your Username and Password to Log in.</p></div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="alert alert-info" style="width: 40%; margin:0 auto;">

        <form action="<?php echo e(route('login')); ?>" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="login" class="col-sm-4 control-label">Username</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" name="login" id="login" value="" class="form-control" placeholder="Username" />
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="password" class="col-sm-4 control-label">Password</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Password" />
                    </div>
                </div>
            </div>



            <div class="form-group">

                <label for="captcha" class="col-sm-4 control-label">Captcha</label>

                <div class="col-sm-8">

                    <div class="col-sm-8">

                        <div class="form-group refereshrecapcha">

                            <?php echo captcha_img('flat'); ?>


                        </div>

                    </div>

                    <div class="col-sm-4">

                        <button type="button" class="btn btn-success" onclick="Captcha_refresh()" ><i class="fa fa-refresh" style="font-size:12px"></i></button>

                    </div>

                    <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha Here"  />

                </div>

            </div>





            <div class="form-group">
                <div class="col-sm-offset-4 col-sm-8">
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-check-square-o"></i> Login            </button>
                </div>
            </div>


        </form>
    </div>

    <script type="text/javascript">

        function Captcha_refresh() {

            $.ajax({

                url: '<?php echo e(route('refreshCaptcha')); ?>',

                type: 'get',

                dataType: 'html',

                success: function(json) {

                    $('.refereshrecapcha').html(json);

                },

            });

        }


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>