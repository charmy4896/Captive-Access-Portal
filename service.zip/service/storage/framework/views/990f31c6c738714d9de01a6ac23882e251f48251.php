<?php $__env->startSection('content'); ?>


    <script src="<?php echo e(asset('DataTable/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/bootstrap.min.css')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.css')); ?>"></script>


    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h1 class="panel-title"><h2>Org Names</h2></h1>
                    </div>
                    <div class="col col-xs-6 text-right" style="padding-top: 15px">

                        <button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal"> Add New Group </button>

                        
                    </div>
                </div>

            </div>

            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog modal-lg" style="padding-top: 50px;
">
                    <div class="modal-content">
                        <div class="modal-header" style="padding: 2px 16px; background-color: #428bca; color: white">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×</button>
                            <h1 class="modal-title" id="myModalLabel">
                               New Group  </h1>
                        </div>
                            <div class="modal-body">

                                <form name="newgroup" class="form-horizontal" method="post" action="<?php echo e(route('addGroup')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="action" value="groupadd" />
                                    <input type="hidden" name="groupdn" value="<?php echo e($group_dn); ?>"/>
                                    <div class="form-group">
                                        <label for="name" class="col-sm-4 control-label">Name of Group</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                                <input type="text" name="name" id="name" class="form-control" placeholder="Group Name" required/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="owner" class="col-sm-4 control-label">Owner</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                                <input type="text" name="owner" id="owner" class="form-control" placeholder="Owner" required/>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Create</button>

                                </form>
                                    </div>
                                </div>
                            </div>
            </div>

            <div class="panel-body">

                <table id="mytable" class="table table-striped" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Owner</th>
                    </tr>
                    </thead>
                    <tbody>

                    <tr>

                        <?php $__currentLoopData = $orgInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <td><a href="<?php echo e(route('getGroupInfoView',$org['dn'])); ?>"><?php echo e($org['name']); ?></a></td>
                            <td><?php echo e($org['owner']); ?></td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>




    <style>


        .panel-table .panel-footer .pagination{
            margin:0;
        }


        /*
        used to vertically center elements, may need modification if you're not using default sizes.
        */


        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 10px;
        }


    </style>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
            $('#mytable1').DataTable();
            $('#myModal').modal('show');
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>