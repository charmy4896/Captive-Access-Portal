<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-2 hidden-xs"></div>


        <div class="display col-md-8 col-xs-12">


            

            

            

            

            

            <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo e(Session::forget('success')); ?>

            <?php echo e(Session::forget('error')); ?>


            <?php if($user_attributes != null and $user != null): ?>

            <div class="panel panel-info">
                <div class="panel-heading text-center">
                    <p class="panel-title">

                        <i class="fa fa-fw fa-user"></i>

                        <?php echo e($user_attributes['displayname']); ?>


                    </p>
                </div>



                <div class="panel-body">

                    <img src="<?php echo e(route('jpegphoto', $user_attributes['username'])); ?>" alt="Not Available" class="center-block" width ="200px" height = "200px">



                    <form action = "<?php echo e(route('upload')); ?>" id="myform" method="POST"  enctype="multipart/form-data" >
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-9">
                                <label class="btn btn-primary" for="my-file-selector">
                                    <input id="my-file-selector" type="file" name = "upload" style="display:none;" onchange="return Upload()">

                                    <script type="text/javascript">
                                        function Upload()
                                        {
                                            //Get reference of FileUpload.
                                            var fileUpload = document.getElementById("my-file-selector");
                                            //Check whether the file is valid Image.
                                            var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png|.gif)$");
                                            if (regex.test(fileUpload.value.toLowerCase()))
                                            {

                                                //Check whether HTML5 is supported.
                                                if (typeof (fileUpload.files) != "undefined")
                                                {
                                                    //Initiate the FileReader object.
                                                    var reader = new FileReader();
                                                    //Read the contents of Image File.
                                                    reader.readAsDataURL(fileUpload.files[0]);
                                                    reader.onload = function (e)
                                                    {
                                                        //Initiate the JavaScript Image object.
                                                        var image = new Image();

                                                        //Set the Base64 string return from FileReader as source.
                                                        image.src = e.target.result;

                                                        //Validate the File Height and Width.
                                                        image.onload = function ()
                                                        {
                                                            var height = this.height;
                                                            var width = this.width;
                                                            if (height > 1024 || width > 1024)
                                                            {
                                                                alert("Height and Width must not exceed 1024px.");
                                                                return false;
                                                            }
                                                            //alert("Uploaded image has valid Height and Width.");
                                                            document.getElementById('myform').submit();
                                                            return true;
                                                        };

                                                    }
                                                }
                                                else
                                                {
                                                    alert("This browser does not support HTML5.");
                                                    return false;
                                                }
                                            }
                                            else
                                            {
                                                alert("Please select a valid Image file.");
                                                return false;
                                            }
                                        }
                                    </script>

                                    <i class="fa fa-upload"></i>  Edit Profile Picture
                                </label>
                            </div>
                        </div>
                    </form>
                    <br/><br/>

                    <ul class="nav nav-tabs">

                        <li class="active"><a data-toggle="tab" href="#general">General</a></li>
                        <li><a data-toggle="tab" href="#personal">Personal</a></li>
                        <li><a data-toggle="tab" href="#group">Group</a></li>
                        <li><a data-toggle="tab" href="#hosts">Access-Rights</a></li>
                    </ul>

                    <div class="tab-content">
                        <div id="general" class="tab-pane fade in active">
                            <h3>General</h3>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">

                                    <?php $__currentLoopData = $user_attributes['general']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <em class="fa fa-<?php echo e($value['faclass']); ?>"></em>
                                            </td>
                                            <td>
                                                <b> <?php echo e($key); ?></b>

                                            </td>
                                            <td>
                                                <?php echo e($value['value']); ?>

                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>

                        <div id="personal" class="tab-pane  fade">
                            <h3>Personal</h3>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">

                                    <?php $__currentLoopData = $user_attributes['personal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td>
                                                <em class="fa fa-<?php echo e($value['faclass']); ?>"></em>
                                            </td>

                                            <td>
                                                <b><?php echo e($key); ?></b>
                                            </td>
                                            <td>
                                                <?php echo e($value['value']); ?>

                                            </td>


                                        </tr>





                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </table>
                            </div>
                        </div>

                        <div id="group" class="tab-pane  fade">
                            <h3>Group</h3>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">



                                        <tbody>
                                        <tr>

                                            <td>
                                            <th class="text-center">
                                                <em class="fa fa-fw fa-users"></em>
                                            </th>

                                            </td>

                                            <td>
                                                Groups
                                            </td>



                                            <td>

                                            <?php if(key_exists('group',$user_attributes)): ?>

                                            <?php $__currentLoopData = $user_attributes['group']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                            <?php echo e($value); ?>

                                                <br>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php endif; ?>

                                    </td>

                                        </tr>




                                        </tbody>


                                </table>
                            </div>
                        </div>

                        <div id="hosts" class="tab-pane  fade">
                            <h3>Hosts</h3>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">

                                    <tbody>
                                    <tr>
                                    <td>

                                        <td>
                                        <th class="text-center">
                                            <em class="fa fa-fw fa-users"></em>
                                        </th>


                                        <td>
                                            Hosts
                                        </td>


                                        <td>

                                            

                                    




                                            

                                                    

                                                

                                                    


                                                

                                        


                                    


                                            <?php $__currentLoopData = $user_attributes['access_rights']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                <?php if($value['value'] == true): ?>

                                                <input type="checkbox" name="<?php echo e($value['name']); ?>" value="<?php echo e($value['name']); ?>" id="<?php echo e($value['name']); ?>" checked  onchange="access_right(this)"><?php echo e($value['name']); ?></input>

                                                <?php else: ?>

                                                <input type="checkbox" name="<?php echo e($value['name']); ?>" value="<?php echo e($value['name']); ?>" id="<?php echo e($value['name']); ?>"   onchange="access_right(this)"><?php echo e($value['name']); ?></input>


                                                <?php endif; ?>

                                                <br>






                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                

                                        </td>

                                    </tr>
                                    </tbody>



                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-9">


                    <?php if(key_exists('ds-pwp-account-disabled',$user_attributes)): ?>

                        <?php if($user_attributes['ds-pwp-account-disabled'] == true or $user_attributes['ds-pwp-account-disabled'] == 1 ): ?>

                            <a href="<?php echo e(route('activate',$user_attributes['username'])); ?>">

                        <button type="submit" name="submit" class="btn btn-success">

                            Activate</button></a>

                        <?php else: ?>

                            <a href="<?php echo e(route('deactivate',$user_attributes['username'])); ?>">

                        <button type="submit" name="submit" class="btn btn-danger">

                            De-Activate</button></a>

                    <?php endif; ?>


                    <?php endif; ?>

                        <a href="<?php echo e(route('editUserProfile',$user_attributes['username'])); ?>">
                            <button type="submit" name="submit" class="btn btn-success">


                                Edit Profile</button></a>

                </div>
            </div>

                <?php endif; ?>

        </div>

        <div class="col-md-2 hidden-xs"></div>

    </div>



    <script>


        // function getUrlParameter(name) {
        //     name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        //     var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        //     var results = regex.exec(location.search);
        //     return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
        // };


        function access_right(element)
        {


            var checkbox = document.getElementById(element.id);

            jQuery.ajax({

                type: 'POST',
                url: "<?php echo e(route('giveAccessRights',$user_attributes['username'])); ?>",
                data: {id:element.id,value: checkbox.checked,_token: '<?php echo e(csrf_token()); ?>'},
                async : true,
                success: function (result) {

                    console.log(result);

                    if (result == 'add') {
                        alert('Member added');

                    }
                    else if(result == 'remove'){
                        alert('Member removed');
                    }
                    else{
                        alert(result);
                    }
                },
                error:function (error){
                    console.log(JSON.stringify(error));
                }
            });
        }



    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>