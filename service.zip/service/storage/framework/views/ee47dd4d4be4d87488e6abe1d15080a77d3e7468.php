        

        <?php $__env->startSection('labels'); ?>


            <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            <?php echo e(Session::forget('success')); ?>


            <?php echo e(Session::forget('error')); ?>



            <div class="result alert alert-success">
                <?php if(Session::has('success') or Session::has('error') ): ?>

                    <p><i class="fa fa-check-square" aria-hidden="true"></i><?php echo e(Session::get('success') != '' ?  Session::get('success')  :  Session::get('error')); ?></p>

                    <?php echo e(Session::forget('success')); ?>


                    <?php echo e(Session::forget('error')); ?>


                    <?php else: ?>

                    <p><i class="fa fa-check-square" aria-hidden="true"></i> Register a new account</p>

                    <?php endif; ?>

            </div>


            <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Fill up necessary details to Request a New account</p>
            </div>


            <?php $__env->stopSection(); ?>

        <?php $__env->startSection('content'); ?>
            <div class="alert alert-info">

                <form action="<?php echo e(route('employee.store')); ?>" method="post" class="form-horizontal">

                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="login" class="col-sm-4 control-label">Username<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" name="login" id="login" value="" class="form-control " placeholder="Username" onblur="checkAvailability()"/>

                            </div>
                        </div>
                        <span id="user-availability-status" style="color: red"></span>
                    </div>

                    
                        
                        
                            
                                
                                
                            

                            
                                

                                    
                                    

                            
                        
                    

                    
                        
                        
                            
                                
                                
                            
                            
                                

                                    
                                    

                                

                        
                    

                    <div class="form-group">
                        <label for="firstname" class="col-sm-4 control-label">First name<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="firstname" id="firstname" value=""class="form-control" placeholder="First name" required/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="lastname" class="col-sm-4 control-label">Last name<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="lastname" id="lastname" value=""class="form-control" placeholder="Last name" required/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="mail" class="col-sm-4 control-label">Work E-Mail<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="mail" id="mail" value=""class="form-control" placeholder="Work E-Mail" required/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="initials" class="col-sm-4 control-label">Initials<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <select class="form-control" id="initials" name="initials" value="">
                                    <option value="Mr.">Mr.</option>
                                    <option value="Ms.">Ms.</option>
                                    <option value="Mrs.">Mrs.</option>
                                    <option value="Prof.">Prof.</option>
                                    <option value="Dr.">Dr.</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="emailaddress" class="col-sm-4 control-label">Alternate Email<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="emailaddress" id="emailaddress" value="" class="form-control" placeholder="Alternate Email" required/>
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="dateofbirth" class="col-sm-4 control-label">Date Of Birth</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" class="form-control" id="dateofbirth" value="" name="dateofbirth"  data-date-format="dd-mm-yy">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="mobile" class="col-sm-4 control-label">Mobile No.<b style = 'font-size:150%;color:red'> *</b></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="mobile" id="mobile" maxlength="10" value="" class="form-control" placeholder="Mobile No."  required/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="homephone" class="col-sm-4 control-label">Home-Phone No.</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="homephone" id="homephone" maxlength="10" value=""class="form-control" placeholder="Home-Phone No." />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="employeenumber" class="col-sm-4 control-label">Payroll/Employee No.</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="employeenumber" id="employeenumber" value="" class="form-control" placeholder="Payroll No." />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="employeetype" class="col-sm-4 control-label">Employee Type</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <select class="form-control" id="employeetype" name="employeetype" value="">
                                    <option value="0">Select a Value</option>
                                    <option value="Permanent">Permanent</option>
                                    <option value="Temporary">Temporary</option>
                                    <option value="Contractual">Contractual-Through Agency</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="businesscategory" class="col-sm-4 control-label">Employee Category</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <select class="form-control" id="businesscategory" name="businesscategory" value="">
                                    <option value="Select a Value">Select a Value</option>
                                    <!-- <option value="Technical">Technical-For Engineers</option> -->
                                    <option value="Scientific/Technical">Scientific/Technical Officers</option>
                                    <option value="Administration">Administration</option>
                                    <option value="Student">Student/Interns/Trainee</option>
                                    <option value="Scholar">Scholar/PDF</option>
                                    <option value="Trainee">Project-Staff</option>
				    <option value="Through Agency">Contractual-Through Agency</option>

                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">

                       <!-- <div class="ui-widget"> -->
                        <label for="manager" class="col-sm-4 control-label">Select your Approving Authority</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="manager" id="manager" value=""class="form-control" placeholder="Select section/division/group head"  onfocus="getOwner()"  onabort="getDepartment()" autocomplete="on" required />
                            </div>
                        </div>
<!--                        </div> -->
                    </div>






                    <div class="form-group">
                        <label for="organizationalunit" class="col-sm-4 control-label">Department</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>

                                <input type="text" name="organizationalunit" id="organizationalunit" value="" class="form-control" onfocus="getDepartment()" placeholder="Department" autocomplete="on" />
                            </div>
                        </div>
                    </div>



                    <div class="form-group">
                        <label for="organization" class="col-sm-4 control-label">Organization</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <select class="form-control" id="organization" name="organization" value="">
                                    <option value="Select a Value">Select a Value</option>
                                    <option value="IPR">IPR</option>
                                    <option value="CPP">CPP</option>
                                    <option value="FCIPT">FCIPT</option>
                                    <option value="ITER-India">ITER-India</option>
                                </select>
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="dateofjoining" class="col-sm-4 control-label">Joining Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" class="form-control" value="" id="dateofjoining" name="dateofjoining" data-provide="datepicker" data-date-language="en" data-date-format="dd-mm-yy">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="dateofcompletion" class="col-sm-4 control-label">Completion Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" class="form-control" value=""id="dateofcompletion" name="dateofcompletion" data-provide="datepicker" data-date-language="en"data-date-format="dd-mm-yy">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="officeroomnumber" class="col-sm-4 control-label">Room Number</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="officeroomnumber" id="officeroomnumber" value=""class="form-control" placeholder="Room Number" />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="extensionnumber" class="col-sm-4 control-label">Extention Number</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                <input type="text" name="extensionnumber" id="extensionnumber" value=""class="form-control" placeholder="Extention Number" />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">

                        <span class="col-sm-4"></span>

                        <div class="col-sm-8">

                            <div class="input-group">

                                <div class="checkbox">

                                    <label><input id="terms" type="checkbox" value=""  required><b>

                                            I hereby declare that I have read,

                                            understood and thereby accept the

                                            <a data-toggle="modal" data-target="#myModal"><b>AUP (Acceptable Use Policy)</b></a>

                                            of Institute for Plasma Research.

                                            I promise to abide strictly to Institute’s IT security policy.

                                            The IPR Management can take necessary action against

                                            me in case of the violation of this policy.

                                        </b></label>

                                </div>

                            </div>

                        </div>

                    </div>







                    <!-- Modal -->

                    <div class="modal fade" id="myModal" role="dialog">

                        <div class="modal-dialog modal-lg">



                            <!-- Modal content-->

                            <div class="modal-content">

                                <div class="modal-header">

                                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                                    <h4 class="modal-title" >ACCEPTABLE USE POLICY</h4>

                                </div>

                                <div class="modal-body" color="black">


                                    <?php echo $__env->make('terms&condition', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                                </div>

                                <div class="modal-footer">

                                    <button type="button" onclick="iAgree()" class="btn btn-success" data-dismiss="modal">I AGREE</button>

                                </div>

                            </div>



                        </div>

                    </div>

                    <div class="form-group">

                        <label for="captcha" class="col-sm-4 control-label">Captcha</label>

                        <div class="col-sm-8">

                            <div class="col-sm-3">

                                <div class="form-group refereshrecapcha">

                                    <?php echo captcha_img('flat'); ?>


                                </div>

                            </div>

                            <div class="col-sm-9">

                                <button type="button" class="btn btn-success" onclick="Captcha_refresh()" ><i class="fa fa-refresh" style="font-size:12px"></i></button>

                            </div>

                            <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha Here"  required />


                        </div>

                    </div>


                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
                            <button type="submit" class="btn btn-success" onsubmit="checkForm()">
                                <i class="fa fa-check-square-o"></i> Request new Account</button>
                        </div>
                    </div>
                </form>
            </div>

            
            
            

            <script>
                function checkAvailability() {


                    jQuery.ajax({

                        type :'POST',

                        url: '<?php echo e(route('checkusername')); ?>',

                        data: {_token: '<?php echo e(csrf_token()); ?>',username :$("#login").val()},

                        success:function(data){

                            if(data == 'true'){
                                $("#user-availability-status").html('&nbsp &nbsp username already exists');
                            }else{
                                $("#user-availability-status").html('  ');

                            }

                        },
                        error:function (){}
                    });

                }



              function getOwner() {

                  var value = $("#manager").val();
                  var data;
                  jQuery.ajax({

                      type: 'POST',

                      url: '<?php echo e(route('getDivHead')); ?>',

                      'datatype': 'json',

                      data: {_token: '<?php echo e(csrf_token()); ?>', manager: value},

                      success: function (data1) {

                          data = JSON.parse(data1);

                          display(data);
                      }

                  });
              }

                function display(owner){

                  $( function() {

                        $( "#manager" ).autocomplete({
                            source: owner
                        });
                    } );

                }



                function iAgree() {

                    // document.getElementById("terms").disabled = false;

                    document.getElementById("terms").checked="true";

                }

                 function getDepartment() {

                    var value = $('#manager').val();

                     jQuery.ajax({

                         type: 'POST',

                         'datatype' :'json',

                         url: '<?php echo e(route('getDepartmentOfOwner')); ?>',

                         data: {_token: '<?php echo e(csrf_token()); ?>', id: value},

                         success: function (data) {

                           // console.log(data);

                            // var data1 =  JSON.parse(data);


                            displayDept( JSON.parse(data));
                         }

                     });

                     function displayDept(dept){

                         $( function() {

                             $( "#organizationalunit" ).autocomplete({
                                 source: dept
                             });
                         } );

                     }




                }

                function Captcha_refresh() {

                    $.ajax({

                        url: '<?php echo e(route('refreshCaptcha')); ?>',

                        type: 'get',

                        dataType: 'html',

                        success: function(json) {

                            $('.refereshrecapcha').html(json);

                        },

                    });

                }



            </script>


            <style>

                .modal-body{

                    color:black;

                    background-color: #e6f7ff;



                }

                .modal-footer{

                    color:black;

                    background-color: #e6f7ff;



                }



                .modal-header{

                    color:black;

                }

            </style>





        <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>