<?php $__env->startSection('labels'); ?>



    <div class="result alert alert-success">
        <p><i class="fa fa-check-square" aria-hidden="true"></i> Register a new account</p>
    </div>


    <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Fill up necessary details to Request a New account</p>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="alert alert-info">
    <form action=" <?php echo e(route('guest.store')); ?>" method="post" class="form-horizontal">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="login" class="col-sm-4 control-label">Username<b style = 'font-size:150%;color:red'> *</b></label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                    <input type="text" name="login" id="login" value="" class="form-control" placeholder="Username"/>
                </div>

            </div>
        </div>

        <div class="form-group">
            <label for="password" class="col-sm-4 control-label">Password<b style = 'font-size:150%;color:red'> *</b></label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required/>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="confirmpassword" class="col-sm-4 control-label">Confirm Password<b style = 'font-size:150%;color:red'> *</b></label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="password" name="confirmpassword" id="confirmpassword" class="form-control" placeholder="Confirm Password" required/>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="firstname" class="col-sm-4 control-label">First name<b style = 'font-size:150%;color:red'> *</b></label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="text" name="firstname" id="firstname" value=""class="form-control" placeholder="First name" required/>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="lastname" class="col-sm-4 control-label">Last name<b style = 'font-size:150%;color:red'> *</b></label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="text" name="lastname" id="lastname" value=""class="form-control" placeholder="Last name" required/>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="mail" class="col-sm-4 control-label">E-mail<b style = 'font-size:150%;color:red'> *</b></label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="text" name="mail" id="mail" value=""class="form-control" placeholder="E-mail" required/>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="initials" class="col-sm-4 control-label">Initials<b style = 'font-size:150%;color:red'> *</b></label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <select class="form-control" id="initials" name="initials" value="">
                        <option value="Mr.">Mr.</option>
                        <option value="Mrs.">Mrs.</option>
                        <option value="Prof.">Prof.</option>
                        <option value="Dr.">Dr.</option>
                        <option value="Ms.">Ms.</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="mobile" class="col-sm-4 control-label">Mobile No.</label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="text" name="mobile" id="mobile" maxlength="10" value="" class="form-control" placeholder="Mobile No." />
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="employeetype" class="col-sm-4 control-label">Type</label>
            <div class="col-sm-8">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <select class="form-control" id="employeetype" name="employeetype" value="">
                        <option value="Guest">Guest</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">

            <div class="ui-widget">
                <label for="manager" class="col-sm-4 control-label">Division/Section/Project Leader</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="text" name="manager" id="manager" value=""class="form-control" placeholder="Division/Section/Project Leader"  onfocus="getOwner()" autocomplete="on" />
                    </div>
                </div>
            </div>
        </div>


        <div class="form-group">
            <div class="col-sm-offset-4 col-sm-8">
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check-square-o"></i> Request new Account            </button>
            </div>
        </div>


    </form>
    </div>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


    <script>


        function getOwner() {

            var value = $("#manager").val();
            var data;
            jQuery.ajax({

                type: 'POST',

                url: 'http://localhost:8000/index/divisionHead',

                'datatype': 'json',

                data: {_token: '<?php echo e(csrf_token()); ?>', manager: value},

                success: function (data1) {

                    data = JSON.parse(data1);

                    display(data);
                }

            });
        }

        function display(owner){

            $( function() {

                $( "#manager" ).autocomplete({
                    source: owner
                });
            } );

        }
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>