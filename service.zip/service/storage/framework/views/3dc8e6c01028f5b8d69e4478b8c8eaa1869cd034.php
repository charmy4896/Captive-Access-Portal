<?php $__env->startSection('content'); ?>


    <div class="result alert alert-success">
        <p><i class="fa fa-check-square" aria-hidden="true"></i> Change your password</p>
    </div>

    <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Enter your old password and choose a new one.</p></div>


    <div class="alert alert-info">
        <form action="<?php echo e(route('IndexPasswordChange')); ?>" method="post" class="form-horizontal">

            <?php echo e(csrf_field()); ?>


            <div class="form-group">
            <label for="username" class="col-sm-4 control-label">Username</label>
            <div class="col-sm-8">
            <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-user"></i></span>
            <input type="text" name="username" id="username" value="" class="form-control" placeholder="Username" />
            </div>
            </div>
            </div>
            <div class="form-group">
                <label for="oldpassword" class="col-sm-4 control-label">Old password</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="password" name="oldpassword" id="oldpassword" class="form-control" placeholder="Old password" required />
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="newpassword" class="col-sm-4 control-label">New password</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="password" name="newpassword" id="newpassword" class="form-control" placeholder="New password"    required/>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="confirmpassword" class="col-sm-4 control-label">Confirm Password</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="password" name="confirmpassword" id="confirmpassword" class="form-control" placeholder="Confirm Password" onkeyup="check()" required />
                    </div>
                    <span id="message"></span>
                    <script>

                        var check = function() {

                            if (document.getElementById('newpassword').value == document.getElementById('confirmpassword').value) {
                                document.getElementById('message').style.color = 'green';
                                document.getElementById('message').innerHTML = '&nbsp &nbsp &nbsp &nbsp matching';
                            } else {
                                document.getElementById('message').style.color = 'red';
                                document.getElementById('message').innerHTML = '&nbsp &nbsp &nbsp &nbsp not matching';
                            }
                        }
                    </script>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-1">
                    <button type="submit" class="btn btn-success">
                        <i class="fa fa-check-square"></i> Change Password            </button>
                </div>
                <div>
        </form>
        <form action="<?php echo e(route('home.index')); ?>" method="GET" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <div class="col-sm-offset-1 col-sm-3">
                    <button type="submit" class="btn btn-success">
                        <input type="hidden" name="cancel" value="cancel">
                        <i class="fa fa-check-square"></i> Cancel            </button>
                </div>
            </div>
        </form>
    </div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>