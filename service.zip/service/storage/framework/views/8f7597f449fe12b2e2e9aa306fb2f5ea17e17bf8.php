<!doctype html>
<html lang="en">
<head>


</head>
<body>


<h4>Division Head ID : <?php echo e($divHeadId); ?></h4>
<h3>Following Student have applied Internet Access :</h3>
<h1><?php echo e($userId); ?></h1>
<h3>Check your Account for above Student Approval</h3>
</body>
</html>