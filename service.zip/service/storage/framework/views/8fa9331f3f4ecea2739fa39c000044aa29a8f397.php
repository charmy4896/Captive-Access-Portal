<?php $__env->startSection('content'); ?>


    <script src="<?php echo e(asset('DataTable/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/bootstrap.min.css')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.css')); ?>"></script>


    <div class="col-md-10 col-md-offset-1">

        
        
        <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo e(Session::forget('success')); ?>


        <?php echo e(Session::forget('error')); ?>


        
        <?php if($orgInfo != null and $users != null and $parent_dn != null and $group_dn != null): ?>

            <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h1 class="panel-title"><h2><?php echo e($orgInfo['name']); ?></h2></h1>
                        <button type="submit" name="submit" class="btn btn-primary col-sm-3" data-toggle="modal" data-target="#myModal1">
                            <em class="glyphicon glyphicon-edit"></em> Rename</button> &nbsp &nbsp &nbsp

                    </div>


                    <div class="col col-xs-6 text-right" style="padding-top: 15px">

                        <button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal4">
                            <em class="glyphicon glyphicon-edit"></em> Change Owner</button>

                        <button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal"> Add New Group </button>



                        
                    </div>
                </div>
            </div>

            

            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog modal-lg" style="padding-top: 50px;
">
                    <div class="modal-content">
                        <div class="modal-header" style="padding: 2px 16px; background-color: #428bca; color: white">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×</button>
                            <h1 class="modal-title" id="myModalLabel">
                                New Group  </h1>
                        </div>
                        <div class="modal-body">

                            <form name="newgroup" class="form-horizontal" method="post" action="<?php echo e(route('addGroup')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="action" value="groupadd" />
                                <input type="hidden" name="groupdn" value="<?php echo e($group_dn); ?>"/>
                                <div class="form-group">
                                    <label for="name" class="col-sm-4 control-label">Name of Group</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                            <input type="text" name="name" id="name" class="form-control" placeholder="Group Name" required/>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="owner" class="col-sm-4 control-label">Owner</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                            <input type="text" name="owner" id="owner" class="form-control" placeholder="Owner"  onfocus="getUsers()" required/>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Create</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            

            <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog modal-lg" style="padding-top: 50px;
">
                    <div class="modal-content">
                        <div class="modal-header" style="padding: 2px 16px; background-color: #428bca; color: white">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×</button>
                            <h1 class="modal-title" id="myModalLabel">
                                New Group  </h1>
                        </div>
                        <div class="modal-body">

                            <form name="newgroup" class="form-horizontal" method="post" action="<?php echo e(route('renameGroupName')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="action" value="groupadd" />
                                <input type="hidden" name="groupdn" value="<?php echo e($group_dn); ?>"/>
                                <input type="hidden" name="parentdn" value="<?php echo e($parent_dn); ?>"/>

                                <div class="form-group">
                                    <label for="groupname" class="col-sm-4 control-label">New Group Name</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                            <input type="text" name="groupname" id="groupname" class="form-control"  placeholder=" New Group Name" required/>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Rename</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

                

                <div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                     aria-hidden="true">
                    <div class="modal-dialog modal-lg" style="padding-top: 50px;
">
                        <div class="modal-content">
                            <div class="modal-header" style="padding: 2px 16px; background-color: #428bca; color: white">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                    ×</button>
                                <h1 class="modal-title" id="myModalLabel">
                                    Change Owner Name  </h1>
                            </div>
                            <div class="modal-body">

                                <form name="newgroup" class="form-horizontal" method="post" action="<?php echo e(route('changeOwner')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="action" value="groupadd" />
                                    <input type="hidden" name="groupdn" value="<?php echo e($group_dn); ?>"/>

                                    <div class="form-group">
                                        <label for="ownername" class="col-sm-4 control-label">Owner Name</label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                                <input type="text" name="ownername" id="ownername" class="form-control" onfocus="getUsers()" placeholder=" New Owner Name" required/>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Change</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>




            <div class="panel-body">

                <table id="mytable" class="table table-striped" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Owner</th>
                    </tr>
                    </thead>
                    <tbody>


                    <?php echo e(Session::put('parent_dn',$group_dn)); ?>


                    <?php if(array_key_exists('suborg',$orgInfo)): ?>

                    <?php $__currentLoopData = $orgInfo['suborg']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>


                            <td><a href="<?php echo e(route('getGroupInfoView',$org['dn'])); ?>"><?php echo e($org['name']); ?></a></td>
                            <td><?php echo e($org['owner']); ?></td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <?php endif; ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>



    

    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6 ">
                        <h1 class="panel-title"><h2>Members</h2></h1>
                    </div>
                    <div class="col col-xs-6 text-right" style="padding-top: 15px">

                        <button type="submit" name="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal2"> Add New Member </button>

                        
                    </div>
                </div>
            </div>




            <div class="modal fade" id="myModal2"  role="dialog">
                <div class="modal-dialog"  >
                    <div class="modal-content">
                        <div class="modal-header" style="background-color: #428bca; color: white" >
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                ×</button>
                            <h1 class="modal-title" id="myModalLabel">
                                New Member </h1>
                        </div>

                        <div class="modal-body">


                            

                    <?php echo e(csrf_field()); ?>

                    
                    

                                <?php echo e(Session::put('groupdn',$group_dn)); ?>



                    
                    <div class="col-md-10 col-md-offset-1">

                        <div class="panel panel-default panel-table">
                            <div class="panel-body">
                                <table id="mytable2" class="table table-striped " cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>UID</th>
                                        <th><em class="fa fa-cog"></em></th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                            <td><?php echo e($user->getCommonName()); ?> </td>

                                            <td>

                                                

                                                <a href="<?php echo e(route('addMember',$user->getCommonName())); ?>">
                                                    <button type="submit" name="submit" class="btn btn-primary"> Add To Group</button></a>

                                            </td>

                                            </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <button type="button" id="newgroupbtn" class="btn btn-primary" style="margin-left: 90%">Create</button>
                

            </div>
        </div>
    </div>
    </div>


            <div class="panel-body">

                <table id="mytable1" class="table table-striped" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>UID</th>
                        <th></th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php if(array_key_exists('member',$orgInfo)): ?>

                        <?php $__currentLoopData = $orgInfo['member']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>


                            <td><a href="<?php echo e(route('showUserProfile',$member)); ?>"><?php echo e($member); ?></a></td>
                            <td>

                                <form name="newgroup" class="form-horizontal" method="post" action="<?php echo e(route('removeMember',$member)); ?>">

                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="groupdn" value="<?php echo e($group_dn); ?>"/>

                                    <button type="submit" name="submit" class="btn btn-primary">Remove</button>

                                </form>

                            </td>

                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <?php endif; ?>

    <link href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" rel="Stylesheet"></link>
    <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script>


    <style>

        /*#myModal2 .modal-content*/
        /*{*/
            /*height:400px;*/
            /*overflow:auto;*/
        /*}*/


        .panel-table .panel-footer .pagination{
            margin:0;
        }

        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 0px;
        }

        .ui-autocomplete {
            z-index:2147483647;
        }


    </style>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();
            $('#mytable1').DataTable();
            $('#mytable2').DataTable({
                "scrollY": "450px",
                "scrollCollapse": true,
                "pagingType": "full_numbers"} );


        } );

        function getUsers() {

            jQuery.ajax({

                type :'POST',

                url: '<?php echo e(route('getUsers')); ?>',

                data: {_token: '<?php echo e(csrf_token()); ?>'},

                success:function(data){

                    displayUsers(JSON.parse(data));

                },
                error:function (){}
            });
        }

        function displayUsers(data){

            $( function() {

                $( "#owner" ).autocomplete({
                    source: data ,
                });

                $( "#ownername" ).autocomplete({
                    source: data ,
                });


            } );


        }



    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>