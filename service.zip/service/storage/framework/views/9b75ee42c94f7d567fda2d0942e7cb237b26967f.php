<!doctype html>
<html lang="en">
<head>

</head>
<body>

Welcome India!!!

<?php echo e($name); ?>

</body>
</html>