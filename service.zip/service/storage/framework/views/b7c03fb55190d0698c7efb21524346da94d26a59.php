<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">





    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/libs.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">

    
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>


    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

</head>
<body>
<div class="container">

    <div class="panel panel-success" >
        <div class="panel-body"  >

            <div class="navbar-wrapper">

                <div class="navbar navbar-default navbar-static-top" role="navigation">
                    <div class="container-fluid">

                        <div class="navbar-collapse collapse">
                            <div class="navbar-form navbar-left">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="<?php echo e(route('home.index')); ?>"><i class="fa fa-fw fa-home"></i> Home</a>
                            </div>
                            <div class="navbar-form navbar-right" >
                                <ul class="nav navbar-nav">
                                    <li >
                                        <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-th"></i> Logout</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="navbar-form navbar-right" >
                                <ul class="nav navbar-nav">
                                    <li >
                                        <a href="<?php echo e(route('password_view')); ?>"><i class="fa fa-fw fa-th"></i> Change Password</a>
                                    </li>
                                </ul>
                            </div>

                            <div class="navbar-form navbar-right">
                                <ul class="nav navbar-nav">
                                    <li>
                                        <form class="navbar-form navbar-right" role="search" action="<?php echo e(route('search')); ?>" method="post">

                                            <?php echo e(csrf_field()); ?>

                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Search" name="search" id="search" required/>
                                                <span class="input-group-btn">
                          <button class="btn btn-default" type="submit">&nbsp;<i class="fa fa-fw fa-search"></i></button>
                        </span>
                                            </div>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


            <?php echo $__env->yieldContent('content'); ?>


        </div>

    </div>
</div>
</body>
</html>