<?php $__env->startSection('labels'); ?>


        <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Enter Your Username to Check Current Status</p></div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="alert alert-info" style="width: 80%; margin:0 auto;">

        <form action="<?php echo e(route('getStatus')); ?>" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="username" class="col-sm-4 control-label">Username</label>
                <div class="col-sm-8">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" name="username" id="username" value="" class="form-control" placeholder="Username"  required/>
                    </div>
                </div>
            </div>


                <div class="form-group">
                    <div class="col-sm-offset-4 col-sm-8">
                        <button type="submit" class="btn btn-success">
                            <i class="fa fa-check-square-o"></i> Get Status           </button>
                    </div>
                </div>
        </form>


    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>