        <?php $__env->startSection('content'); ?>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
        google.load("visualization", "1", { packages: ["orgchart"] });
        google.setOnLoadCallback(drawChart);
        function drawChart() {
            $.ajax({
                type: "POST",
                url: '<?php echo e(route('getOrganizationInformation')); ?>',
                data: {_token: '<?php echo e(csrf_token()); ?>'},

                success: function (data1) {

                    // console.log(data1);
                    // // console.log(jQuery.parseJSON(data1));


                    var r =  JSON.parse(data1);

                    var count = Object.keys(r).length;

                    console.log(r);
                    var data = new google.visualization.DataTable();
                    data.addColumn('string', 'Entity');
                    data.addColumn('string', 'ParentEntity');
                    data.addColumn('string', 'ToolTip');

                    for (var i = 0; i < count; i++) {

                        console.log(r[i]);
                         var employeeId = i.toString();
                        var parentName = r[i]['parentId'];
                         var childName = r[i]['memberId'];

                        data.addRows([[{ v: employeeId,
                            f: childName }, parentName, parentName]]);
                    }
                    var chart = new google.visualization.OrgChart($("#chart")[0]);
                    chart.draw(data, { allowHtml: true });
                },
                failure: function (r) {
                    alert(r.d);
                },
                error: function (r) {
                    alert(r.d);
                }
            });
        }

        </script>


<div id="chart">
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>