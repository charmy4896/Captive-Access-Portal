 



<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo e(Session::forget('success')); ?>


    <?php echo e(Session::forget('error')); ?>



    <?php if($info != null and $username != null): ?>

    <div class="col-lg-4">
        <div class="panel panel-info">
            <div class="panel-heading">
                <div class="row"><div class="col-xs-6">
                        <i class="fa fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-6 text-right">
                        <p class="announcement-heading"><?php echo e($info['totalusers']); ?></p>
                        <p class="announcement-text">Total Users</p>
                    </div>
                </div>
            </div>
                </div>
        </div>

    <div class="col-lg-4">
        <div class="panel panel-success">
            <div class="panel-heading">
                <div class="row"><div class="col-xs-6">
                        <i class="fa fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-6 text-right">
                        <p class="announcement-heading"><?php echo e($info['unlockedusers']); ?></p>
                        <p class="announcement-text">Total Unlocked Users</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="panel panel-danger">
            <div class="panel-heading">
                <div class="row"><div class="col-xs-6">
                        <i class="fa fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-6 text-right">
                        <p class="announcement-heading"><?php echo e($info['lockedusers']); ?></p>
                        <p class="announcement-text">Total Locked Users</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php endif; ?>




    Welcome to Admin Home


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>