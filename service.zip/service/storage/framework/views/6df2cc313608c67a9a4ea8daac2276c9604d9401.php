<!doctype html>
<html lang="en">
<head>

    <link rel="stylesheet" href="<?php echo e(asset('css/libs.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

</head>
<body>


<div class="container">
    <div class="row">

        <div class="panel panel-success">
            <div class="panel-body" style="background-color: lightgray">

                <a href="#" alt="Home">
                    <img src="<?php echo e(asset('/images/ipr-logo.png')); ?>" alt="Logo" class="logo img-responsive center-block" />
                </a>


        <div class="result alert alert-success">
            <p>
                <b>
                    USER DIVSION HEAD APPROVAL
                </b>
            </p>
        </div>




                <div class="panel panel-success">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">User Id</th>
                            <th scope="col">Payroll No</th>
                            <th scope="col">Group Head Id</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>

                        </tr>
                        </thead>
                        <tbody>

                        <tr>
                            <td ><?php echo e($div_head_approval_info->user_id); ?></td>
                            <td ><?php echo e($div_head_approval_info->payroll_no); ?></td>
                            <td ><?php echo e($div_head_approval_info->div_head_id); ?></td>
                            <td ><?php echo e($div_head_approval_info->status); ?></td>
                            <td>

                                

                                    
                                    

                                    <button  id="approve" name="submit" class="btn btn-primary" onclick="approve()" >Approve</button>

                                    <button  id="disapprove" name="submit" class="btn btn-danger" onclick="disapprove()">Disapprove</button>


                                



                            </td>

                        </tr>
                        </tbody>
                    </table>

                </div>
             </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script type="text/javascript">


    function approve() {

        jQuery.ajax({

            type :'POST',

            url: '<?php echo e(route('divHeadApproval')); ?>',

            data : {_token: '<?php echo e(csrf_token()); ?>', user_id: '<?php echo e($div_head_approval_info->user_id); ?>' },

            success:  function (data) {

                console.log(data);

                if(data == 'true'){
                    alert('User request Approved');
                }else{
                    alert('Error While Approving');
                }

            }


        });
    }
    
    function disapprove() {


        jQuery.ajax({

            type :'POST',

            url: '<?php echo e(route('divHeadDisApproval')); ?>',

            data : {_token: '<?php echo e(csrf_token()); ?>', user_id: '<?php echo e($div_head_approval_info->user_id); ?>' },

            success:  function (data) {

                console.log(data);

                if(data == 'true'){
                    alert('User request DisApproved');
                }else{
                    alert('Error While DisApproving');
                }

            }


        });
    }





</script>

</body>
</html>