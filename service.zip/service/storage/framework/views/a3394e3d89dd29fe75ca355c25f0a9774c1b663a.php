<?php $__env->startSection('labels'); ?>

    <div class="help alert alert-warning"><p><i class="fa fa-info-circle"></i> Enter Your Username to Check Current Status</p></div>


    <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo e(Session::forget('success')); ?>


    <?php echo e(Session::forget('error')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="alert alert-info" style="width: 80%; margin:0 auto;">

        <form action="<?php echo e(route('getStatus')); ?>" method="POST" class="form-horizontal">

            <?php echo e(csrf_field()); ?>




            <div class="form-group">
                <label for="username" class="col-sm-4 control-label">Username</label>
                <div class="col-sm-4">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" name="username" id="username" value="" class="form-control" placeholder="Username"  required/>
                    </div>
                </div>
            </div>


            <div class="form-group">

                <label for="captcha" class="col-sm-4 control-label">Captcha</label>

                <div class="col-sm-4">

                    <div class="col-sm-8">

                        <div class="form-group refereshrecapcha">

                            <?php echo captcha_img('flat'); ?>


                        </div>

                    </div>

                    <div class="col-sm-4">

                        <button type="button" class="btn btn-success" onclick="Captcha_refresh()" ><i class="fa fa-refresh" style="font-size:12px"></i></button>

                    </div>

                    <input type="text" name="captcha" id="captcha" class="form-control" placeholder="Enter Captcha Here"   />


                </div>

            </div>



            <div class="form-group">
                    <div class="col-sm-offset-4 col-sm-8">
                        <button type="submit"  class="btn btn-success">
                            <i class="fa fa-check-square-o"></i> Get Status           </button>
                    </div>
                </div>
        </form>


    </div>

    <script>


        function Captcha_refresh() {

            $.ajax({

                url: '<?php echo e(route('refreshCaptcha')); ?>',

                type: 'get',

                dataType: 'html',

                success: function(json) {

                    $('.refereshrecapcha').html(json);

                },

            });

        }






    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>