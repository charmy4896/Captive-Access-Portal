<!doctype html>
<html lang="en">
<head>

    

    
    


            <script rel="stylesheet" src="<?php echo e(asset('js/jquery.js')); ?>" ></script>

    <script rel="stylesheet" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>

    

    

<!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/libs.css')); ?>" rel="stylesheet">


    

    <script rel="stylesheet" src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>


    

    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">

</head>
<body>
<div class="container">

    <div class="panel panel-success" >
        <div class="panel-body"  >

            <div class="navbar-wrapper">

                <div class="navbar navbar-default navbar-static-top" role="navigation">
                    <div class="container-fluid">

                        <div class="navbar-collapse collapse">
                            <div class="navbar-form navbar-left">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="<?php echo e(route('home.index')); ?>"><i class="fa fa-fw fa-home"></i> Home</a>
                            </div>
                            <div class="navbar-form navbar-right" >
                                <ul class="nav navbar-nav">
                                    <li >
                                        <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-th"></i> Logout</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="navbar-form navbar-right" >
                                <ul class="nav navbar-nav">
                                    <li >
                                        <a href="<?php echo e(route('password_view')); ?>"><i class="fa fa-fw fa-th"></i> Change Password</a>
                                    </li>
                                </ul>
                            </div>

                            <div class="navbar-form navbar-right">
                                <ul class="nav navbar-nav">
                                    <li>
                                        <form class="navbar-form navbar-right" role="search" action="<?php echo e(route('search')); ?>" method="post">

                                            <?php echo e(csrf_field()); ?>

                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Search" name="search" id="search" required/>
                                                <span class="input-group-btn">
                          <button class="btn btn-default" type="submit">&nbsp;<i class="fa fa-fw fa-search"></i></button>
                        </span>
                                            </div>
                                        </form>
                                    </li>
                                </ul>
                            </div>

                            <div class="navbar-form navbar-right">
                                <ul class="nav navbar-nav">

                                    <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                            <i class="fa fa-fw fa-th"></i> User Request Management<b class="caret"></b></a>

                                        <ul class="dropdown-menu">

                                    <?php if(Session::get('ismember') == 'true'): ?>

                                        <li class="navbar">
                                            <a href="<?php echo e(route('divHeadApprovalView')); ?>"><i class="fa fa-fw fa-th"></i>User Request Approval</a>
                                        </li>

                                        <?php endif; ?>

                                        <?php if(Session::get('cc_head') == 'true'): ?>

                                            <li class="navbar">
                                                <a href="<?php echo e(route('CCHeadApprovalView')); ?>"><i class="fa fa-fw fa-th"></i> CC Head Approval</a>
                                            </li>
                                        <?php endif; ?>
                                        </ul>
                                    </li>

                                </ul>


                            </div>




                        </div>
                    </div>
                </div>

            </div>


            <?php echo $__env->yieldContent('content'); ?>


        </div>

    </div>
</div>
</body>
</html>