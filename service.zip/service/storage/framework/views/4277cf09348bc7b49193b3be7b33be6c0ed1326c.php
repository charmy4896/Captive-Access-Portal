<?php $__env->startSection('content'); ?>

    <style>


        h1 {
            font-size: 16px;
            margin-top: 0;
        }

        #table-log {
            font-size: 16px ;
        }

        .btn {
            font-size: 0.7rem;
        }


        .stack {
            font-size: 0.85em;
        }

        .date {
            min-width: 75px;
        }

        .text {
            word-break: break-all;
        }
        

    </style>
        <div class="col-12 table-container">
            <?php if($logs === null): ?>
                <div>
                    Log file >50M, please download it.
                </div>
            <?php else: ?>
                <table id="table-log" class="table table-striped">
                    <thead>
                    <tr>
                        <th>Level</th>
                        <th>Context</th>
                        <th>Date</th>
                        <th>Content</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-display="stack<?php echo e($key); ?>">
                            <td class="text-<?php echo e($log['level_class']); ?>"><span class="fa fa-<?php echo e($log['level_img']); ?>"
                                                                             aria-hidden="true"></span> &nbsp;<?php echo e($log['level']); ?></td>
                            <td class="text"><?php echo e($log['context']); ?></td>
                            <td class="date"><?php echo e($log['date']); ?></td>
                            <td class="text">
                                <?php if($log['stack']): ?> <button type="button" class="float-right expand btn btn-outline-dark btn-sm mb-2 ml-2"
                                                            data-display="stack<?php echo e($key); ?>"><span
                                            class="fa fa-search"></span></button><?php endif; ?>
                                <?php echo e($log['text']); ?>

                                <?php if(isset($log['in_file'])): ?> <br/><?php echo e($log['in_file']); ?><?php endif; ?>
                                <?php if($log['stack']): ?>
                                    <div class="stack" id="stack<?php echo e($key); ?>"
                                         style="display: none; white-space: pre-wrap;"><?php echo e(trim($log['stack'])); ?>

                                    </div><?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            <?php endif; ?>
        </div>

<!-- Datatables -->
    <script src="<?php echo e(asset('DataTable/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/bootstrap.min.css')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.css')); ?>"></script>
<script>
    $(document).ready(function () {

        $('.table-container tr').on('click', function () {
            $('#' + $(this).data('display')).toggle();
        });

        $('#table-log').DataTable({
            "ordering" : false

        });
        $('#delete-log, #delete-all-log').click(function () {
            return confirm('Are you sure?');
        });

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>