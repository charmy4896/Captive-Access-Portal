<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-2 hidden-xs"></div>
        <div class="display col-md-8 col-xs-12">


            <div class="panel panel-info">
                <div class="panel-heading text-center">
                    <p class="panel-title">
                        <i class="fa fa-fw fa-user-o"></i>

                        <?php echo e($user_attributes['username']); ?>

                    </p>
                </div>

                <div class="panel-body">

                    <img src="<?php echo e(route('jpegphoto',$user_attributes['username'])); ?>" alt="" class="center-block" width ="300px" height = "300px">

                    <div class="table-responsive">
                        <table class="table table-striped table-hover">

                            <?php $__currentLoopData = $user_attributes['info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th class="hidden-xs">
                                <?php echo e($key); ?>

                            </th>
                            <td>
                                <?php echo e($value); ?>

                            </td>

                        </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>


                    </div>

            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.display_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>