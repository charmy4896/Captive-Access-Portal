<!doctype html>
<html lang="en">
<head>


</head>
<body>
<h1>Computer Division</h1>

<h2><br>
    Following User have requested  for Directory Access : <br>
    <?php echo e($userId); ?> <br>
 </h2>
</body>
</html>