<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-md-2 hidden-xs"></div>


        <div class="display col-md-8 col-xs-12">


            

                

                

                

            



            <div class="panel panel-info">
                <div class="panel-heading text-center">
                    <p class="panel-title">

                        <i class="fa fa-fw fa-user"></i>

                        <?php echo e($user_attributes['displayname']); ?>


                    </p>
                </div>


            <div class="panel-body">

                <img src="<?php echo e(route('jpegphoto', $user_attributes['username'])); ?>" alt="Not Available" class="center-block" width ="200px" height = "200px">



                <form action = "<?php echo e(route('upload')); ?>" id="myform" method="POST"  enctype="multipart/form-data" >
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <label class="btn btn-primary" for="my-file-selector">
                                <input id="my-file-selector" type="file" name = "upload" style="display:none;" onchange="return Upload()">

                                <script type="text/javascript">
                                    function Upload()
                                    {
                                        //Get reference of FileUpload.
                                        var fileUpload = document.getElementById("my-file-selector");
                                        //Check whether the file is valid Image.
                                        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png|.gif)$");
                                        if (regex.test(fileUpload.value.toLowerCase()))
                                        {

                                            //Check whether HTML5 is supported.
                                            if (typeof (fileUpload.files) != "undefined")
                                            {
                                                //Initiate the FileReader object.
                                                var reader = new FileReader();
                                                //Read the contents of Image File.
                                                reader.readAsDataURL(fileUpload.files[0]);
                                                reader.onload = function (e)
                                                {
                                                    //Initiate the JavaScript Image object.
                                                    var image = new Image();

                                                    //Set the Base64 string return from FileReader as source.
                                                    image.src = e.target.result;

                                                    //Validate the File Height and Width.
                                                    image.onload = function ()
                                                    {
                                                        var height = this.height;
                                                        var width = this.width;
                                                        if (height > 1024 || width > 1024)
                                                        {
                                                            alert("Height and Width must not exceed 1024px.");
                                                            return false;
                                                        }
                                                        //alert("Uploaded image has valid Height and Width.");
                                                        document.getElementById('myform').submit();
                                                        return true;
                                                    };

                                                }
                                            }
                                            else
                                            {
                                                alert("This browser does not support HTML5.");
                                                return false;
                                            }
                                        }
                                        else
                                        {
                                            alert("Please select a valid Image file.");
                                            return false;
                                        }
                                    }
                                </script>

                                <i class="fa fa-upload"></i>  Edit Profile Picture
                            </label>
                        </div>
                    </div>
                </form>
                <br/><br/>

                <ul class="nav nav-tabs">

                    <li class="active"><a data-toggle="tab" href="#general">General</a></li>
                    <li><a data-toggle="tab" href="#personal">Personal</a></li>
                    <li><a data-toggle="tab" href="#group">Group</a></li>
                    <li><a data-toggle="tab" href="#hosts">Access-Rights</a></li>
                </ul>

                <div class="tab-content">
                    <div id="general" class="tab-pane fade in active">
                        <h3>General</h3>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">

                                <?php $__currentLoopData = $user_attributes['general']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-center">
                                        <i class="fa  fa-<?php echo e($value['faclass']); ?>"></i>
                                    </th>
                                    <th>
                                        <b> <?php echo e($key); ?></b>

                                    </th>
                                    <td>
                                       <?php echo e($value['value']); ?>

                                    </td>

                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>

                    <div id="personal" class="tab-pane  fade">
                        <h3>Personal</h3>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">

                                <?php $__currentLoopData = $user_attributes['personal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <th class="text-center">
                                            <i class="fa fa-<?php echo e($value['faclass']); ?>"></i>
                                        </th>

                                        <th>
                                          <b><?php echo e($key); ?></b>
                                        </th>
                                        <td>
                                            <?php echo e($value['value']); ?>

                                        </td>


                                    </tr>





                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </table>
                        </div>
                    </div>

                    <div id="group" class="tab-pane  fade">
                        <h3>Group</h3>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">


                                <tbody>
                                <tr>

                                    <td>
                                    <th class="text-center">
                                        <em class="fa fa-fw fa-users"></em>
                                    </th>

                                    </td>

                                    <td>
                                        Groups
                                    </td>



                                    <td>

                                        <?php if(key_exists('group',$user_attributes)): ?>

                                            <?php $__currentLoopData = $user_attributes['group']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                                <?php echo e($value); ?>

                                                <br>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>

                                    </td>

                                </tr>




                                </tbody>

                            </table>
                        </div>
                    </div>

                    <div id="hosts" class="tab-pane  fade">
                        <h3>Hosts</h3>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">


                                <tbody>
                                <tr>

                                    <td>
                                    <th class="text-center">
                                        <em class="fa fa-fw fa-users"></em>
                                    </th>

                                    </td>

                                    <td>
                                        Groups
                                    </td>



                                    <td>

                                        <?php if(key_exists('access_rights',$user_attributes)): ?>

                                            <?php $__currentLoopData = $user_attributes['access_rights']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                                <?php echo e($value); ?>

                                                <br>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>

                                    </td>

                                </tr>




                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>

            </div>


                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-9">
                        <a href="<?php echo e(route('employee.edit',$user_attributes['username'])); ?>">
                        <button type="submit" name="submit" class="btn btn-success">
                            Edit Profile</button></a>
                    </div>
                </div>

         </div>

        <div class="col-md-2 hidden-xs"></div>

    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.display_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>