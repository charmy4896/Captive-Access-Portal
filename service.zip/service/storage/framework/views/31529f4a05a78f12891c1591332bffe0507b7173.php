<?php $__env->startSection('content'); ?>


    <script src="<?php echo e(asset('DataTable/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/bootstrap.min.css')); ?>"></script>
    <script src="<?php echo e(asset('DataTable/dataTables.bootstrap.min.css')); ?>"></script>


    <?php echo $__env->make('flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo e(Session::forget('success')); ?>


    <?php echo e(Session::forget('error')); ?>





    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h3 class="panel-title">Users to be disable in Current Month</h3>
                    </div>

                </div>
            </div>
            <div class="panel-body">

                <table id="mytable1" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>

                        <th>Username</th>
                        <th>Date</th>
                        <th>Status</th>

                    </tr>
                    </thead>
                    <tbody>

                    <?php if($currentMonthUsers != null): ?>

                        <?php $__currentLoopData = $currentMonthUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><a href="<?php echo e(route('showUserProfile',  $user['username'])); ?>"><?php echo e($user['username']); ?></a></td>

                                <td><?php echo e($user['date']); ?></td>

                                <?php if($user['status'] == 'true' or $user['status'] == '1'): ?>

                                    <td> Disabled</td>


                                <?php else: ?>

                                    <td>Enabled</td>

                                <?php endif; ?>



                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>



                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <div class="col-md-10 col-md-offset-1">

        <div class="panel panel-default panel-table">
            <div class="panel-heading">
                <div class="row">
                    <div class="col col-xs-6">
                        <h3 class="panel-title">Users disabled in Previous Month</h3>
                    </div>
                </div>
            </div>
            <div class="panel-body">

                <table id="mytable" class="table table-striped " cellspacing="0" width="100%">
                    <thead>
                    <tr>

                        <th>Username</th>
                        <th>Date</th>
                        <th>Status</th>

                    </tr>
                    </thead>
                    <tbody>

                    <?php if($prevMonthUsers != null): ?>

                    <?php $__currentLoopData = $prevMonthUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><a href="<?php echo e(route('showUserProfile',  $user['username'])); ?>"><?php echo e($user['username']); ?></a></td>

                            <td><?php echo e($user['date']); ?></td>



                            <td>Disabled</td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>



                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <style>
        .panel-table .panel-body{
            padding:0;
        }

        .panel-table .panel-body .table-bordered{
            border-style: none;
            margin:0;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type {
            text-align:center;
            width: 100px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:last-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:last-of-type {
            border-right: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr > th:first-of-type,
        .panel-table .panel-body .table-bordered > tbody > tr > td:first-of-type {
            border-left: 0px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr:first-of-type > td{
            border-bottom: 0px;
        }

        .panel-table .panel-body .table-bordered > thead > tr:first-of-type > th{
            border-top: 0px;
        }

        .panel-table .panel-footer .pagination{
            margin:0;
        }


        /*
        used to vertically center elements, may need modification if you're not using default sizes.
        */
        .panel-table .panel-footer .col{
            line-height: 34px;
            height: 34px;
        }

        .panel-table .panel-heading .col h3{
            line-height: 30px;
            height: 30px;
        }

        .panel-table .panel-body .table-bordered > tbody > tr > td{
            line-height: 30px;
        }
        .row {
            padding-bottom: 10px;
        }

        #example_length {
            padding-left: 10px;
        }

        .dataTables_info{
            padding-left: 10px;
            padding-top: 10px;
        }


    </style>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable();

            $('#mytable1').DataTable();

        } );

    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.Admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>