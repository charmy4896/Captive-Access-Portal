<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserCcHeadApprovalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_cc_head_approvals', function (Blueprint $table) {
            $table->increments('id');
            $table->string('cc_head_id');
            $table->string('cc_head_email');
            $table->timestamp('last_updated');
            $table->string('enabled_status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_cc_head_approvals');
    }
}
