<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserDivHeadApprovalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_div_head_approvals', function (Blueprint $table) {
            $table->increments('id');
            $table->string('user_id');
            $table->string('div_head_id');
            $table->string('user_email');
            $table->string('div_head_email');
            $table->string('payroll_no')->nullable();
            $table->string('div_head_status');

            $table->timestamp('request_date')->nullable();
            $table->timestamp('div_approval_date')->nullable();
            $table->string('cc_head_email')->nullable();
            $table->string('cc_head_approval_status')->nullable();
            $table->timestamp('cc_head_approval_date')->nullable();
            $table->timestamp('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_div_head_approvals');
    }
}
