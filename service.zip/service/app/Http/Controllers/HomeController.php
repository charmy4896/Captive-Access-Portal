<?php

namespace App\Http\Controllers;

use Adldap\AdldapInterface;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $ldap;

    protected  $connection;


    public function __construct(AdldapInterface $ldap)
    {
        $this->ldap = $ldap;

        $this->connection = $this->ldap->getDefaultProvider()->getConnection();


    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     *
     */

    public function checkGroupMember(){


      try{
          $username = Session()->exists('admin_username')? Session()->get('admin_username') : Session()->get('username');

          $userDn = 'uid='.$username.','.Session()->get('base_dn');

          $userRead =  $this->connection->read($userDn,ldap_base('ldap_user_filter'),array('ismemberof'));

          $userEntry  = $this->connection->getEntries($userRead);

          $userEntry = $userEntry[0];

          if(array_key_exists('ismemberof',$userEntry)){

              // if true then include UserRequestApproval tab  else not needed

              $isMemberOf = $userEntry['ismemberof'];

              unset($isMemberOf['count']);

              foreach ($isMemberOf as $groupMember){

                  //  cn=newGroup1,ou=OrgGroups,o=IPR,dc=ipr,dc=res,dc=in

                  if ( strpos($groupMember,'OrgGroups') != false){

                      Session()->put('ismember','true');

                  }
              }

          }


          // Check whether user is CC HEAD using DB
          $cc_head = DB::select('select * from user_cc_head_approvals where cc_head_id = ? ',[$username]);

          if ($cc_head != null){
              if ($cc_head[0]->enabled_status == 1){

                  Session()->put('cc_head','true');
              }
          }
      }catch (QueryException $q){

          Session()->put('error',' SQLSTATE[HY000] [2002] Connection refused Contact Administrator');



      }

    }

    public function index(Request $request)
    {

          $this->checkGroupMember();

        if($request->session()->exists('admin_username')){

            $admin_username = $request->session()->get('admin_username');

            if($admin_username != null){

                // change Dashboard
                return redirect('/Admin/home');
            }

        }else{

            $username = $request->session()->get('username');

            if($username != null){

                return view('Employee.display',compact('username'));

          //      return view('Employee.display');

            }
        }

       return redirect('/login');

    }


    // view user profile
    public function viewProfile(Request $request){

        $user_dn = 'uid='.$request->session()->get('username').','.$request->session()->get('base_dn');


        $user_attributes = $this->getUserInfo($user_dn);


        return view('Employee.viewprofile',compact('user_attributes'));

    }

    public function getUserInfo($user_dn){

        try{

            $user = getUserObject($this->connection,$user_dn);      // functions.inc.php

            $user_attributes['username'] = $user->getCommonName();

            $user_attributes['displayname'] = $user->getDisplayName();


            $user_attributes['general'] = attributes_map($user,'general');  // config.inc.php

            $user_attributes['personal'] = attributes_map($user,'personal');  // config.ibc.php


            $orgs = array();

            $access_rights = array();

            $ismember = $user->getAttribute('ismemberof');


            unset($ismember['count']);

            if($ismember != null) {
                foreach ($ismember as $key => $value) {

                    // code for fetching OU for checking whether it is OrgGroup or Security Group
                    $del = explode(',', $value);

                    $count = count($del);

                    $ou = substr('' . $del[$count - 5] . '', 3);

                    // check whether OU is orgGroups
                    if ($ou == 'OrgGroups') {

                        // fetch orgName from IsMember attribute
                        $orgName = substr('' . $del[0] . '', 3);

                        array_push($orgs, $orgName);
                    } // else OU is security Group
                    else if ($ou == 'SecurityGroups') {

                        $access_right = substr('' . $del[0] . '', 3);

                        array_push($access_rights,$access_right);

                    }
                }
            }

            $user_attributes['access_rights'] = $access_rights;

            $user_attributes['group'] = $orgs;

            return $user_attributes;

        }catch (\Adldap\AdldapException $e){
            echo $e->getMessage();
        }


    }


    // user profile picture upload
    public function upload(Request $request){

        $session = $request->session();

            if($file = $request->file('upload')) {

                  $username = $session->exists('username') ? $session->get('username') : $session->get('admin_username');

                  $user_dn = 'uid='.$username.','.$session->get('base_dn');

                  $entry['jpegphoto'] = file_get_contents($file);

                  try{

                      $connection = $this->ldap->getDefaultProvider()->getConnection();

                      $result = $connection->modify($user_dn,$entry);

                      if($result){

                          $request->session()->put('success','Profile Photo updated');


                          return redirect('/home');

                      }else{

                          $request->session()->put('error','Error while uploading try later');

                      }

                  }catch(\Adldap\AdldapException $e){

                      $request->session()->put('error',$e->getMessage());

//                      echo $e->getMessage();
                  }

            }
      //  return $request->all();

    }


    // fetch user profile picture from LDAP Server
    public function photo(Request $request,$username){

        $user_dn = 'uid='.$username.','.$request->session()->get('base_dn');

        $user = getUserObject($this->connection,$user_dn);

        $jpegphoto = $user->getJpegPhoto();

        if($jpegphoto == ''){

            if($user->getInitials() == 'Mr.'){

                $photo = imagecreatefromjpeg(public_path().'/images/mrdefault.jpg');
            }else if ($user->getInitials() == 'Mrs.'){
                $photo = imagecreatefromjpeg(public_path().'/images/msdefault.jpg');
            }else if($user->getInitials() == 'Dr.'){
                $photo = imagecreatefromjpeg(public_path().'/images/drdefault.jpg');

            }else if ($user->getInitials() == 'Prof.'){
                $photo = imagecreatefromjpeg(public_path().'/images/profdefault.jpg');
            }else{
                $photo = imagecreatefromjpeg(public_path().'/images/default.jpg');
            }
        }else{
            $photo = imagecreatefromstring($jpegphoto);
        }



        header('Content-Type: image/jpeg');

        imagejpeg($photo);

        imagedestroy($photo);

        echo $photo;


    }


    public function search(Request $request){

        try{

            $connection = $this->ldap->getDefaultProvider()->getConnection();

            $ldap_filter = "(&(objectclass=ipruseraccount)(uid={login}*))";

            $ldap_filter = str_replace("{login}", $request->search, $ldap_filter);

            $result = $connection->search(ldap_base('ldap_base'), $ldap_filter, ['*']);

            $entries = $connection->getEntries($result);

            $builder = new \Adldap\Query\Builder($connection);

            $builder->setSchema();

            $count = 0;

            $users = array();

            if($entries['count'] > 0)
            {

                unset($entries['count']);

                foreach ($entries as $key => $value){

                    $user = new \Adldap\Models\User($value,$builder);

                    $users[$count] = $user;

                    $count ++ ;
                }
            }


            return view('index',compact('users','count'));

        } catch(\Adldap\AdldapException $e){

            $request->session()->put('error','No found');

            return view('index');
        }catch(\ErrorException $e){

            $count = null;

            $users = null;

            $request->session()->put('error','No User Found');

            return view('index',compact('users','count'));

        }
    }



    public function logout(Request $request){
        $request->session()->flush();

//        $request->session()->put('success','Successfully Logout');
        return redirect('/login');
    }




    // Search Results User Display profile function
    public function profile(Request $request,$username){

        $user_dn = 'uid='.$username.','.$request->session()->get('base_dn');


        try{

            $user = getUserObject($this->connection,$user_dn);

            $user_attributes['info'] = attributes_map($user,'user_search_items');

            $user_attributes['username'] = $user->getCommonName();


        }catch (\Adldap\AdldapException $e){
            echo $e->getMessage();
        }

        return view('Employee.profile',compact('dn','user_attributes'));
    }



    public function password_change_view(Request $request){

        return view('Employee.password_change');
    }

}
