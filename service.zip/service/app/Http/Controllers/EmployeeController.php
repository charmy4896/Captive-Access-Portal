<?php

namespace App\Http\Controllers;

use Adldap\Adldap;
use \Adldap\AdldapInterface;
use App\user_cc_head_approval;
use function Composer\Autoload\includeFile;
use Illuminate\Contracts\Auth\Guard;
use App\Http\Requests\CreateEmployeeRequest;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\user_div_head_approval;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

use Illuminate\Database\Connection;


class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    protected  $ldap;

    protected $auth;

    protected $connection;

    protected  $log;



    public function __construct(AdldapInterface $adldap, Guard $auth)
    {
        $this->ldap = $adldap;
        $this->auth = $auth;

        $this->connection = $this->ldap->getDefaultProvider()->getConnection();

        // Logger
        $this->log = new Logger('name');

        $this->log->pushHandler(new StreamHandler(storage_path('/logs/laravel.log'), Logger::INFO));
    }
    public function index()
    {
        //
        return view('Employee.create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

        return view('Employee.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */




    public function store(CreateEmployeeRequest $request)
    {

        // convert all input data to Array coming from EMPLOYEE CREATE FORM
        $attributes = $request->toArray();

        $rules = ['captcha' => 'required|captcha'];

        $validator = Validator::make(Input::all(), $rules);

        try{

            if($validator->fails()) {

                $request->session()->put('error', 'Incorrect Captcha ');

                return view('Employee.create');
            }

            unset($attributes['captcha']);

            //set LDAP options
           $this->connection =  setLDAPOptions($this->connection);      // functions.inc.php line 111

     //     $attributes = change_array_index('employee',$attributes);

            // added
           $attributes = changeIndexEmployeeCreateForm($attributes);   // functions.inc.php  198
            // end added


            $attributes = set_object_class($attributes);                //functions.inc.php line 81

            $attributes = delete_empty_index($attributes);              // functions.inc.php line 98


            if (array_key_exists('manager',$attributes)){
                // save manager UID
                $manager = getUID($attributes['manager']);

                $attributes['manager'] = 'uid='.$manager.','.ldap_base('ldap_user_base');
            }

            // user DN
            $dn_user = 'uid='.$attributes['uid'].','. ldap_base('ldap_user_base');

            // checks Username in ldap return true if Username is Unique
            $result = check_username_unique($this->connection,$attributes['uid']);          // functions.inc.php 124


            if($result ){


                $added_user =$this->connection->add($dn_user,$attributes);

            }else{

                $request->session()->put('error','Username Already Exists');

                return view('Employee.create') ;
            }

            // successfully User Added then send Mail to DivHead
            if ($added_user){


                // try catch to handle Error related to  Mail failed to send
                try{
                    if (array_key_exists('manager',$attributes)){

                        // send mail to division Head for Request Approval
                        if (array_key_exists('employeenumber',$attributes)){

                            $this->sendMailToDivHead($attributes['mail'],$manager,$attributes['uid'],$attributes['employeenumber']);

                        }else{

                            $this->sendMailToDivHead($attributes['mail'],$manager,$attributes['uid'],null);
                        }
                    }
                }catch (\ErrorException $e){            // handle error of Mail failed to send

                    $request->session()->put('error','Account Created successfully Contact Adminisrator '.$e->getMessage());

                    return view('Employee.create');

                }

                // flash success message on to screen
                $request->session()->put('success','Your Registration is Successfull');

                return view('Employee.create');

            }else{

                // Failed to Add New User Account Flash error Message
                $request->session()->put('error', 'Your Registration is Unsuccessfull Please Contact Administration');
                return view('Employee.create');
            }

        }catch (\ErrorException $e){

            // in case if Can't Connect LDAP server, Flash error Message
            $request->session()->put('error', $this->connection->getLastError());

            return view('Employee.create');
        }
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    public function edit(Request $request,$id)
    {
        //
            try{

                $user_dn = 'uid='.$id.','.$request->session()->get('base_dn');

                // get User Object
                $user = getUserObject($this->connection,$user_dn);      // functions.inc.php

                return view('Employee.editProfile',compact('user'));

            }catch (\ErrorException $e){


                $request->session()->put('error',$e->getMessage());

                $user = null;

                return view('Employee.editProfile',compact('user'));

            }
    }



    public function changePassword(Request $request){

       try{

           $session = $request->session();

           $username = $session->get('username');

           $user_dn = 'uid='.$username.','.$session->get('base_dn');

           $checkOldPassword = checkOldPassword($this->ldap,$user_dn,$request->oldpassword);  // functions.inc.php line 255

           if($checkOldPassword){

               if(!$this->connection->canChangePasswords()){

                   $this->connection->tls(true);
               }

               $userdata['userpassword'] = $request->newpassword;

               $result = $this->connection->modReplace($user_dn,$userdata);

               if ($result){

                   $request->session()->put('success','Successfully Password Updated');

                   return view('Employee.password_change');

                   //  return 'Succesfully Password Changed';
               }else{

                   $request->session()->put('error','Error While Updating Password');

                   return view('Employee.password_change');
               }
           }else{
               $request->session()->put('error','Old Password is Incorrect');

               return view('Employee.password_change');
           }
       }catch (\ErrorException $e){

           $request->session()->put('error',$e->getMessage());

           return view('Employee.password_change');
       }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //
        try{

            $session = $request->session();

        $username =  $session->get('username');

        $attributes = $request->toArray();

        $user_dn = 'uid='.$username.','.$session->get('base_dn');

         $attributes = changeIndexEditForm($attributes);         // functions.inc.php

            $attributes = delete_empty_index($attributes);         // functions.inc.php

            $results = $this->connection->modify($user_dn,$attributes);

            if ($results){

                $session->put('success','Successfully Profile updated');

                return redirect('/home');
            }



        }catch (\ErrorException $e){

            $session->put('error','Update Failed try it later');


        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }







    // send mail div head for approval
    public function sendMailToDivHead($userMail,$divHead,$uid,$userPayrollNo)
    {

        // fetching Div Head  Information ( MAIL)
        $usr_dn = 'uid='.$uid.','.ldap_base('ldap_user_base');

        $divHeadDn = 'uid='.$divHead.','.ldap_base('ldap_user_base');

        $ldap_filter = "objectclass=ipruseraccount";

        $headSearch = $this->connection->search($divHeadDn, $ldap_filter, array('mail', 'uid'));

        $divHeadEntry = $this->connection->getEntries($headSearch);

        $divHeadEntry = $divHeadEntry[0];

        // send emai to $to
        $divHeadEmailID = $divHeadEntry['mail'][0];

        // div Head ID
        $divHeadId = $divHeadEntry['uid'][0];


        // Get CC head email
        $cc_head = DB::select('select * from user_cc_head_approvals where enabled_status = ? LIMIT 1',[1]);

       $cc_head_email =  $cc_head[0]->cc_head_email;

        // update user_div_head_approval

        $user_id = $uid;

        $div_head_id = $divHeadId;

        $user_email = $userMail;

        $div_head_email = $divHeadEntry['mail'][0];

        $payroll_no = $userPayrollNo;

        $status = 'pending';


        try{

            user_div_head_approval::insert([

                'user_id' => $user_id,
                'div_head_id' => $div_head_id,
                'user_email' => $user_email,
                'div_head_email' => $div_head_email,
                'payroll_no' => $payroll_no,
                'div_head_status' => $status,
                'cc_head_email' => $cc_head_email,
                'request_date' => date('y-m-d  h:m:s'),
                'cc_head_approval_status' => $status
            ]);

        } catch (QueryException $q){

            // log
            $this->log->error($q->getMessage(),[$usr_dn]);

            Session()->put('error',$q->getMessage() .'User Account Created but Mail failed to Sent Contact Administrator');

            return view('Employee.create');

        }

        // data array is sent along with view body
        $data = [
            'to' => $divHeadEmailID,
            'userId' => $uid,
            'divHeadId' => $divHeadId
        ];

        $divHead = DivHead();   // config.inc.php

        sendMail($data,$divHead);   // functions.inc.php

        $this->log->info('Mail have been sent to Division Head' .$div_head_email. ' for User Request Approval',[ $usr_dn]);

    }

    // Div Head Approval
    public function divHeadApprovalView(Request $request)
    {

        // divHeadApprovalView consists User_ID, Payroll_No, Group_Head_ID,
        try{
          $divHeadInfo = array();

          $userId = session()->exists('username') ? session()->get('username') : session()->get('admin_username');

          $div_head_approval_info = user_div_head_approval::all();

          foreach ($div_head_approval_info as $info){

              if($info['div_head_id'] ==  $userId){

                  $divHeadInfo[] = $info;
              }

          }
      }catch (QueryException $e){

          $divHeadInfo = null;

          $request->session()->put('error',$e->getMessage());

          return view('index.DivHeadApproval.userDivHeadApproval', compact('divHeadInfo'));

      }

      return view('index.DivHeadApproval.userDivHeadApproval', compact('divHeadInfo'));

    }



    public function divHeadApproval(Request $request){

       try{
           $userId = $request->user_id;

           $user_dn = 'uid='.$userId.','.ldap_base('ldap_user_base');

           $entry['divHead'] = 0;

           user_div_head_approval::where('user_id',$userId)->update(['div_head_status' => 'Approved' ,
               'div_approval_date' => date('y-m-d  h:m:s') , 'remarks' => $request->remarks]);

           $date = date('y-m-d h:m:s');

           $result = $this->connection->modify($user_dn,$entry);

           if ($result){
               // log record
               $this->log->info('User Request Approval from Division Head at '. $date ,[ $user_dn ]);


               // SQL User record from user_div_head_approval//
               $div_head_record =   DB::table('user_div_head_approvals')->where('user_id',$userId)->first();


               // fetch  CC-head email
               $cc_head_email = $div_head_record->cc_head_email;

               $this->sendMailToCCHead($request->user_id,$cc_head_email);

               return 'true';
           }else{
               return 'false';
           }
       }
    catch (QueryException $q){

            //log
            $this->log->error($q->getMessage(),[$user_dn]);

            $request->session()->put('error',$q->getMessage(). ' Contact Administrator');

            return $q->getMessage();

        }
    }


    public function divHeadDisApproval(Request $request){

       try{

           $user_dn = 'uid='.$request->user_id.','.ldap_base('ldap_user_base');

           $entry['divHead'] = 1;

           $result = $this->connection->modify($user_dn,$entry);

           user_div_head_approval::where('user_id',$request->user_id)->update([ 'div_head_status' => 'Disapproved']);

           if ($result){

               // log record
               $this->log->info('User Request Dispproval from Division Head',[ $user_dn]);


               return 'true';

           }else{

               return 'false';

           }
       }catch (QueryException $q){

           //log
           $this->log->error($q->getMessage(),[$user_dn]);

           $request->session()->put('error',$q->getMessage(). ' Contact Administrator');

           return $q->getMessage();

           }
    }


    // send Mail to CC head
    public function sendMailToCCHead($userId,$cc_head_email){

        $user_dn = 'uid='.$userId.','.ldap_base('ldap_user_base');

        $div_head_record =  DB::table('user_div_head_approvals')->where('user_id',$userId)->first();

        $divHeadId = $div_head_record->div_head_id;

        $data = [
            'to' => $cc_head_email,
            'userId' => $userId,
            'divHeadId' => $divHeadId,
            'remarks' => $div_head_record->remarks
        ];

        $cchead = CCHead();   // config.inc.php

        sendMail($data,$cchead);        //functions.inc.php

        $this->log->info('Mail have been sent to CC Head' .$cc_head_email. ' for User Request Approval after 
        Division Head Approval',[ $user_dn]);

    }

    public function  CCHeadApprovalView(Request $request){

      try{

          $div_head_record = user_div_head_approval::all();

          $pendingRequest = array();

          $otherRequest = array();

          foreach ($div_head_record as $record){

              if($record->cc_head_approval_status == 'pending'){

                  $pendingRequest[] = $record;

              }else{

                  $otherRequest[] = $record;

              }

          }
      }catch(QueryException $e){

          $pendingRequest = null;

          $otherRequest = null;

          $request->session()->put('error','SQLSTATE[HY000] [2002] Connection refused');

          return view('index.CCHeadApproval.userCCHeadApproval', compact('pendingRequest','otherRequest'));

      }

        return view('index.CCHeadApproval.userCCHeadApproval', compact('pendingRequest','otherRequest'));

    }

    public function CCHeadApproval(Request $request){

        try{
            $userId = $request->user_id;

            $user_dn = 'uid='.$userId.','.ldap_base('ldap_user_base');

            $entry['cchead'] = 0;

            $date = date('y-m-d h:m:s');

            user_div_head_approval::where('user_id',$userId)->update(['cc_head_approval_status' => 'Approved' ,
                'cc_head_approval_date' => date('y-m-d  h:m:s')]);

            $result = $this->connection->modify($user_dn,$entry);

            if ($result){



                // log record
                $this->log->info('User Request Approval from CC Head at ' . $date,[ $user_dn]);

                $this->log->info('Mail has been sent to COMPUTER DIVISION');

                //fetching remarks from SQL
                $remarks =  DB::table('user_div_head_approvals')->where('user_id',$userId)->first();

                $this->SendMailToComputerDivision($userId,$remarks->remarks);




                // fetch mail from ldap
                $emailRead = $this->connection->read($user_dn,ldap_base('ldap_user_filter'),array('mail'));

                $emailResult = $this->connection->getEntries($emailRead);

                $emailResult = $emailResult[0];

                $email = $emailResult['mail'][0]; // user email


                // set user password
                $tempPassword=$this->createRandomString();

                $entry['userpassword'] = $tempPassword;

                $setPass = $this->connection->modify($user_dn,$entry);

                if ($setPass) {

                    // Mail temp password to User Mail
                    $this->sendPassword($email, $tempPassword, $user_dn);
                }

                return 'true';
            }else{
                return 'false';
            }
        } catch (QueryException $q){

            //log
            $this->log->error($q->getMessage() . 'CC-HEAD APPROVAL',[$user_dn]);

            $request->session()->put('error',$q->getMessage(). ' Contact Administrator');

            return $q->getMessage();

        }
    }


    public function CCHeadDisApproval(Request $request){

      try{

          $user_dn = 'uid='.$request->user_id.','.ldap_base('ldap_user_base');

          user_div_head_approval::where('user_id',$request->user_id)->update([ 'cc_head_approval_status' => 'Disapproved']);

          $entry['cchead'] = 1;

          $result = $this->connection->modify($user_dn,$entry);

          unset($entry['cchead']);

          if ($result){

              // log record
              $this->log->info('User Request Disapproval from Division Head',[ $user_dn]);

              return 'true';

          }else{

              return 'false';

          }

      }
    catch (QueryException $q){

            //log
            $this->log->error($q->getMessage() . 'CC-HEAD DISAPRROVAL',[$user_dn]);

            $request->session()->put('error',$q->getMessage(). ' Contact Administrator');

            return $q->getMessage();

        }
    }  // end of cchead Disapproval



    public function SendMailToComputerDivision($userId,$remarks){


        $ccDivision = CCDivision();   // config.inc.php

        $data = [
            'userId' => $userId,
            'to' => $ccDivision['email'],
            'remarks' => $remarks

        ];

        sendMail($data,$ccDivision);             //functions.inc.php


    }  // end of SendMailToComputerDivision()




    public function sendPassword($email,$password,$user_dn)
    {

        $passInfo = sendPassword();

        $data = [
            'to' => $email ,
            'password' => $password
        ];

        sendMail($data,$passInfo);  // functions.inc.php

        $this->log->info('Password has been sent to'. $email,[ $user_dn]);


    }   //end of sendPassword()



    function createRandomString()
    {
        $length=8;
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }  // end of createRandomString()

}
