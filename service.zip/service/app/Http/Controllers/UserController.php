<?php

namespace App\Http\Controllers\Auth;

namespace App\Http\Controllers;
use Adldap\AdldapInterface;
use Illuminate\Http\Request;


class UserController extends Controller
{

    protected $ldap;
   
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct(AdldapInterface $ldap)
    {
        $this->ldap = $ldap;
    }
    public function index()
    {
        return view('addUser');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        try {

            $provider = $this->ldap->getDefaultProvider();

            $user = $provider->make()->user();

            $cn = $request->firstname.$request->lastname;

            $user->setDistinguishedName('cn='.$cn.',ou='.$request->category.',o='.$request->organization.',dc=ipr,dc=in');

            $user->setFirstName($request->firstname);

            $user->setLastName($request->lastname);

            $user->setCommonName($cn);

            $user->setEmail($request->emailaddress);

            $user->setRoomNumber($request->officeroomnumber);

            $user->setAttribute('objectclass', 'inetOrgPerson');

            dd($user->save());
        }catch (\Adldap\AdldapException $e){
            echo $e;
        }





    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
