<?php

namespace App\Http\Controllers\Auth;

use Adldap\AdldapInterface;

use Adldap\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    protected  $ldap;

 //   protected $auth;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(AdldapInterface $adldap)
    {
        $this->ldap = $adldap;

      //  $this->auth = $auth;

      //  $this->middleware('guest');
    }


    /**
     * @param Request $request
     */
    public function sendResetLinkEmail(Request $request)
    {
        $data = [
            'emailId' => $request->email ,
            'from' => 'nilpatel111296@gmail.com',

         ];
        Mail::send('auth.passwords.forgotPassword',$data,function($message) use ($data){

            $message->to($data['emailId'])->from($data['from'])->subject('Change Password');
        });
    }

    /**
     * @param Request $request
     */
    public function updatePasswordInDirectory(Request $request){

            $username =  $request->username;
            $password = $request->password;


            try{

                $provider = $this->ldap->getDefaultProvider();

                $connection = $provider->getConnection();

                $builder = new \Adldap\Query\Builder($connection);

                $builder->setSchema();

                $ldap_filter = "(&(objectclass=ipruseraccount)(uid={login}))";

                $ldap_filter = str_replace("{login}", $username, $ldap_filter);

                $search = $connection->search('dc=ipr,dc=res,dc=in', $ldap_filter,['*']);

                $entry = $connection->getEntries($search);

                $user = new User($entry,$builder);






//              $user = new User($attributes[0]['attributes'],$provider->search()->users()->listing());
//
//               $user->setDn($user->distinguishedname[0]);




            }catch (\Adldap\AdldapException $e) {
                echo $e;
            }

    }
}