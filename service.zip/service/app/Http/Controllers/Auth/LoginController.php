<?php

namespace App\Http\Controllers\Auth;


use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;


use Adldap\AdldapInterface;


class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
//   protected $redirectTo = '/home';

    protected  $ldap;

    protected $log ;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(AdldapInterface $ldap )
    {

        try{
            $this->ldap =$ldap;
            $this->middleware('guest')->except('logout');

            $this->log = new Logger('name');
            $this->log->pushHandler(new StreamHandler(storage_path('/logs/laravel.log'), Logger::INFO));

        }catch (\ErrorException $e){

            Session()->put('error','Something went wrong ' . $e->getMessage());

            $this->getBackToHome();

        }

        }

        public function getBackToHome(){

                return redirect('/login');

        }


    public function  login(Request $request){
        try{

            // Captcha
            $captcha = $request->captcha;

            $rules = ['captcha' => 'required|captcha'];

            $validator = Validator::make(Input::all(), $rules);


            $username  = stripcslashes($request->login);

            $password = stripcslashes($request->password);

            $provider = $this->ldap->getDefaultProvider();

            $connection = $provider->getConnection();

            $user_dn = 'uid='.$username.','.ldap_base('ldap_user_base');

            if ($request->session()->get('username') != null){

                return redirect('/home');

            }else if ($request->session()->get('admin_username') != null){

                return redirect('/home');

            }

            if($provider->auth()->attempt($user_dn,$password,true)) {


                if($validator->fails()){


                    $request->session()->put('error','Incorrect Captcha ');


                    return redirect('/login');

                }


                $ldap_user_filter = "(objectClass=ipruseraccount)";

                $Admindn = ldap_base('ldap_admin_bind').ldap_base('ldap_hosts_base');

               $search = $connection->read('uid='.$username.','.ldap_base('ldap_user_base'),$ldap_user_filter,array('ismemberof','ds-pwp-account-disabled'));

                $entries = $connection->getEntries($search);


                $present = array_key_exists('ismemberof',$entries[0]);

                $request->session()->put('base_dn',ldap_base('ldap_user_base'));

                if($entries['count'] > 0){

                    if($present){

                        $groups = $entries[0]['ismemberof'];

                        unset($groups['count']);

                            foreach ($groups as $key => $group){

                                if ($group == $Admindn){

                                    // if user is member of Directory Admin then store admin_username inside session
                                    $request->session()->put(['admin_username' => $username]);
                                    $request->session()->save();

                                    // forget username if stored inside session
                                    $request->session()->forget('username');

                                    return redirect('/home');
                                }
                                else{

                                    $request->session()->put(['username' => $username]);
                                    $request->session()->save();

                                }
                        }

//                        $this->log->info('User Successfully Logged',[ $user_dn ]);

                        return redirect('/home');

                   }else{

                       $request->session()->put('loginMsg','Your Account is disabled');
//
                        return redirect('/login');

//                        $request->session()->put(['username' => $username]);
//                        $request->session()->save();
//                        return redirect('/home');

                    }
                }

            }else{

                // invalid Username or password
                $request->session()->put('loginMsg', $connection->getLastError()) ;
                return redirect('/login');
            }


    }catch (\ErrorException $e) {

            $request->session()->put('error','Something Went Wrong '.$e->getMessage());

            return redirect('/login');

        }
    }

    public function logout(Request $request){

        $request->session()->flush();

        return redirect('/login');
    }

}
