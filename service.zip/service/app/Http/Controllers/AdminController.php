<?php




namespace App\Http\Controllers;


use App\Events\deadline;
use Illuminate\Http\Request;
use Adldap\AdldapInterface;


use Illuminate\Support\Facades\DB;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;


class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    protected $ldap;

    protected $connection;

    protected $provider;

    protected  $request;

    protected  $log;

    public function __construct(AdldapInterface $ldap)
    {

        // Setting LDAP connection ($connection) and its provider  ($provider)
        $this->ldap = $ldap;

        $this->provider = $this->ldap->getDefaultProvider();

        $this->connection = $this->provider->getConnection();

        $this->request = app('request');

        // Logger
        $this->log = new Logger('name');

        $this->log->pushHandler(new StreamHandler(storage_path('/logs/laravel.log'), Logger::INFO));
    }

    public function index()
    {
        //

        try{

            $info['totalusers'] = $this->totalUsers();

            $info['unlockedusers'] = $this->unlockedUsers();

            $info['lockedusers'] = $this->lockedUsers();

            $username = Session()->get('admin_username');


        }catch(\ErrorException $e){

            $username = null;

            $info = null;

            session()->put('error',$e->getMessage());

            return view('Admin.home',compact('username','info'));

        }



        return view('Admin.home',compact('username','info'));

    }

    // return totalUsers in digit
    public function totalUsers(){


        $searchUsers = $this->connection->search(ldap_base('ldap_user_base'),ldap_base('ldap_user_filter'),array('ds-pwp-account-disabled'));

        $result = $this->connection->getEntries($searchUsers);

        return $result['count'];
    }   // end of totalUsers





    // return LockedUsers in digit
    public function lockedUsers(){

        $searchUsers = $this->connection->search(ldap_base('ldap_user_base'),ldap_base('ldap_user_filter'),array('ds-pwp-account-disabled'));

        $entries = $this->connection->getEntries($searchUsers);

        // store number of locked users
        $no_of_locked_users = 0;

        // $count for indexing
        $count = 0;

        if ($entries['count'] > 0) {

            unset($entries['count']);

            while (array_key_exists($count, $entries)) {

                if (array_key_exists('ds-pwp-account-disabled', $entries[$count])) {

                    if ($entries[$count]['ds-pwp-account-disabled'][0] == 1 or $entries[$count]['ds-pwp-account-disabled'][0] == 'true') {
                        $no_of_locked_users += 1;
                    }
                }

                // increment $count for next user value
                $count++;
            }
        }

        return $no_of_locked_users;

    }           // end of lockedUsers



    // return UnlockeUsers in digit
    public function unlockedUsers(){

        $searchUsers = $this->connection->search(ldap_base('ldap_user_base'),ldap_base('ldap_user_filter'),array('ds-pwp-account-disabled'));

        $entries = $this->connection->getEntries($searchUsers);

        // store number of locked users
        $no_of_unlocked_users = 0;

        // $count for indexing
        $count = 0;

        if ($entries['count'] > 0) {

            unset($entries['count']);

            while (array_key_exists($count, $entries)) {

                if (array_key_exists('ds-pwp-account-disabled', $entries[$count])) {

                    if ($entries[$count]['ds-pwp-account-disabled'][0] == 0 or $entries[$count]['ds-pwp-account-disabled'][0] == 'false') {
                        $no_of_unlocked_users += 1;}
                }else{
                    $no_of_unlocked_users += 1;
                }
                // increment $count for next user value
                $count++;
            }
        }
        return $no_of_unlocked_users;
    }  // end of unLockedUsers function


    // returns all users from LDAP
    public function getUsersName(Request $request){

        $seachUsers = $this->connection->search(ldap_base('ldap_user_base'),ldap_base('ldap_user_filter'),array('cn'));

        $resultUsers = $this->connection->getEntries($seachUsers);

        $users = array();

        unset($resultUsers['count']);

        foreach ($resultUsers as $user){

            $users[] = $user['cn'][0];
        }

        return json_encode($users);     // returns users in JSON Format

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    // Logout

    public function logout(Request $request){
        $request->session()->flush();

        return redirect('/login');
    }



    // Retrieve all Users
    public function getAllUsers(Request $request)
    {
        try{
           $users = array();

           $ldap_filter = "(objectclass=ipruseraccount)";

           // LDAP search and retriving all attributes along with ds-pwp-account-disabled attribute
           $result = $this->connection->search(ldap_base('ldap_user_base'), $ldap_filter, ['*', 'ds-pwp-account-disabled']);

           $entries = $this->connection->getEntries($result);

           $i = 0;  // index for Users array

           // get no of users and assign to $count
           $count = $entries['count'];


           // Do only if count > 0 else 'No users'
           if ($entries['count'] > 0) {

               // unsetting count attribute
               unset($entries['count']);

               // Here $i is used for indexing of User
               while (array_key_exists($i, $entries)) {

                   // creating builder Object
                   $builder = new \Adldap\Query\Builder($this->connection);

                   // set Schema . By default it will set Active Directory
                   $builder->setSchema();

                   // creating User Object
                   $user = new \Adldap\Models\User($entries[$i], $builder);

                   // Now if ds-pwp-account-disabled attribute is set true or 1 then User is disabled else enabled
                   if (array_key_exists('ds-pwp-account-disabled', $entries[$i])) {

                       if ($user['ds-pwp-account-disabled'][0] == 1 or $user['ds-pwp-account-disabled'][0] == 'true') {

                           $user->setActive('Disabled');
                       } else {
                           $user->setActive('Enabled');
                       }

                   }
                   // if  ds-pwp-account-disabled attribute is not absent then that user is considered as enabled
                   else {
                            $user->setActive('Enabled');

                   }

                   // $users array consists of User Objects and $i indicates User Object index
                   $users[$i] = $user;

                   // increment $i for next user
                   $i = $i + 1;
               }
           }

       }catch(\ErrorException $e){

           $users = null;

           $count = null;

           $request->session()->put('error',$e->getMessage());

           return view('Admin.allusers', compact('users', 'count'));

       }
        // return Admin/allusers.blade.php view with Users array and $count (No of users)
        return view('Admin.allusers', compact('users', 'count'));

    }

    // Delete User
    public function deleteUser(Request $request,$username){

        $user_dn = 'uid='.$username.','.ldap_base('ldap_user_base');

        try{

            $delete = $this->connection->delete($user_dn);

            if ($delete){

                // flash message
                $request->session()->put('success',$username." has been deleted");

                $this->log->info('User has been deleted ',[$user_dn]);

           //     return redirect('/home');

                return redirect('/Admin/allUsers');

            }else{

                $request->session()->put('error',$username."'s has not deleted Try it later");

//                return redirect('/home');
                return redirect('/Admin/allUsers');

            }


        }catch (\ErrorException $e){

            $request->session()->put('error',$e->getMessage());

//            return redirect('/home');

            return redirect('/Admin/allUsers');


        }





    }


    // retrieve all Locked Users
    public function getLockedUsers(Request $request)
    {
       try{

           $users = array();

           $ldap_filter = "(objectclass=ipruseraccount)";

           // search all Users under dn = ou=users,o=IPR,dc=ipr,dc=res,dc=in
           $result = $this->connection->search(ldap_base('ldap_base'), $ldap_filter, ['*', 'ds-pwp-account-disabled']);

           $entries = $this->connection->getEntries($result);

           // store number of locked users
           $no_of_locked_users = 0;


           $count = 0; // index

           if ($entries['count'] > 0) {

               unset($entries['count']);

               while (array_key_exists($count, $entries)) {

                   $builder = new \Adldap\Query\Builder($this->connection);

                   $builder->setSchema();

                   $user = new \Adldap\Models\User($entries[$count], $builder);

                   if (array_key_exists('ds-pwp-account-disabled', $entries[$count])) {

                       if ($entries[$count]['ds-pwp-account-disabled'][0] == 1 or $entries[$count]['ds-pwp-account-disabled'][0] == 'true') {

                           $users[$no_of_locked_users] = $user;

                           $no_of_locked_users += 1;
                       }
                   }

                   // increment $count for next user value
                   $count++;
               }
           }

       }catch(\ErrorException $e) {

           $no_of_locked_users = null;

           $users = null;

           $request->session()->put('error', $e->getMessage());

           return view('Admin.lockedusers', compact('users', 'no_of_locked_users'));

       }


        return view('Admin.lockedusers', compact('users', 'no_of_locked_users'));
    }       // end of  getLockedUsers



    public function getUnLockedUsers(Request $request)
    {

     try{
         $users = array();

         $ldap_filter = "(objectclass=ipruseraccount)";

         $result = $this->connection->search(ldap_base('ldap_user_base'), $ldap_filter, ['*', 'ds-pwp-account-disabled']);

         $entries = $this->connection->getEntries($result);

         $no_of_unlocked_users = 0;

         $count = 0; // index

         if ($entries['count'] > 0) {

             unset($entries['count']);

             while (array_key_exists($count, $entries)) {

                 $builder = new \Adldap\Query\Builder($this->connection);

                 $builder->setSchema();

                 $user = new \Adldap\Models\User($entries[$count], $builder);

                 if (array_key_exists('ds-pwp-account-disabled', $entries[$count])) {

                     if ($entries[$count]['ds-pwp-account-disabled'][0] == 0 or $entries[$count]['ds-pwp-account-disabled'][0] == 'false') {

                         $users[$no_of_unlocked_users] = $user;

                         $no_of_unlocked_users += 1;
                     }
                 } else {

                     $users[$no_of_unlocked_users] = $user;

                     $no_of_unlocked_users += 1;
                 }
                 $count++;
             }
         }
     }catch(\ErrorException $e){

         $no_of_unlocked_users = null;

         $users = null;

         $request->session()->put('error',$e->getMessage());

         return view('Admin.unlockedusers', compact('users', 'no_of_unlocked_users'));

     }

        return view('Admin.unlockedusers', compact('users', 'no_of_unlocked_users'));
    }       // end of unlockedusers





    public function getGuests(Request $request)
    {

      try{
          $users = array();

          $ldap_filter = "(objectclass=ipruseraccount)";

          $result = $this->connection->search(ldap_base('ldap_guest_base'), $ldap_filter, ['*', 'ds-pwp-account-disabled']);

          $entries = $this->connection->getEntries($result);

          $i = 0; // for indexing in USERS array

          $no_of_guests = $entries['count'];

          if ($entries['count'] > 0) {
              unset($entries['count']);

              while (array_key_exists($i, $entries)) {

                  $builder = new \Adldap\Query\Builder($this->connection);

                  $builder->setSchema();

                  $user = new \Adldap\Models\User($entries[$i], $builder);

                  if (array_key_exists('ds-pwp-account-disabled', $entries[$i])) {

                      if ($user['ds-pwp-account-disabled'][0] == 1) {

                          $user->setActive('Disabled');

                      } else {

                          $user->setActive('Active');
                      }

                  } else {

                      $user->setActive('Active');
                  }
                  $users[$i] = $user;

                  $i = $i + 1;
              }
          }
      }catch (\ErrorException $e){

          $users = null;

          $no_of_guests = null;

          $request->session()->put('error',$e->getMessage());

          return view('Admin.guests', compact('users', 'no_of_guests'));

      }

        return view('Admin.guests', compact('users', 'no_of_guests'));
    }       // end of guests





    public function showUserProfile(Request $request, $username)
    {

      try{
        //  $user = $this->getUserProfileDetails($username);

          $user_dn = 'uid='.$username.','.$request->session()->get('base_dn');

          $user = getUserObject($this->connection,$user_dn);            // functions.inc.php

          // 1 .General Details
          $user_attributes['general'] = attributes_map($user,'general');    // config.inc.php

          // 2. Personal Details
          $user_attributes['personal'] = attributes_map($user,'personal');      // config.inc.php


          // 3.Security group
          $securityGroups = getSecurityGroup($this->connection);   // config.inc.php

          // $securityGroups = getSecurityGroups();

          $ismember = $user->getAttribute('ismemberof'); // returns array of ismemberof

          unset($ismember['count']);

          // 4. Group Details
          $orgGroups = array();

          if($ismember != null) {

              foreach ($ismember as $key => $value) {

                  // code for fetching OU for checking whether it is OrgGroup or Security Group
                  $del = explode(',', $value);

                  $count = count($del);

                  $ou = substr('' . $del[$count - 5] . '', 3);



                  // check whether OU is orgGroups
                  if ($ou == 'OrgGroups') {

                      // fetch orgName from IsMember attribute
                      $orgName = substr('' . $del[0] . '', 3);

                      array_push($orgGroups, $orgName);
                  }



                  // else OU is security Group
                  else if ($ou == 'SecurityGroups') {

                      $access_right = substr('' . $del[0] . '', 3);

                      // By default all access-rights are set FALSE . Now, if access-right is exists then set to TRUE
//                      foreach ($securityGroups as $value){
//
                      foreach ($securityGroups as $key1 => $value1){

                          if ($access_right == $value1['name']) {

                              $securityGroups[$key1] = [ 'name' => $access_right , 'value' => true];
                          }

                      }

                  }
              }

              // OrgGroup
              $user_attributes['group'] = $orgGroups;

          }

          // Security Group
          $user_attributes['access_rights'] = $securityGroups;


          // ACTIVATE DE-ACTIVATE purpose
          $user_attributes['ds-pwp-account-disabled'] = $user->getAttribute('ds-pwp-account-disabled')[0];


          $user_attributes['displayname'] = $username;

          $user_attributes['username'] = $username;


      }catch (\ErrorException $e){

          $user_attributes = null;

          $user = null;

          // flashing message
          $request->session()->put('error','Something Went Wrong Try it Later');

          return view('Admin.userprofile',compact('user_attributes','user'));

      }

        return view('Admin.userprofile', compact('user_attributes', 'user'));

    }


    public function giveAccessRights(Request $request, $id)
    {

      try{
          // fetching Access-Right name and create Security Group Dn
          $securityGroupDn = 'cn=' . $request->id . ',' . ldap_base('ldap_hosts_base');


          // Member commonName
          $entry['member'] = 'uid=' . $id . ',' . $request->session()->get('base_dn');

          if ($request->value == 'true') {
              $result = $this->connection->modAdd($securityGroupDn, $entry);
              if ($result) {

                  //logger
                  $this->log->info($request->id.' access-right has been given',[ $entry['member']]);

                  return 'add';

                  }
          } else if ($request->value == 'false') {
              $result = $this->connection->modDelete($securityGroupDn, $entry);

              if ($result) {

                  // logger
                  $this->log->info($request->id.' access-right has been removed',[ $entry['member']]);

                  return 'remove';
              }
          }
      }catch(\ErrorException $e){

          return $e->getMessage();

      }

    }  // end of giveAccessRights()


    // edit User profile
    public function editUserProfile(Request $request, $username)
    {

        $user_dn = 'uid='.$username.','.$request->session()->get('base_dn');

        $user = getUserObject($this->connection,$user_dn);

        return view('Admin.editprofile', compact('user'));

    } // end of editUserProfile()



    public function updateEmployeeDetails(Request $request){

        $session = $request->session();

        $username = $request->username;
        //
        try {


            $user_dn = 'uid='.$username.','.ldap_base('ldap_user_base');

        //retrieve all attributes from edit form
        $editedAttributes = $request->toArray();


        $editedAttributes['displayname'] = $editedAttributes['initials'].' '.$editedAttributes['firstname'].' '.$editedAttributes['lastname'];


        $editFormAttributes = getEditFormAttributes();      // config.inc.php

        // get Attributes array
        $attributes_map = changeIndexNameLdap();


        foreach ($attributes_map as $key => $value){

            $index = $value['attribute'];

            if (array_key_exists($key,$editFormAttributes)){

                $editedAttributes[$value['attribute']] = $editedAttributes[$key];


                // if name is not same then unset it
                if ($key != $index){

                    unset($editedAttributes[$key]);

                }
            }
        }

        unset($editedAttributes['_token']);             // NR
        unset($editedAttributes['username']);           // NR

        $editedAttributes = delete_empty_index($editedAttributes);  // functions.inc.php

        if (array_key_exists('manager',$editedAttributes)){

            $manager = getUID($editedAttributes['manager']);

            $editedAttributes['manager'] = 'uid='.$manager.','.ldap_base('ldap_user_base');
        }

        $result= $this->connection->modify($user_dn,$editedAttributes);

        if ($result){

            // log
            $session->put('success','profile updated successfully');

            return  redirect('/Admin/profile/'.$username);

        }else{

            $session->put('error','Error while updating profile  successfully');

            return  redirect('/Admin/profile/'.$username);
        }


        } catch (\ErrorException $e) {

            $session->put('error', 'Update Failed try it later'.$e->getMessage());

            return  redirect('/Admin/profile/'.$username);
        }
    }       // end of updateEmployeeDetails()





    public function deactivate(Request $request, $username)
    {

        try{
            $userDn = 'uid=' . $username . ',' . $request->session()->get('base_dn');

            $entry["ds-pwp-account-disabled"] = 1;

            $result = $this->connection->modify($userDn, $entry);

            if ($result) {

                // log
                $this->log->info('User has been Locked',[ $userDn]);

                // flashing message
                $request->session()->put('error', $username.' has been De-activated');

               // return redirect(route('showUserProfile', $username));

            } else {

                $request->session()->put('error','Something went Wrong try later');

            }

            return redirect(route('showUserProfile', $username));

        }catch(\ErrorException $e){

            $request->session()->put('error', $e->getMessage());

            return redirect(route('showUserProfile', $username));


        }
    }           // end of de-activate




    public function activate(Request $request, $username)
    {
        try{
            $userDn = 'uid=' . $username . ',' . $request->session()->get('base_dn');

            $entry["ds-pwp-account-disabled"] = 0;

            $result = $this->connection->modify($userDn, $entry);

            if ($result) {

                $this->log->info('User has been Unlocked', [$userDn]);

                // flashing message
                $request->session()->put('success', $username.' has been activated');

                return redirect(route('showUserProfile', $username));

            } else {
                return 'Error While Deactivating';
            }
        }catch(\ErrorException $e){

            // flashing message
            $request->session()->put('error', $e->getMessage());

            return redirect('showUserProfile',$username);
    }

    } // end of activate




    public function password_change_view(Request $request)
    {

        return view('Admin.passwordchangeview');

    }



    public function Admin_password_change(Request $request)
    {

       try{
           $session = $request->session();

           $username = $request->username;

           $user_dn = 'uid=' . $username . ',' . $session->get('base_dn');

           if (!$this->connection->canChangePasswords()) {

               $this->connection->tls(true);
           }

           $userdata['userpassword'] = $request->newpassword;

           $result = $this->connection->modReplace($user_dn, $userdata);


           if ($result) {

               $request->session()->put('success', $username."'s " .'password has been reset');

               //log
               $this->log->info('Password has been resent',[$user_dn]);

           } else {

               $request->session()->put('error','Error while reseting'. $username."'s" .'password');

           }
           return view('Admin.passwordchangeview');

       }catch (\ErrorException $e){


           $request->session()->put('error',$e->getMessage());

           return view('Admin.passwordchangeview');

       }
    }


    // get All Org Groups
    public function OrgGroupsName(Request $request)
    {

       try{
           $count = 0;

           $group_dn = ldap_base('ldap_groups_base');

           $ldap_filter = ldap_base('ldap_groups_filter');

           $read = $this->connection->listing($group_dn, $ldap_filter, ['*', 'hassubordinates']);

           $search = $this->connection->getEntries($read);

           if ($search['count'] > 0) {

               unset($search['count']);

               foreach ($search as $key => $org) {


                   $del_owner = explode(',', $org['owner'][0]);

                   $owner = substr('' . $del_owner[0] . '', 4);

                   $orgInfo[$count] = [
                       'name' => $org['cn'][0],
                       'owner' => $owner,
                       'dn' => $org['dn']
                   ];

                   $count++;
               }

           }
            // parent_dn is use while Renaming child
           $request->session()->put('parent_dn', $group_dn);

       }catch(\ErrorException $e){

           $orgInfo = null;

           $group_dn = null;

           $request->session()->put('error','Something Went Wrong '.$e->getMessage());

           return view('Admin.group',compact('orgInfo','group_dn'));


       }
        return view('Admin.group', compact('orgInfo', 'group_dn'));
    }



    // Retrieve Sub Org Information
    public function getOrgGroupInfo(Request $request, $group_dn)
    {

       try{
           $orgInfo = array();

           $parent_dn = $request->session()->get('parent_dn');

           $ldap_filter = ldap_base('ldap_groups_filter');

           $search = $this->connection->read($group_dn, $ldap_filter, ['*', 'hassubordinates']);

           $result = $this->connection->getEntries($search);

           if ($result['count'] > 0) {

               unset($result['count']);

               $org = $result[0];


               // Name of ORG
               $orgInfo['name'] = $org['cn'][0];


               // Member of selected ORG
               if (array_key_exists('member', $org)) {

                   if ($org['member']['count'] > 0) {


                       unset($org['member']['count']);

                       foreach ($org['member'] as $key => $value) {


                           $del_owner = explode(',', $value);

                           $owner = substr('' . $del_owner[0] . '', 4);

                           $member[$key] = $owner;

                       }
                   }

                   $orgInfo['member'] = $member;
               }


               // Add Sub Org if hassubordinates == 'true

               if ($org['hassubordinates'][0] == 'true') {

                   $subGroup_dn = $org['dn'];

                   $searchSubOrg = $this->connection->listing($subGroup_dn, $ldap_filter, ['*']);

                   $readSubOrg = $this->connection->getEntries($searchSubOrg);

                   if ($readSubOrg['count'] > 0) {

                       $subOrgInfo = array();

                       $subCount = 0;

                       foreach ($readSubOrg as $key => $subOrg) {

                           $del_owner = explode(',', $subOrg['owner'][0]);

                           $owner = substr('' . $del_owner[0] . '', 4);

                           $subOrgInfo[$subCount] = [
                               'name' => $subOrg['cn'][0],
                               'owner' => $owner,
                               'dn' => $subOrg['dn']
                           ];

                           $subCount++;
                       }
                       unset($subOrgInfo[0]);
                   }

                   $orgInfo['suborg'] = $subOrgInfo;

               }

               $group_dn = $org['dn'];

           }


           $users = $this->getAllUnlockedUsers();


       }catch(\ErrorException $e){

           $orgInfo = null;

           $parent_dn = null;

           $users = null;

           $group_dn = null;

           // flashing message

           $request->session()->put('error','Something went wrong '. $e->getMessage());

           return view('Admin.groupinfo', compact('orgInfo', 'parent_dn', 'users', 'group_dn'));

       }

        return view('Admin.groupinfo', compact('orgInfo', 'parent_dn', 'users', 'group_dn'));

    }



    // Add New Group
    public function addGroup(Request $request){

        try{

            $group_dn = 'cn='.$request->name.','.$request->groupdn;

            $objectclass[0] = 'top';
            $objectclass[1] = 'groupOfNames';

            $entry = [
                'owner' =>  'uid='.$request->owner.','.$request->session()->get('base_dn'),
                'member' => 'uid='.$request->owner.','.$request->session()->get('base_dn'),
                'cn' => $request->name,
                'objectclass' => $objectclass
            ];

            $result = $this->connection->add($group_dn,$entry);

            // if group_dn is same as LDAP_GROUPS_BASE then return to /Admin/orgGroups
            // else return to /Admin/orgGroups/'.$request->groupdn

            if ($result){

                // flashing message
                $request->session()->put('success',' New Group Created Successfully');

                if ($request->groupdn == ldap_base('ldap_groups_base')){

                    return redirect('/Admin/orgGroups');
                }

                return redirect('/Admin/orgGroups/'.$request->groupdn);
            }else{

                $request->session()->put('error','Error while adding new group try it later');


                return redirect('/Admin/orgGroups');

            }

        }catch (\ErrorException $e){

            $request->session()->put('error',$e->getMessage());

            return redirect('/Admin/orgGroups');
        }
    }


    // Add New Host
    public function addHost(Request $request){

        try{

            $group_dn = 'cn='.$request->name.','.$request->groupdn;

            $objectclass[0] = 'top';
            $objectclass[1] = 'groupOfNames';

            $entry = [
                'owner' =>  'uid='.$request->owner.','.$request->session()->get('base_dn'),
                'member' => 'uid='.$request->owner.','.$request->session()->get('base_dn'),
                'cn' => $request->name,
                'objectclass' => $objectclass
            ];

            $result = $this->connection->add($group_dn,$entry);



            // if group_dn is same as LDAP_GROUPS_BASE then return to /Admin/orgGroups
            // else return to /Admin/orgGroups/'.$request->groupdn

            if ($result){
                // flashing message
                $request->session()->put('success','New Host Created Successfully');

                if ($request->groupdn == ldap_base('ldap_hosts_base')){

                    return redirect('/Admin/SecurityGroups');
                }

                return redirect('/Admin/securityGroups/'.$request->groupdn);

            }else{

                $request->session()->put('error','Something went wrong');

                return redirect('/Admin/SecurityGroups');

            }
        }catch(\ErrorException $e){

            $request->session()->put('error','Something Went Wrong '.$e->getMessage());

            return redirect('/Admin/SecurityGroups');
        }


    }


    // Change Owner Name
    public function changeOwner(Request $request){

        try{

            $groupDn = $request->groupdn;

            $owner = 'uid='.$request->ownername.','.$request->session()->get('base_dn');


            $modify_attributes[0] = [
                'attrib' => 'owner',
                'modtype' => LDAP_MODIFY_BATCH_REPLACE,
                'values' => [$owner]
            ];


            $result = $this->connection->modifyBatch($groupDn,$modify_attributes);

            if ($result){

                // flashing message
                $request->session()->put('success','Owner Changed Successfully');


                    return redirect('/Admin/orgGroups/'.$groupDn);


            }else{

                $request->session()->put('error','Something went wrong');


                return redirect('/Admin/orgGroups/'.$groupDn);
            }

        }catch (\ErrorException $e){

            $request->session()->put('error','Something went wrong '.$e->getMessage());


            return redirect('/Admin/orgGroups/'.$groupDn);

        }

    }




    // Rename Host Name
    public function renameHostName(Request $request){


       try{

           $parentDn = $request->parentdn;

           $groupDn = $request->groupdn;

           $rename = $request->groupname;

           $newGroupDn = 'cn='.$rename;


           $result = $this->connection->rename($groupDn,$newGroupDn,$parentDn,TRUE);

           if ($result){

               // flashing message
               $request->session()->put('success',' Hostname Renamed  Successfully');

               if ($parentDn == 'ou=SecurityGroups,o=IPR,dc=ipr,dc=res,dc=in'){

                   return redirect('/Admin/SecurityGroups');

               }else{


                   return redirect('/Admin/securityGroups/'.$parentDn);

               }

           }else{

               $request->session()->put('error','Something went wrong');

               return redirect('/Admin/SecurityGroups');
           }

       }catch (\ErrorException $e){

           $request->session()->put('error','Something went wrong '.$e->getMessage());

           return redirect('/Admin/SecurityGroups');

       }

    }


    // Add member to group and host
    public function addMember(Request $request,$username){

        try{

            $group_dn = $request->session()->get('groupdn');

            $request->session()->forget('groupdn');

          //  $member_name = $request->commanName;

            $member_name = $username;

            $member_dn = 'uid='.$member_name.','.$request->session()->get('base_dn');



            $modify_attributes[0] = [
                'attrib' => 'member',
                'modtype' => LDAP_MODIFY_BATCH_ADD,
                'values' => [$member_dn]
            ];

            $result = $this->connection->modifyBatch($group_dn,$modify_attributes);

            if ($result){

                // flashing message
                $request->session()->put('success',$member_name.' Added Successfully');

            }else{


                $request->session()->put('error','Something went wrong');

            }

            if ( strpos($group_dn,'OrgGroups') != false){

                return redirect('/Admin/orgGroups/'.$group_dn);

            }else{

                return redirect('/Admin/securityGroups/'.$group_dn);
            }


        }catch(\ErrorException $e){

            $request->session()->put('error',$e->getMessage());

            return redirect('/Admin/orgGroups/'.$group_dn);

        }
    }





    // Rename Group Name
    public function renameGroupName(Request $request){

        try{

            $parentDn = $request->parentdn;

            $groupDn = $request->groupdn;

            $rename = $request->groupname;

            $newGroupDn = 'cn='.$rename;

            $result = $this->connection->rename($groupDn,$newGroupDn,$parentDn,TRUE);

            if ($result){

                $request->session()->put('success','Groupname Renamed Successfully');

                if ($parentDn == 'ou=OrgGroups,o=IPR,dc=ipr,dc=res,dc=in'){

                    return redirect('/Admin/orgGroups');

                }else{

                    return redirect('/Admin/orgGroups/'.$parentDn);

                }

            }else{

                $request->session()->put('error','Something Went Wrong');

                return redirect('/Admin/orgGroups');
            }

        }catch(\ErrorException $e){

            $request->session()->put('error',$e->getMessage());

            return redirect('/Admin/orgGroups');
        }


    }




    // Remove member from group
    public function removeMember(Request $request,$username){

        try{

            $memberdn = 'uid='.$username.','.$request->session()->get('base_dn');

            $groupdn = $request->groupdn;

            $entry['member'] = $memberdn;

            $result = $this->connection->modDelete($groupdn,$entry);

            if ($result){

                $request->session()->put('success', $username.' has been Removed Successfully');

            }else{

                $request->session()->put('error','Something Went Wrong');

            }


            if ( strpos($groupdn,'OrgGroups') != false){

                return redirect('/Admin/orgGroups/'.$groupdn);

            }else{

                return redirect('/Admin/securityGroups/'.$groupdn);
            }


        }catch(\ErrorException $e){

            $request->session()->put('error',$e->getMessage());


            if ( strpos($groupdn,'OrgGroups') != false){

                return redirect('/Admin/orgGroups/'.$groupdn);

            }else{

                return redirect('/Admin/securityGroups/'.$groupdn);
            }

        }

    }



 // get all Unlocked Users
    public function getAllUnlockedUsers()
    {

       try{
           $users = array();

           $ldap_filter = "(objectclass=ipruseraccount)";

           $result = $this->connection->search(ldap_base('ldap_user_base'), $ldap_filter, ['*','ds-pwp-account-disabled']);

           $entries = $this->connection->getEntries($result);

           $no_of_unlocked_users = 0;

           $count = 0;

           if ($entries['count'] > 0){

               unset($entries['count']);

               while (array_key_exists($count,$entries)){

                   $builder = new \Adldap\Query\Builder($this->connection);

                   $builder->setSchema();

                   $user = new \Adldap\Models\User($entries[$count],$builder);

//                   $user = getUserObject($this->connection,$u)

                   if (array_key_exists('ds-pwp-account-disabled',$entries[$count]) ) {

                       if ($entries[$count]['ds-pwp-account-disabled'][0] == 0 or $entries[$count]['ds-pwp-account-disabled'][0] == 'false' ){

                           $users[$no_of_unlocked_users] = $user;

                           $no_of_unlocked_users += 1;
                       }
                   }else{

                       $users[$no_of_unlocked_users] = $user;

                       $no_of_unlocked_users += 1;
                   }
                   $count ++;
               }
           }

           return $users;

       }catch (\ErrorException $e){

           return null;

       }

    }


    // Security Groups
    public function SecurityGroupNames(Request $request){

        try{

            $count = 0;

            $group_dn = ldap_base('ldap_hosts_base');

            $ldap_filter = ldap_base('ldap_groups_filter');

            $read = $this->connection->listing($group_dn, $ldap_filter, ['cn']);

            $search = $this->connection->getEntries($read);


            if ($search['count'] > 0) {

                unset($search['count']);

                foreach ($search as $key => $security) {

//                $del_owner = explode(',',$org['owner'][0]);
//
//                $owner = substr(''.$del_owner[0].'',4);

                    $SecurityInfo[$count] = [
                        'name' => $security['cn'][0],
                        'dn' => $security['dn']
                    ];

                    $count++;
                }

            }


            $request->session()->put('parent_dn',$group_dn);


        }catch (\ErrorException $e){

            $SecurityInfo = null;

            $group_dn = null;

            $request->session()->put('error','Something Went Wrong '.$e->getMessage());

            return view('Admin.hosts',compact('SecurityInfo','group_dn'));

        }



        return view('Admin.hosts',compact('SecurityInfo','group_dn'));

    }


    // Get Security Group Info
    public function SecurityGroupInfo(Request $request,$group_dn){


      try{

          $securityInfo = array();

          $parent_dn = $request->session()->get('parent_dn');

          $ldap_filter = ldap_base('ldap_groups_filter');

          $search = $this->connection->read($group_dn, $ldap_filter, ['*', 'hassubordinates']);

          $result = $this->connection->getEntries($search);

          if ($result['count'] > 0) {

              unset($result['count']);

              $security = $result[0];

              // Name of ORG
              $securityInfo['name'] = $security['cn'][0];


              // Member of selected ORG
              if (array_key_exists('member', $security)) {

                  if ($security['member']['count'] > 0) {


                      unset($security['member']['count']);

                      foreach ($security['member'] as $key => $value) {

                          $del_owner = explode(',', $value);

                          $owner = substr('' . $del_owner[0] . '', 4);

                          $member[$key] = $owner;

                      }
                  }

                  $securityInfo['member'] = $member;
              }


              // Add Sub Org if hassubordinates == 'true

              if ($security['hassubordinates'][0] == 'true') {

                  $subGroup_dn = $security['dn'];

                  $searchSubOrg = $this->connection->listing($subGroup_dn, $ldap_filter, ['*']);

                  $readSubOrg = $this->connection->getEntries($searchSubOrg);

                  if ($readSubOrg['count'] > 0) {

                      $subSecurityInfo = array();

                      $subCount = 0;

                      foreach ($readSubOrg as $key => $subOrg) {

                          $del_owner = explode(',', $subOrg['owner'][0]);

                          $owner = substr('' . $del_owner[0] . '', 4);

                          $subSecurityInfo[$subCount] = [
                              'name' => $subOrg['cn'][0],
                              'owner' => $owner,
                              'dn' => $subOrg['dn']
                          ];

                          $subCount++;

                      }
                      unset($subSecurityInfo[0]);
                  }

                  $securityInfo['suborg'] = $subSecurityInfo;

              }

              $group_dn = $security['dn'];
          }

          $users = $this->getAllUnlockedUsers();

      }catch (\ErrorException $e){

          $securityInfo = null;

          $parent_dn = null;

          $users = null;

          $group_dn = null;


          $request->session()->put('error','Something Went Wrong '.$e->getMessage());

          return view('Admin.hostinfo', compact('securityInfo', 'parent_dn', 'users', 'group_dn'));


      }

        return view('Admin.hostinfo', compact('securityInfo', 'parent_dn', 'users', 'group_dn'));


    }


    protected $ParentInfo = array();

    protected $ChildInfo = array();



    public function showOrganizationalChart(Request $request){

       //    $this->getOrganizationInformation();
    return view('Admin.organizationalchart');
    }


    /**
     * @param Request $request
     */
    public function  getOrganizationInformation(){

        $dn = 'o=IPR,dc=ipr,dc=res,dc=in';

        $ldap_filter = ldap_base('ldap_hosts_filter');

        $search = $this->connection->listing($dn,$ldap_filter,['ou','hasSubordinates','numSubordinates']);

        $entries = $this->connection->getEntries($search);

        $noOfOrg = $entries['count'];

        $count = 0;

        unset($entries['count']);

        for ($i =0 ; $i < $noOfOrg ; $i++){

            foreach ($entries as $index => $orgInfo){

        if (array_key_exists('ou',$orgInfo)) {

            $parentCn = $orgInfo['ou'][0];
                }


                $parentDn = $orgInfo["dn"];

                if ($orgInfo['hassubordinates'][0] == true && $parentDn != 'ou=users,o=IPR,dc=ipr,dc=res,dc=in' ){

                    $subOrg = $this->connection->listing($parentDn,$ldap_filter,['cn','dn','hasSubordinates']);

                    $entries = $this->connection->getEntries($subOrg);

                    unset( $entries['count']);

                    foreach ($entries as $index => $subOrg){

                      $this->ParentInfo[] = ['parentId' => $parentCn, 'memberId' => $subOrg['cn'][0]];

//                      $this->ChildInfo[$count] = [ 'parentId' => $parentCn, 'memberId' => $subOrg['cn'][0]];

//                        echo $count;
//
//                      print_r($this->ParentInfo[$count]) ;
//
//                      echo  '<br>';

                        $this->subOrg($subOrg);


                    }

                    $count++;

                }


            }

        }

    //   dd($this->ParentInfo,$this->ChildInfo);

    //    dd(array_values($this->ParentInfo),array_values($this->ChildInfo));
   //   dd (json_encode(array(array_values($this->ParentInfo),array_values($this->ChildInfo))));

    return (json_encode(array(($this->ParentInfo),array_values($this->ChildInfo))));
    }


    public function subOrg($subOrg){

        $parentDn = $subOrg['dn'];

        $parentCn = $subOrg['cn'][0];

        $ldap_filter = ldap_base('ldap_hosts_filter');


        if ($subOrg['hassubordinates'] == true ){

            $subOrg = $this->connection->listing($parentDn,$ldap_filter,['cn','dn','hasSubordinates','numSubordinates']);

            $entries = $this->connection->getEntries($subOrg);

            unset( $entries['count']);

            foreach ($entries as $index => $subOrg){


                $this->ChildInfo[]  = ['parentId' => $parentCn, 'memberId' =>$subOrg['cn'][0]];

                $this->subOrg($subOrg);
            }
        }

    }


    // deadline

    public function deadline(Request $request){

//        event(new deadline($this->ldap));

        try{

            $date1 = date('Y-M-D');

            $d = date_parse_from_format("Y-M-D", $date1);

            $currentMonth = $d["month"];

            $currentYear = $d['year'] % 100;


            if($currentMonth == 1){

                $prevMonth = 12;
            }else{

                $prevMonth = $currentMonth - 1;
            }



            $user_dn = ldap_base('ldap_user_base');

            $ldap_user_filter = "(objectClass=ipruseraccount)";

            $search_results = $this->connection->search($user_dn,$ldap_user_filter,array('uid','displayname','dateofcomplition','cn','ds-pwp-account-disabled'));

            $entries = $this->connection->getEntries($search_results);


            $currentMonthUsers = array();

            $prevMonthUsers = array();

            unset($entries['count']);

            foreach ($entries as $user){

                if(key_exists('dateofcomplition',$user)){

                    $dateofcomplition = $user['dateofcomplition'][0];

                    $dateElements = explode('-', $dateofcomplition);

                    if (count($dateElements) == 1){


                        $dateElements  = explode('/',$dateofcomplition);

                        $month = $dateElements[1];

                        $year =  $dateElements[2] % 100;

                    }else{

                        $month = $dateElements[1];

                        $year = $dateElements[2];
                    }



                    if ($currentYear == $year){

                        if ($currentMonth == $month){

                            $currentMonthUsers[] = array( 'username' => $user['cn'][0], 'status' => $user['ds-pwp-account-disabled'],'date' => $dateofcomplition) ;

                        }else if( $prevMonth == $month) {

                            $prevMonthUsers[] = array('username'  => $user['cn'][0], 'status' =>$user['ds-pwp-account-disabled'],'date' => $dateofcomplition);

                        }

                    }

                }

            }
        }catch (\ErrorException $e){

            $request->session()->put('error',$e->getMessage());

            $prevMonthUsers = null;

            $currentMonthUsers = null;

            return view('Admin.deadline',compact('prevMonthUsers','currentMonthUsers'));

        }

    //    dd($currentMonthUsers,$prevMonthUsers);

        return view('Admin.deadline',compact('prevMonthUsers','currentMonthUsers'));



    }

    public function createUser(Request $request){

     try{
         $attributes_map = createNewUserAttributes();

         $attributes = $request->toArray();


         foreach ($attributes_map as $key => $value){

             if (array_key_exists($key,$attributes)){

                 $attributes[$value['attribute']] = $attributes[$key];

                 unset($attributes[$key]);
             }
         }

         $attributes['cn'] = $attributes['uid'];

         unset($attributes['confirmpassword']);

         unset($attributes['_token']);

//         $attributes = delete_empty_index($attributes);

         // set objects
         $attributes = set_object_class($attributes);

         $attributes['ds-pwp-account-disabled'] = 0;

         $user_dn = 'uid='.$attributes['uid'].','.ldap_base('ldap_user_base');

         $result = $this->connection->add($user_dn,$attributes);

         if ($result){

             $request->session()->put('success','User created successfully');

             $this->log->info('User has been Created',[$user_dn]);

             return $this->getAllUsers($request);
         }else{


             $request->session()->put('error','User create failed try it later');

             return $this->getAllUsers($request);

         }
     }catch (\ErrorException $e){

         $request->session()->put('error',$e->getMessage());

         return $this->getAllUsers($request);


     }

    }




//    public function  getOrganizationInformation(Request $request){
//
//
//        $dn = 'o=IPR,dc=ipr,dc=res,dc=in';
//
//        $ldap_filter = ldap_base('ldap_hosts_filter');
//
//        $search = $this->connection->listing($dn,$ldap_filter,['ou','hasSubordinates','numSubordinates']);
//
//        $entries = $this->connection->getEntries($search);
//
//        unset($entries['count']);
//
//        $count = 0;
//
//            foreach ($entries as $index => $orgInfo) {
//
//                $parentDn = $orgInfo["dn"];
//
//                $parentCn = $orgInfo["ou"][0];
//
//
//                if ($orgInfo['hassubordinates'][0] == "true" && $parentDn != 'ou=users,o=IPR,dc=ipr,dc=res,dc=in') {
//
//                    $subOrg = $this->connection->listing($parentDn, $ldap_filter, ['cn','dn', 'hasSubordinates', 'numSubordinates']);
//
//                    $entries = $this->connection->getEntries($subOrg);
//
//                    $this->Info['Main'][$count] = $parentCn;
//
//                    unset($entries['count']);
//
//                    foreach ($entries as  $subOrg) {
//
//                        if ($subOrg['hassubordinates'][0] == "true"){
//
//                            $this->Info[$parentCn][$count] = $subOrg['cn'][0];
//
//                            $this->subOrg($subOrg,$count);
//
//                            $count ++;
//
//                        }else{
//
//                            $this->Info[$parentCn][$count] = $subOrg['cn'][0] ;
//
//                            $count++;
//                        }
//
//
//                    }
//                }
//
//            }
//          foreach($this->Info['Main'] as $key => $value){
//
//                    if(array_key_exists($value,$this->Info)){
//
////                        $this->Info['Main'][$value] = $this->Info[$value];
//
//                        $this->Info['Main'][$value] = $this->Info[$value];
//
//                        unset($this->Info[$value]);
//
//                        $this->subFunc($this->Info['Main'][$value]);
//
//                        unset($this->Info['Main'][$key]);
//
//                    }
//            }
//
//            $info = $this->Info['Main'];
//
//
//
//            return view('Admin.organizationalchart',compact('info'));
//            dd(json_encode($this->Info));
//
//    }
//
//    public function subFunc(& $ref){
//
//        foreach ($ref as $key => $value) {
//
//            if (array_key_exists($value,$this->Info)){
//
//               $ref[$key] = array( $value => $this->Info[$value]);
//
//                $this->subFunc($ref[$key][$value]);
//
//                unset($this->Info[$value]);
//            }
//        }
//
//    }
//
//
//    public function subOrg($subOrg,& $count){
//
//        $parentDn = $subOrg['dn'];
//
//        $parentCn = $subOrg['cn'][0];
//
//        $ldap_filter = ldap_base('ldap_hosts_filter');
//
//        if ($subOrg['hassubordinates'][0] == "true" ){
//
//            $subOrg = $this->connection->listing($parentDn,$ldap_filter,['dn','cn','hasSubordinates']);
//
//            $entries = $this->connection->getEntries($subOrg);
//
//            unset( $entries['count']);
//
//            foreach ($entries as $index => $subOrg){
//
//                $this->Info[$parentCn][$count] = $subOrg['cn'][0];
//
//                $this->subOrg($subOrg,$count);
//
//                $count ++;
//
//            }
//        }
//    }
}





