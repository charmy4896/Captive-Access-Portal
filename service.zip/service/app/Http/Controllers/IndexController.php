<?php

namespace App\Http\Controllers;

use App\User;
use App\user_div_head_approval;
use Illuminate\Http\Request;

use Adldap\AdldapInterface;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;

class IndexController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    protected  $ldap;

    protected  $connection;

    protected $request;

    public function __construct(AdldapInterface $ldap)
    {

        // Setting LDAP connection ($connection) and its provider  ($provider)
        $this->ldap = $ldap;

        $this->provider = $this->ldap->getDefaultProvider();

        $this->connection = $this->provider->getConnection();

        $this->request = app('request');
    }
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    // Username validity
    public function checkUsername(Request $request){

        try{

            $username = $request->username;

            $provider = $this->ldap->getDefaultProvider();

            $connection = $provider->getConnection();

            $ldap_filter = "(&(objectclass=ipruseraccount)(uid={login}))";

            $ldap_filter = str_replace("{login}", $username, $ldap_filter);

            $result = $connection->search(ldap_base('ldap_base'), $ldap_filter, ['*']);

            $entry = $connection->getEntries($result);

            if($entry['count'] != 0) {

                return 'true';
            }

        }catch (\Adldap\AdldapException  $e){

            echo $e->getMessage();
        }

    }

    // fetch all divison Owners
    public function getDivisionHead(Request $request){


        $ldap_filter = ldap_base('ldap_groups_filter');

        $result = $this->connection->search(ldap_base('ldap_groups_base'), $ldap_filter, ['owner']);

        $owners = $this->connection->getEntries($result);


        $ownersDn = array();


        foreach ($owners as $owner){

            array_push($ownersDn,$owner['owner'][0]);

        }

        $ownersDn = array_unique($ownersDn);

        $owners = array();

        unset($ownersDn[0],$ownersDn[4],$ownersDn[105]);

        foreach ($ownersDn as $key => $ownerDn){

            $search_owner = $this->connection->read($ownerDn,ldap_base('ldap_user_filter'),['displayname','cn']);

            $owner = $this->connection->getEntries($search_owner);

            $owner = $owner[0];

            array_push($owners,  $owner['displayname'][0] .' ('.$owner['cn'][0] .') ' );
            //.'('. $owner['cn'][0] .')');

        }

        return json_encode(array_values($owners));

    }

    public function getDepartmentOfOwner(Request $request){

        $username = $this->getUID($request->id);

        $search = $this->connection->read('uid='.$username.','.ldap_base('ldap_user_base'),ldap_base('ldap_user_filter'),array('ismemberof'));

        $result = $this->connection->getEntries($search);

        $result = $result[0];

        $groupName = array();

        foreach ($result['ismemberof'] as $member){


            if ( strpos($member,'OrgGroups') != false){


                $split = explode(',', $member);

                $split = explode('cn=',$split[0]);

                $groupName[] = $split[1];

            }


        }

        return json_encode($groupName);

    }

    public function getUID($name){

        $manager_split = explode('(', $name);

        $manager = explode(')',$manager_split[1]);

        return $manager[0];

    }


    public function getStatusView(){

        return view('index.status.statusView');

    }

    public function getPasswordChangeView(Request $request){

        return view('index.passwordchange');
    }

    public function passwordChange(Request $request){

       try{


           $rules = ['captcha' => 'required|captcha'];

           $validator = Validator::make(Input::all(), $rules);

           if($validator->fails()){

               $request->session()->put('error','Incorrect Captcha ');


               return redirect('/index/passwordchangeView');

           }

           $username = $request->username ;

           $user_dn = 'uid='.$username.','.ldap_base('ldap_user_base');

           $checkOldPassword = $this->checkOldPassword($user_dn,$request->oldpassword);

           if($checkOldPassword){

               if(!$this->connection->canChangePasswords()){

                   $this->connection->tls(true);
               }

               $userdata['userpassword'] = $request->newpassword;

               $result = $this->connection->modReplace($user_dn,$userdata);

               if ($result){

                   $request->session()->put('success','Password have been reset successfully');


                   return $this->getPasswordChangeView($request);

                   //  return 'Succesfully Password Changed';
               }else{

                   $request->session()->put('error','Old password is incorrect');

                   return $this->getPasswordChangeView($request);
               }
           }else{

               $request->session()->put('error','Old password is incorrect');

               return $this->getPasswordChangeView($request);
           }


       }catch (\ErrorException $e){

            $request->session()->put('error',$e->getMessage());

           return $this->getPasswordChangeView($request);


       }
    }


    public function checkOldPassword($user_dn,$oldpassword){

        try {


            if ($this->ldap->getDefaultProvider()->auth()->attempt($user_dn, $oldpassword, true)) {
                return true;
            }

        }catch (\ErrorException $e){
            echo $e->getMessage();
        }
        return false;
    }



    public function getStatus(Request $request){

       try{


           $rules = ['captcha' => 'required|captcha'];


           $validator = Validator::make(Input::all(), $rules);

//           if($validator->fails()){
//
//               $request->session()->put('error','Incorrect Captcha ');
//
//
//               return redirect('/index/statusView');
//
//           }


           $username = $request->username != null ? $request->username : $request->session()->get('statusUsername')  ;

           $user_dn = 'uid='.$username.','.ldap_base('ldap_user_base');

           $ldap_filter = "objectclass=ipruseraccount";

           $result = $this->connection->search($user_dn, $ldap_filter, array('*','ds-pwp-account-disabled'));

           $entries = $this->connection->getEntries($result);


           if ($entries['count'] > 0){

               $entries = $entries[0];

               $info['start'] = 'true';

               $info['registered'] = 'true';

               $request->session()->put('Status','done');


               if (array_key_exists('divhead',$entries)){

                   // step 3
                   $info['divhead'] = $entries['divhead'][0];
               }else{

                   $info['divhead'] = '0';
               }


               if(array_key_exists('cchead',$entries)){
                   // step 4
                   $info['cchead'] = $entries['cchead'][0];
               }else{
                   $info['cchead'] = '0';
               }

               // Account Disabled Check
               // step - 5 and step - 6
               if (array_key_exists('ds-pwp-account-disabled',$entries)){

                   if ( $entries['ds-pwp-account-disabled'][0] == 'false' ||  $entries['ds-pwp-account-disabled'][0] == '0'){

                       $info['finish'] = 'true';
                   }else{

                       $info['finish'] = 'false';
                   }

                   $info['accountstatus']  =    $entries['ds-pwp-account-disabled'][0];

               }else{

                   $info['finish'] = 'true';

               }

           }else{

               $info['start'] = 'true';

           }

           $info['username'] = $username;
       }catch (\ErrorException $e){

           $request->session()->put('error','User does not exists');

           return redirect('index/statusView');

       }

//        return view('index.status.status',compact('info'));

        return view('index.status.status',compact('info'));
    }




    public function getPasswordResetEmail(Request $request){

        return view('index.ResetPasswordEmailView');

    }

    public function SentResetPasswordLink(Request $request){

        $username = $request->username;

        try{


            $rules = ['captcha' => 'required|captcha'];


            $validator = Validator::make(Input::all(), $rules);

            if($validator->fails()){

                $request->session()->put('error','Incorrect Captcha ');


                return redirect('/index/statusView');

            }

            $user_dn = 'uid='.$username.','.ldap_base('ldap_user_base');

            $read = $this->connection->read($user_dn,ldap_base('ldap_user_filter'),array('mail'));

            $result = $this->connection->getEntries($read);

            $result = $result[0];

            $toMail = $result['mail'][0];

            // create user entry to store tokon
            $random = base64_encode($toMail);

            $user = new User();
            $user->userId = $username;
            $user->email_token = $random;

            $user->save();

            $data = [
                'to' => $toMail,
                'username' => $username
            ];




            Mail::send('index.ResetPasswordEmailLink' ,$data,function($message) use ($data){

//            $message->to($data['emailId'])->from($data['from'])->subject('IPR Password');
                $message->to($data['to'])->subject('Reset Password IPR');
            });



            $request->session()->put('success','Password Reset Link have been sent to your mail');

            return  $this->getPasswordResetEmail($request);

        }catch (\ErrorException $e){

            $request->session()->put('error','Failed to send mail Contact Administrator ');

            return  $this->getPasswordResetEmail($request);

        }

    }


    // ResetPasswordEmailLink on submit following function will execute
    // password reset View
    public  function PasswordResetEmailView(Request $request,$username){


        return view('index.ResetPasswordLInkView',compact('username'));

        }



        public function changePasswordEmail(Request $request,$username){


            $user_dn = 'uid='.$username.','.ldap_base('ldap_user_base');

            try{

                $user = DB::select('select * from users where userId = ? LIMIT 1',[$username]);

                $email_token = $user[0]->email_token;

                $read = $this->connection->read($user_dn,ldap_base('ldap_user_filter'),array('mail'));

                $result = $this->connection->getEntries($read);

                $result = $result[0];

                $mail = $result['mail'][0];

                if ($mail ==  base64_decode($email_token)){

                    $entry['userpassword'] = $request->newpassword;

                    $update = $this->connection->modReplace($user_dn,$entry);

                    if ($update){

                        $request->session()->put('success','Password have reset successfully');


                        return $this->PasswordResetEmailView($request,$username);

                    }else{

                        $request->session()->put('error','Password reset failed Contact Administrator');


                        return $this->PasswordResetEmailView($request,$username);
                    }

                }else{

                    $request->session()->put('error', 'Wrong Username Contact Administrator');

                    return $this->PasswordResetEmailView($request,$username);
                }



            }catch (\ErrorException $e){


                $request->session()->put('error',$e->getMessage().' Contact Administrator');


                return $this->PasswordResetEmailView($request,$username);

            }

        }

}
