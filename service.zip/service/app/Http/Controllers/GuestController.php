<?php

namespace App\Http\Controllers;

use Adldap\AdldapException;
use \Adldap\AdldapInterface;

use Illuminate\Http\Request;

class GuestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    protected  $ldap;

    public function __construct(AdldapInterface $adldap)
    {
        $this->ldap = $adldap;
    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('guest.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        try{

            $provider = $this->ldap->getDefaultProvider();

            $connection = $provider->getConnection();

            $connection->ssl(true);

            $connection->setOption(LDAP_OPT_PROTOCOL_VERSION,3);

            $connection->setOption(LDAP_OPT_REFERRALS,0);

            $attributes = $request->toArray();


            $attributes = change_array_index('guest',$attributes);

            $attributes = $this->set_object_class($attributes);

            $attributes = delete_empty_index($attributes);

            $dn_user = 'uid='.$attributes['uid'].','. ldap_base('ldap_guest_base');

            $attributes['manager'] = 'uid='.$attributes['uid'].','.ldap_base('ldap_guest_base');

            $result = check_username_unique($connection,$attributes['uid']);

            if ($result != false){
                echo 'User Already Exists';
                return;

            }else{
                echo 'Unique Username';
            }

            $added_user =$connection->add($dn_user,$attributes);

            if ($added_user){
                echo 'Added';
            }else{
                echo 'Plz try later';
            }
        }catch(AdldapException $exception){
            echo $exception->getMessage();
        }


    }



    function  set_object_class($attributes){
        $attributes['objectclass'][0] = 'organizationalPerson';

        $attributes['objectclass'][1] = 'top';

        $attributes['objectclass'][2] = 'person';

        $attributes['objectclass'][3] = 'inetOrgPerson';

        $attributes['objectclass'][4] = 'ipruseraccount';

        $attributes["ds-pwp-account-disabled"] = 1;

        return $attributes;
    }

    public function change_array_index(){











    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
