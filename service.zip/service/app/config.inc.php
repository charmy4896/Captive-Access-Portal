<?php
/**
 * Created by PhpStorm.
 * User: patel
 * Date: 01/02/18
 * Time: 11:13 AM
 */

use Adldap\AdldapInterface;


 function ldap_base($name){

     $base = array();
    $base['ldap_base'] = "dc=ipr,dc=res,dc=in";
    $base['ldap_user_base'] = "ou=users,o=IPR,".$base['ldap_base'];
    $base['ldap_user_filter'] = "(objectClass=ipruseraccount)";
    $base['ldap_groups_base'] = "ou=OrgGroups,o=IPR,dc=ipr,dc=res,dc=in";
    $base['ldap_admin_bind'] = "cn=DirectoryAdmin,";
    $base['ldap_guest_manager_bind'] = "cn=GuestHouse-Admin,";
    $base['ldap_guest_base'] = "ou=guests,o=IPR,dc=ipr,dc=res,dc=in";
    $base['ldap_hosts_base'] = "ou=SecurityGroups,o=IPR,dc=ipr,dc=res,dc=in";


    $base['ldap_hosts_filter'] = "(objectClass=*)";
    $base['ldap_groups_filter'] = "(objectClass=groupOfNames)";
    // $base['ldap_iprgroups_filter'] = "(objectClass=iprusergroup)";
    return $base[$name];
}

use Adldap\Connections\ConnectionInterface;

function getSecurityGroup(ConnectionInterface $connection){



   try{


       $search = $connection->listing( ldap_base('ldap_hosts_base'),ldap_base('ldap_hosts_filter'),array('*'));

       $results = $connection->getEntries($search);

       unset($results['count']);


       foreach ($results as $SecurityGroup){

           $securityGroups[] = [ 'name' => $SecurityGroup['cn'][0] , 'value' => false];

       }

     //  dd(json_encode(array_values($securityGroups)));


       return $securityGroups;

   }catch (ErrorException $e){

       dd($e->getMessage());

   }
}


function getSecurityGroups(){


    $securityGroups = [
        'DirectoryAdmin' => false,
        'Computer Division' => false,
        'hostname' => false,
        'InternetAccess' => false,
        'PAST' => false,
        'PASTA' => false,
        'Eoffice' => false,
        'IDRMS' => false,
        'ZimbraMail' => false,
        'ecloud'=> false,
        'GuestHouse-Admin' => false,
        'MDAccess' => false

    ];

    return $securityGroups;
}

use \Adldap\Models\User;

function attributes_map( User $user,$info){

     $general = array();

     if ($info == 'general'){

         $general = ['Initials' => [ 'value' => $user->getInitials(),'faclass' => 'user'],
         'First Name' => ['value' => $user->getFirstName(), 'faclass' => 'user' ],
         'Last Name' =>['value' => $user->getLastName(), 'faclass' => 'user'],
         'Display Name' => ['value'=>$user->getDisplayName(), 'faclass' => 'user-circle-o'],
     ];
         return $general;
     }

     if ($info == 'personal'){

         $personal = [

             'Alternate Email' => ['value'=>$user->getEmailAddress(),'faclass' => 'envelope'],
             'Payroll number' => ['value'=>$user->getEmployeeNumber(),'faclass' => 'hashtag'],
             'Employee type' => ['value'=>$user->getEmployeeType()[0],'faclass' => 'id-badge'],
             'Employee category' => ['value'=>$user->getBusinessCategory(),'faclass'=>'briefcase'],
             'Division/Section/Project Leader' => ['value'=>$user->getManager(),'faclass' => 'user-circle-o'],
             'Organization' =>['value'=> $user->getOrganizationName(),'faclass' => 'building'],
             'Department' => ['value'=>$user->getDepartment(), 'faclass' => 'building'],
             'Joining Date' => ['value'=>$user->getJoiningDate()[0], 'faclass' => 'calendar'],
             'Completion Date' => ['value'=>$user->getDateOfCompletion(), 'faclass' => 'calendar'],
             'Date Of Birth' => ['value'=>$user->getBirthOfDate(), 'faclass' => 'calendar'],
             'Mobile' => ['value'=>$user->getMobile()[0], 'faclass' => 'mobile'],
             'homephone' => ['value'=>$user->getHomePhone(), 'faclass' => 'phone'],
             'Room Number' => ['value'=>$user->getPhysicaldeliveryofficename(), 'faclass' => 'building'],
             'Extention Number' => ['value'=>$user->getTelephoneNumber(), 'faclass' => 'phone' ]

         ];

         return $personal;
     }

     // when employee search for any other employee nonadmin part
     if($info == 'user_search_items'){

         $searchUserItems = [
             'Initials' => [ 'value' => $user->getInitials(), 'faclass' => 'user'] ,
             'First Name' => ['value' => $user->getFirstName(), 'faclass' => 'user' ],
             'Last Name' =>['value' => $user->getLastName(), 'faclass' => 'user'],
             'Display Name' => ['value'=>$user->getDisplayName(), 'faclass' => 'user-circle-o'] ,
             'IPR E-mail' => [ 'value' =>$user->getEmail() , 'faclass' => 'envelope'],
             'Employee type' => ['value'=>$user->getEmployeeType()[0],'faclass' => 'id-badge'] ,
             'Employee category' => ['value'=>$user->getBusinessCategory(),'faclass'=>'briefcase'] ,
             'Room Number' => ['value'=>$user->getPhysicaldeliveryofficename(), 'faclass' => 'building'],
             'Extention Number' => ['value'=>$user->getTelephoneNumber(), 'faclass' => 'phone']
         ];

         return $searchUserItems;


     }


}

        // All attributes used in web portal
    function changeIndexNameLdap(){

        $attributes_map = array(
            'businesscategory' => array( 'attribute'=>'businesscategory','faclass'=>'briefcase'),
            'displayname' => array( 'attribute' => 'displayname', 'faclass' => 'user-circle'),
            'employeenumber' => array( 'attribute' => 'employeenumber', 'faclass' => 'hashtag'),
            'employeetype' => array( 'attribute' => 'employeetype', 'faclass' => 'id-badge'),
            'firstname' => array( 'attribute' => 'givenname', 'faclass' => 'user-o'),
            'fullname' => array( 'attribute' => 'cn', 'faclass' => 'user-circle'),
            'login' => array( 'attribute' => 'uid', 'faclass' => 'user-o'),
            'lastname' => array( 'attribute' => 'sn', 'faclass' => 'user-o'),
            'mail' => array( 'attribute' => 'mail', 'faclass' => 'envelope-o'),
            'manager' => array( 'attribute' => 'manager', 'faclass' => 'user-circle-o'),
            'mobile' => array( 'attribute' => 'mobile', 'faclass' => 'mobile'),
            'organization' => array( 'attribute' => 'o', 'faclass' => 'building'),
            'organizationalunit' => array( 'attribute' => 'ou', 'faclass' => 'building-o'),
            'initials' => array('attribute' => 'initials','faclass' => 'user-o'),
            'emailaddress' => array( 'attribute' => 'emailaddress', 'faclass' => 'envelope-o'),
            'dateofbirth' => array('attribute' => 'dateofbirth', 'faclass' => 'calendar'),
            'dateofcompletion' => array('attribute' => 'dateofcomplition', 'faclass' => 'calendar'),
            'dateofjoining' => array('attribute' => 'dateofjoining', 'faclass' => 'calendar'),
            'homephone' => array( 'attribute' => 'homephone', 'faclass' => 'phone'),
            'officeroomnumber' => array('attribute' => 'physicaldeliveryofficename','faclass' => 'building'),
            'extensionnumber' => array('attribute' => 'telephonenumber','faclass' => 'phone'),
            'jpegphoto' => array('attribute' => 'jpegphoto'),
            'membership' => array('attribute' => 'ismemberof','faclass' => 'users'),

        );

        return $attributes_map;

    }


    // non admin side
    function changeIndexEmployeeEditForm(){

    $editform = [

        'initials' => '',
        'emailaddress' => '',
        'mobile' => '',
        'homephone' => '',
        'officeroomnumber'=> '',
        'extensionnumber' =>''
    ];


    return $editform;

    }


    // Admin-side Employee edit Form
    function getEditFormAttributes(){

      $editform = array('initials' => '' ,
            'firstname' => '','lastname' => '','mail' => '',
            'emailaddress' => '','employeenumber' => '',
            'employeetype' => '' ,'businesscategory' => '','manager' => '',
            'organization' => '','organizationalunit' => '',
            'dateofjoining' => '','dateofcompletion' => '','dateofbirth' => '',
            'mobile' => '','homephone' => '','officeroomnumber'=> '','extensionnumber' =>'');

        return $editform;
    }


    // Admin Create User with Limited Fields
    function createNewUserAttributes(){

        $createNewUserAttributes = array( 'firstname' => array( 'attribute' => 'givenname', 'faclass' => 'user-o'),
            'fullname' => array( 'attribute' => 'cn', 'faclass' => 'user-circle'),
            'login' => array( 'attribute' => 'uid', 'faclass' => 'user-o'),
            'lastname' => array( 'attribute' => 'sn', 'faclass' => 'user-o'),
            'email' => array( 'attribute' => 'mail', 'faclass' => 'envelope-o'),
            'password' => array('attribute' => 'userpassword','faclass' => 'user-o'),
            'initials' => array('attribute' => 'initials','faclass' => 'user-o'));

        return $createNewUserAttributes;


    }


    function CCDivision(){


     return  ['view' => 'index.ComputerDivision.email' , 'email' => 'nil12111996@gmail.com' , 'subject' => 'User Internet Approval'] ;
    }

    function ComputerCenter(){

    return ['email' => ''];

    }

    function DivHead(){

     return ['subject' => 'User Internet Approval' , 'view' => 'index.DivHeadApproval.email'];

    }

    function CCHead(){

        return ['subject' => 'User Internet Approval' , 'view' => 'index.CCHeadApproval.email'];

    }

    function sendPassword(){

     return ['subject' => 'IPR password' , 'view' => 'auth.temp_pass'];
    }


?>
