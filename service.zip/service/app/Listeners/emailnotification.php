<?php

namespace App\Listeners;

use Adldap\AdldapInterface;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

class emailnotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    protected $ldap;

    protected $connection;
    public function __construct(AdldapInterface $ldap)
    {
        $this->ldap = $ldap;

        $this->connection = $ldap->getDefaultProvider()->getConnection();
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle($event)
    {



        $txt = "Following users are disabled because of completion of tenure.".PHP_EOL; // For sending email

        $date2 = date('d-m-y');

        $d = date_parse_from_format("d-m-y", $date2);

        $currentMonth = $d["month"];

        $currentYear = $d['year'] % 100;

        $currentDay = $d['day'];





        $user_dn = ldap_base('ldap_user_base');

        $ldap_user_filter = "(objectClass=ipruseraccount)";

        $search_results = $this->connection->search($user_dn,$ldap_user_filter,array('uid','displayname','dateofcomplition','cn','ds-pwp-account-disabled'));

        $entries = $this->connection->getEntries($search_results);


        unset($entries['count']);

        foreach ($entries as $user){

            if(key_exists('dateofcomplition',$user)){

                $dateofcomplition = $user['dateofcomplition'][0];

                $dateElements = explode('-', $dateofcomplition);

                if (count($dateElements) == 1){


                    $dateElements  = explode('/',$dateofcomplition);

                     $year =  $dateElements[2] % 100;

                }else{


                    $year = $dateElements[2];
                }


                $month = $dateElements[1];

                $day = $dateElements[0];


                if ($currentYear == $year){

                    if ($currentMonth == $month){

                        if ($currentDay == $day){

                            $txt .= PHP_EOL."Userid: ". $user['uid'][0]. ",User's Name: " . $user['displayname'][0]. PHP_EOL;


                        }

                    }

                }

            }

        }

        $email = ComputerCenter();

        $data =  [
            'txt' => $txt,
            'to'=> $email['email']
        ];


        Mail::send('DeadlineEmail' ,$data,function($message) use ($data){

            $message->to($data['to'])->subject('Account disabled due to end of Completion');
        });

    }
}
