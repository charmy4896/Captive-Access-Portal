<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class user_cc_head_approval extends Model
{
    //
}
