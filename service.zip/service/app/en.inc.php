<?php
/**
 * Created by PhpStorm.
 * User: patel
 * Date: 19/02/18
 * Time: 2:18 PM
 */

    function getHeading($name){
        $messages['hosts'] = "Hosts";
        $messages['profilenotupdated'] = "Profile was not updated";
        $messages['users'] = "User Management";
        $messages['changepassword'] = 'Change Password';
        $messages['orggroups'] = "Org Groups";
        $messages['hbac'] = "Security Groups";
        $messages['groups'] = "Groups";
        $messages['label_lastlogin'] = 'Last Login';
        $messages['label_membership'] = 'Groups';
        $messages['ipr'] = 'IPR';
        $messages['cpp'] = 'CPP';
        $messages['fcipt'] = 'FCIPT';
        $messages['iter-ind'] = 'ITER-India';
        $messages['label_hosts'] = 'Hosts';
        $messages['label_initials'] = 'Initials';
        $messages['label_emailaddress'] = 'Alternate Email';
        $messages['label_departmentnumber'] = 'Department Number';
        $messages['label_dateofjoining'] = 'Joining Date';
        $messages['label_dateofcompletion'] = 'Completion Date';
        $messages['label_bankaccountnumber'] = 'Bank Account Number';
        $messages['label_aadharnumber'] = 'Aadhar Card Number';
        $messages['label_dateofbirth'] = 'Date Of Birth';
        $messages['label_homephone'] = 'homephone';
        $messages['label_officeroomnumber'] = 'Room Number';
        $messages['label_extensionnumber'] = 'Extention Number';


        $messages['required'] = 'One or more fields are incomplete.';
        $messages['ms'] = "Ms.";
        $messages['mr'] = "Mr.";
        $messages['mrs'] = "Mrs.";
        $messages['prof'] = "Prof.";
        $messages['dr'] = "Dr.";
#added for employee types
        $messages['perm'] = "Permanent";
        $messages['temp'] = "Temporary";

#added for employee categories
        $messages['tech'] = "Technical";
        $messages['scit'] = 'Scientific';
        $messages['admin'] = "Administration";
        $messages['cons'] = "Consultant";
        $messages['scholar'] = "Scholar";
        $messages['student'] = "Student";
        $messages['trainee'] = "Trainee";


        $messages['logout'] = "Logout";
        $messages['changepassword'] = "Change Password";
        $messages['advancedsearch'] = "Advanced search";
        $messages['displayentry'] = "Display entry";
        $messages['dnrequired'] = "Entry identifier required";
        $messages['entriesfound'] = "entries found";
        $messages['entryfound'] = "entry found";
        $messages['false'] = "No";
        $messages['fromdate'] = "From";
        $messages['all'] = "All Users";
        $messages['guest'] = "Guest Users";
        $messages['locked'] = "Locked Users";
        $messages['unlocked'] = "Unlocked Users";
        $messages['label_businesscategory'] = "Employee category";
        $messages['label_carlicense'] = "Car license";
        $messages["label_created"] = "Created";
        $messages['label_description'] = "Description";
        $messages['label_displayname'] = "Display name";
        $messages['label_employeenumber'] = "Payroll number";
        $messages['label_employeetype'] = "Employee type";
        $messages['label_fax'] = "Fax";
        $messages['label_firstname'] = "First name";
        $messages['label_fullname'] = "Full name";
        $messages['label_identifier'] = "Identifier";
        $messages['label_l'] = "Locality";
        $messages['label_lastname'] = "Last name";
        $messages['label_mail'] = "IPR E-Mail";
        $messages['label_manager'] = "Division/Section/Project Leader";
        $messages['label_mobile'] = "Mobile";
        $messages["label_modified"] = "Modified";
        $messages['label_organization'] = "Organization";
        $messages['label_organizationalunit'] = "Department";
        $messages['label_pager'] = "Pager";
        $messages['label_phone'] = "Phone";
        $messages['label_postaladdress'] = "Address";
        $messages['label_postalcode'] = "Postal code";
        $messages['label_secretary'] = "Secretary";
        $messages['label_state'] = "State";
        $messages['label_street'] = "Street";
        $messages['label_title'] = "Title";
        $messages['ldaperror'] = "LDAP communication error";
        $messages['noentriesfound'] = "No entries found";
        $messages['notdefined'] = "Not defined";
        $messages['search'] = "Search";
        $messages['searchrequired'] = "Please enter your search";
        $messages['sizelimit'] = "Size limit has been reached, some entries could not be displayed";
        $messages['title'] = "Home";
        $messages['todate'] = "To";
        $messages['true'] = "Yes";
        $messages['welcome'] = "Welcome to LDAP Tool Box White Pages";

        return $messages[$name];
    }
?>