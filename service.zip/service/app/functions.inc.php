<?php
/**
 * Created by PhpStorm.
 * User: patel
 * Date: 01/02/18
 * Time: 11:10 AM
 */

use Illuminate\Support\Facades\Mail;




function change_array_index($type,$attributes = array()){

    unset($attributes['_token']);
    // 1
    $attributes =  change_name($attributes,'login','uid');


    //2
 //   $attributes = change_name($attributes,'password','userpassword');

    if (array_key_exists('confirmpassword',$attributes)){
        unset($attributes['confirmpassword']);
    }

    // 3
    if(array_key_exists('uid',$attributes)){
        $attributes['cn'] =  $attributes['uid'];
    }

    //4
    $attributes =change_name($attributes,'firstname','givenname');


    //
    $attributes =  change_name($attributes,'lastname', 'sn');


    //8
    $attributes['displayname'] =   $attributes['initials'].' '.$attributes['givenname'].' '.$attributes['sn'];

    // 16
        $attributes =  change_name($attributes, 'organization', 'o');

        // 17
        $attributes =  change_name($attributes, 'organizationalunit', 'ou');

        //19
        $attributes = change_name($attributes, 'dateofcompletion', 'dateofcomplition') ;

        // 20
        $attributes = change_name($attributes, 'officeroomnumber', 'physicaldeliveryofficename');

        // 21
        $attributes =change_name($attributes, 'extensionnumber', 'telephonenumber');


    $attributes['cchead'] = '1';

    $attributes['divhead'] = '1';

    return $attributes;
}




 function change_name($attributes,$old_name,$new_name){

    if (array_key_exists($old_name,$attributes)){

        $attributes[$new_name] = $attributes[$old_name];
        unset($attributes[$old_name]);
    }

    return $attributes;
}


    // Employee create Set LDAP objects
  function  set_object_class($attributes){
    $attributes['objectclass'][0] = 'organizationalPerson';

    $attributes['objectclass'][1] = 'top';

    $attributes['objectclass'][2] = 'person';

    $attributes['objectclass'][3] = 'inetOrgPerson';

    $attributes['objectclass'][4] = 'ipruseraccount';

    $attributes["ds-pwp-account-disabled"] = 1;

    return $attributes;
}


 function delete_empty_index($attributes){

    foreach ($attributes as $key => $value){
        if($value == ''){
            unset($attributes[$key]);
        }
    }
    return $attributes;
}


use Adldap\Connections\ConnectionInterface;

    function setLDAPOptions(ConnectionInterface $connection){


        $connection->tls(true);

        $connection->setOption(LDAP_OPT_PROTOCOL_VERSION,3);

        $connection->setOption(LDAP_OPT_REFERRALS,0);

        return $connection;

    }

 function check_username_unique(ConnectionInterface $connection,$username){


    $ldap_filter = "(&(objectclass=ipruseraccount)(uid={login}))";

    $ldap_filter = str_replace("{login}", $username, $ldap_filter);

    $result = $connection->search(ldap_base('ldap_base'), $ldap_filter, ['*']);

    $entry = $connection->getEntries($result);

    if($entry['count'] != 0) {

        return false;
    }
    return true;

}

 function verify_password($password,$confirm_password){
    if($password == $confirm_password){
        return true;
    }
    return false;
}




// get User Details from LDAP
function getUserDetails( ConnectionInterface $connection,$user_dn){

    try{

        $ldap_filter = "objectclass=ipruseraccount";

        $search = $connection->read($user_dn,$ldap_filter,array('*','isMemberOf','ds-pwp-account-disabled'));

        $entries = $connection->getEntries($search);

        return $entries[0];


    }catch (\Adldap\AdldapException $e){
        echo $e->getMessage();
    }

}


// return User Object
function getUserObject(ConnectionInterface $connection , $user_dn){


            $entry = getUserDetails($connection,$user_dn);

            $builder = new \Adldap\Query\Builder($connection);

            $builder->setSchema();

            $user = new \Adldap\Models\User($entry,$builder);

            return $user;

}


// changing Index name Employee Form
function changeIndexEmployeeCreateForm($attributes){

        $attributes_map = changeIndexNameLdap();

    foreach ($attributes_map as $key => $value){

        if (array_key_exists($key,$attributes)){

            $attributes[$value['attribute']] = $attributes[$key];

        }
        if ($key != $value['attribute']){

            unset($attributes[$key]);
        }

    }

    unset($attributes['_token']);

    $attributes['cn'] = $attributes['uid'];

    $attributes['displayname'] =   $attributes['initials'].' '.$attributes['givenname'].' '.$attributes['sn'];

    $attributes['cchead'] = '1';

    $attributes['divhead']  = '1';


    return $attributes;

}

// changeIndexEditFrom  Non-Admin Employee edit from

function changeIndexEditForm($attributes){  // here attributes comes directly from Employee edit form (NOn-Admin Side)

        $editForm = changeIndexEmployeeEditForm();      // config.inc.php

        // Attrbiutes array
        $attributes_map = changeIndexNameLdap();            // config.inc.php


        foreach ($attributes_map as $key => $value ){

            if (array_key_exists($key,$editForm)){

                $attributes[$value['attribute']] = $attributes[$key];

            }


            if ($key != $value['attribute']){

                unset($attributes[$key]);
            }



        }

        unset($attributes['_token']);


        return $attributes;


}



function getUID($name){

    $manager_split = explode('(', $name);

    $manager = explode(')',$manager_split[1]);

    return $manager[0];

}


function sendMail($data,$info){

    $view = $info['view'];

    Mail::send($view, $data, function ($message) use ($data , $info) {

        $message->to($data['to'])->subject($info['subject']);

    });
}



 function checkOldPassword(\Adldap\AdldapInterface $ldap,$user_dn,$oldpassword){


    if ($ldap->getDefaultProvider()->auth()->attempt($user_dn,$oldpassword,true)){
        return true;
    }
    return false;
}







?>