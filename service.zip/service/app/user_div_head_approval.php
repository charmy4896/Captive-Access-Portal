<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class user_div_head_approval extends Model
{
    //

    protected $fillable = [
        'user_id','payroll_no','remarks','user_email','div_head_id','group_head_email','status','request_date','div_approval_date'
    ];

}
