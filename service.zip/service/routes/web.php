<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



//Route::get('/', function () {
//
//    return view('auth.login');
//});



Route::get('/sendMail',function (){

    $data = array(
           'name' => "Learning Laravel",
       );

       Mail::send('welcomeTestMail', $data, function ($message) {

//           $message->from('nil12111996@gmail.com', 'no-reply@ipr.com');

           $message->to('nil12111996@gmail.com')->subject('Learning Laravel test email');

       });

       return "Your email has been sent successfully";

});


use \Illuminate\Support\Facades\DB;

Route::get('/database-test', function () {
    if ( DB::connection('mysql')->getDatabaseName() != null ) {
        echo 'Connected successfully to database: ' . DB::connection()->getDatabaseName();
    }
});


//Route::get('demostatus',function(){
//
//
//    return view('index.status.demostatus');
//
//});



// testing demostatus
Route::post('/demostatusinfo','IndexController@getStatusInfo')->name('getStatusInfo');



//Route::resource('/user','UserController');


//
Auth::routes();

use Intervention\Image\Facades\Image;


Route::group(['middleware' => 'Authenticate','web'],function (){



    Route::get('/', function () {

        return view('auth.login');
    });


    Route::get('/pdfs/{id}', function($id){

        $storagePath = storage_path('app/pdfs/' . $id);

        return  response()->file($storagePath);

    });


    Route::get('/image/{id}', function($id){

        $storagePath = storage_path('app/images/' . $id);

        return Image::make($storagePath)->response();

    });


    Route::resource('/home', 'HomeController');


    // Employee Controller
  
    Route::post('/employee/upload','HomeController@upload')->name('upload');

    Route::get('/employee/jpegphoto/{id}','HomeController@photo')-> name('jpegphoto');

    Route::post('/employee/search','HomeController@search')->name('search');

    Route::get('/employee/logout','HomeController@logout')->name('logout');

    Route::get('/employee/profile/{id}','HomeController@profile')->name('profile');

    Route::get('/employee/password_change_view','HomeController@password_change_view')->name('password_view');

    Route::post('/employee/passwordChange','EmployeeController@changePassword')->name('changepassword');

    Route::get('/employee/viewProfile','HomeController@viewProfile')->name('viewprofile');

    Route::post('/employee/profileUpdate','EmployeeController@update')->name('profileupdate');



    // ADMIN CONTROLLER
    Route::get('/Admin/home','AdminController@index')->name('Admin.index');

    Route::get('/Admin/allUsers','AdminController@getAllUsers')->name('getAllUsers');

    Route::post('/Admin/createUser','AdminController@createUser')->name('createUser');

    Route::get('Admin/deleteUser/{id}','AdminController@deleteUser')->name('deleteUser');

    Route::get('/Admin/lockedUsers','AdminController@getLockedUsers')->name('getLockedUsers');

    Route::get('/Admin/unlockedUsers','AdminController@getUnLockedUsers')->name('getUnLockedUsers');

    Route::get('/Admin/guests','AdminController@getGuests')->name('getGuests');

    // organizational chart

    Route::get('/Admin/home/showOrganizationChart','AdminController@showOrganizationalChart')->name('showOrganizationalChart');

//    Route::get('/Admin/home/showOrganizationChart','AdminController@showOrganizationalChart')->name('showOrganizationalChart');

    Route::post('/Admin/home','AdminController@getOrganizationInformation')->name('getOrganizationInformation');


//    Route::get('/Admin/home','AdminController@getOrganizationInformation')->name('getOrganizationInformation');

    Route::get('/Admin/logout','AdminController@logout')->name('logout');



    Route::get('/Admin/profile/{id}','AdminController@showUserProfile')->name('showUserProfile');

    Route::get('/Admin/profile/{id}/edit','AdminController@editUserProfile')->name('editUserProfile');

    Route::post('/Admin/profileUpdate','AdminController@updateEmployeeDetails')->name('updateEmployeeDetails');

    Route::get('/Admin/profile/{id}/deactivate','AdminController@deactivate')->name('deactivate');

    Route::get('/Admin/profile/{id}/activate','AdminController@activate')->name('activate');

    Route::get('/Admin/passwordChangeView','AdminController@password_change_view')->name('admin_password_change_view');

    Route::post('/Admin/passwordChange','AdminController@Admin_password_change')->name('Admin_password_change');

    Route::get('/Admin/orgGroups','AdminController@OrgGroupsName')->name('OrgGroupsView');

    Route::get('/Admin/orgGroups/{group_dn}','AdminController@getOrgGroupInfo')->name('getGroupInfoView');

    Route::post('/Admin/orgGroups/addGroup','AdminController@addGroup')->name('addGroup');

    Route::post('/Admin/getUsers','AdminController@getUsersName')->name('getUsers');

    // Route::get('/Admin/orgGroups/addMember/{username}','AdminController@addMember')->name('addMember');
    Route::get('/Admin/addMember/{username}','AdminController@addMember')->name('addMember');


    Route::post('/Admin/orgGroups/rename','AdminController@renameGroupName')->name('renameGroupName');

    // change owner name
    Route::post('/Admin/orgGroups/changeOwnerName','AdminController@changeOwner')->name('changeOwner');


    // Route::post('/Admin/orgGroups/removeMember/{commanname}','AdminController@removeMember')->name('removeMember');
    Route::post('/Admin/removeMember/{commanname}','AdminController@removeMember')->name('removeMember');

    Route::post('/Admin/profile/{id}/access-right','AdminController@giveAccessRights')->name('giveAccessRights');


    // Security Groups
    Route::get('/Admin/SecurityGroups','AdminController@SecurityGroupNames')->name('SecurityGroupNames');

    Route::get('/Admin/securityGroups/{group_dn}','AdminController@SecurityGroupInfo')->name('getHostInfoView');

    Route::post('/Admin/securityGroups/addHost','AdminController@addHost')->name('addHost');

    Route::post('/Admin/securityGroups/rename','AdminController@renameHostName')->name('renameHostName');


    // Deadline
    Route::get('/Admin/deadline','AdminController@deadline')->name('deadline');

    // Log viewer
    Route::get('logs', '\Rap2hpoutre\LaravelLogViewer\LogViewerController@index')->name('logviewer');


    // Show div head Aprroval View
//    Route::get('/index/{id}/{token}/{divHeadId}','IndexController@divHeadApprovalView')->name('divHeadApprovalView');
    Route::get('/head/DivHeadApprovalView','EmployeeController@divHeadApprovalView')->name('divHeadApprovalView');

    // Approve User Div Head Request
    Route::post('/head/DivHeadApproval','EmployeeController@divHeadApproval')->name('divHeadApproval');

    // Disapproval User Div Head Request
    Route::post('/head/DivHeadDisApproval','EmployeeController@divHeadDisApproval')->name('divHeadDisApproval');


    Route::get('/CCHead/CCUserApproval','EmployeeController@CCHeadApprovalView')->name('CCHeadApprovalView');


    // Approve User CC Head Request
    Route::post('/CCHead/DivHeadApproval','EmployeeController@CCHeadApproval')->name('CCHeadApproval');

    // Disapproval User CC Head Request
    Route::post('/CCHead/DivHeadDisApproval','EmployeeController@CCHeadDisApproval')->name('CCHeadDisApproval');



});




Route::group(['middleware' => 'web'],function (){


    // Refresh Captcha
    Route::get('/refreshcaptcha',function (){

        return captcha_img('flat');

    })->name('refreshCaptcha');




    Route::get('/', function () {

        return view('auth.login');
    });




    // IndexController
    Route::get('/index/statusView','IndexController@getStatusView')->name('getStatusView');

 //   Route::post('/index/statusInfo','IndexController@getStatus')->name('getStatus');

    Route::match(['get', 'post'], '/index/statusInfo', ['as' => 'getStatus', 'uses' => 'IndexController@getStatus']);

    Route::get('/index/passwordchangeView','IndexController@getPasswordChangeView')->name('getPasswordChangeView');

    Route::post('/index/passwordchange','IndexController@passwordChange')->name('IndexPasswordChange');

    Route::post('/index/divisionHead','IndexController@getDivisionHead')->name('getDivHead');

    Route::post('/index/getDept','IndexController@getDepartmentOfOwner')->name('getDepartmentOfOwner');

    Route::get('/index/passwordResetEmailView','IndexController@getPasswordResetEmail')->name('passwordResetEmail');

    Route::post('/index/SentResetPasswordLink','IndexController@SentResetPasswordLink')->name('SentResetPasswordLink');

    //  ResetPasswordLink on submit following route will execute
    Route::get('/index/{username}/PasswordResetEmailView','IndexController@PasswordResetEmailView')->name('PasswordResetEmail');

    // change password using Email
    Route::post('/index/PasswordResetEmail/{username}','IndexController@changePasswordEmail')->name('changePasswordEmail');


    // Checkusername Validity
    Route::post('/index/check_username_unique','IndexController@checkUsername')->name('checkusername');


    // EMPLOYEE CONTROLLER



    Route::resource('/employee','EmployeeController');



    // Guest Controller
    Route::resource('/guest','GuestController');




});



